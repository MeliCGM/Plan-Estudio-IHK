# Vocabulario nuevo — añadir al TQ2_Vocabulario_CONSOLIDADO (secciones 42-43)

## 42. Elektrotechnik — Grundstromkreis, Normschaltzeichen (Ergänzung)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die DIN (Deutsche Industrienorm) | norma industrial alemana (DIN) | German Industrial Standard (DIN) | Define cómo se dibujan los símbolos eléctricos. |
| der Schließer, - | contacto normalmente abierto | normally open contact (NO) | Nombre alemán describe la función al accionar; el inglés describe el reposo — fuente de confusión al traducir. |
| der Öffner, - | contacto normalmente cerrado | normally closed contact (NC) | Ver Schließer — misma trampa de traducción inversa. |
| der Taster, - / handbetätigter Drucktaster | pulsador | pushbutton | Símbolo básico de esquemas. |
| der Zählpfeil, -e | flecha de referencia (de sentido) | reference arrow | Indica el sentido técnico convencional de corriente/tensión en el esquema. |
| die Klemmspannung | tensión en bornes | terminal voltage | Depende de la carga; mencionada al comparar mediciones reales con la tensión nominal de red. |
| der statische Widerstand | resistencia estática (lineal) | static/linear resistance | Constante en todo el rango de tensión; contrasta con el "Halbleiterwiderstand". |
| der Halbleiterwiderstand | resistencia de semiconductor (no lineal) | non-linear (semiconductor) resistance | Cambia con la tensión aplicada; clave para entender diodos/Z-Dioden. |
| THT (Through-Hole Technology) | tecnología de orificio pasante | through-hole technology (THT) | Audio transcribió erróneamente "Two-Hole Technology" — corregido por contexto. |
| die E3-Reihe | serie E3 (valores normalizados) | E3 series | 3 escalones/década, tolerancia >20%; la más antigua/menos precisa mencionada en clase. |
| der Temperaturbeiwert (TK, ΔK) | coeficiente de temperatura | temperature coefficient | Variación del valor por kelvin; anillo adicional opcional en el código de colores. |

## 43. Elektrotechnik — Diode, Gleichrichtung, Glättung, Transistor Grundlagen (Ergänzung)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Kennlinienaufnahme | toma/registro de la curva característica | characteristic curve measurement | Ensayo práctico de medición de un diodo/transistor. |
| die Einweggleichrichtung | rectificación de media onda | half-wave rectification | Un solo diodo; deja pasar solo una polaridad. |
| die Mittelpunkt-Zweiweggleichrichtung | rectificación de onda completa con punto medio | full-wave center-tap rectification | Requiere transformador con toma central + 2 diodos. |
| der Brückengleichrichter, - | puente rectificador | bridge rectifier | 4 diodos, no requiere transformador especial; usa ambas semiondas. |
| die Glättung | filtrado/alisado (de la tensión) | smoothing (filtering) | Con condensador en paralelo a la carga. |
| die Restwelligkeit / die Brummspannung | ondulación residual / tensión de zumbido | ripple (voltage) | Depende de C y de R_L; audible como zumbido a 50/100 Hz. |
| die Freilaufdiode | diodo de rueda libre / diodo de marcha libre | flyback / freewheeling diode | Protege contra la tensión inducida al desconectar una bobina (relé). |
| der Spannungsregler, - / der Festspannungsregler | regulador de tensión / regulador de tensión fija | voltage regulator / fixed voltage regulator | Ej. serie 7805; mantiene salida constante pese a variaciones de carga/entrada. |
| die Verlustleistung (P_tot) | potencia disipada (total) | (total) power dissipation | P_tot ≈ U_CE·I_C en un transistor; nunca debe superarse. |
| die Stromverstärkung (B, h_FE) | ganancia de corriente (estática) | (DC) current gain | B = I_C/I_B. |
| die Basis / der Kollektor / der Emitter | base / colector / emisor | base / collector / emitter | Terminales del transistor bipolar (B, C, E). |
| der Bipolartransistor | transistor bipolar | bipolar junction transistor (BJT) | Control por diferencia de potencial (a diferencia del unipolar/FET). |
| der NPN-Transistor / der PNP-Transistor | transistor NPN / transistor PNP | NPN transistor / PNP transistor | Flecha del emisor: NPN hacia afuera, PNP hacia adentro. |
| die Grenzdaten (pl.) | datos límite (nunca superar) | absolute maximum ratings | P.ej. U_CE max, I_C max, P_tot max. |
| die Kenndaten (pl.) | datos característicos (de comportamiento) | characteristic data | P.ej. la ganancia B en un punto de trabajo. |
| der BNC-Anschluss | conector BNC | BNC connector | Conector rápido de cuarto de vuelta para sondas de osciloscopio; cable coaxial (núcleo + blindaje) evita interferencias en frecuencia. |
| die Tantal-Elektrolytkondensator | condensador electrolítico de tantalio | tantalum electrolytic capacitor | Dieléctrico sólido (óxido metálico), no líquido; con el envejecimiento baja la tensión máxima admisible (no la capacidad). |
