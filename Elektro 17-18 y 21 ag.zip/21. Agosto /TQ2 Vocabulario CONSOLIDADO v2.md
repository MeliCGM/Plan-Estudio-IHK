# TQ2 — Vocabulario acumulado consolidado (alemán-español-inglés)

_Documento único fusionado a partir de los archivos guardados en DCA (chats del proyecto "Transcripción de clases", 5–21 jul 2026), incluyendo las prácticas (HP-Wochen) del 20 y 21 de julio. Términos duplicados entre archivos se listan una sola vez, conservando la nota más completa disponible. Organizado por tema del temario TQ2, no por fecha de clase._

---

## 1. Sala limpia (Reinraum) — fundamentos y clases

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Reinraumklasse, -n | clase de sala limpia | cleanroom class | Definida por norma ISO 14644-1 o Fed-Std-209 (obsoleta). |
| der Fed-Standard (Fed-Std-209) | norma federal EE.UU. (obsoleta) de clasificación de salas limpias | Federal Standard 209 (obsolete) | Precedente histórico del ISO 14644; retirada oficialmente en 2001 pero aún citada por costumbre. |
| die ISO-Klasse | clase ISO (de limpieza) | ISO class | Escala de clasificación según partículas/m³ (ISO 14644-1); grados fijos sin fórmula simple detrás. |
| die laminare Strömung | flujo laminar | laminar flow | Capas paralelas sin turbulencia; partículas se dirigen controladamente hacia abajo. |
| die turbulente Strömung | flujo turbulento | turbulent flow | Opuesto de flujo laminar; hay que combatirlo/aislarlo en el Reinraum. |
| die Vertikalbox, -en | cabina de flujo laminar vertical | vertical laminar flow box | De arriba hacia abajo; cubre grandes superficies de forma uniforme. |
| die Horizontalbox, -en | cabina de flujo laminar horizontal | horizontal laminar flow box | Flujo frontal; suele estar más cerrada lateralmente que la vertical. |
| das Mini-Environment | mini-entorno (zona de aire controlado) | mini-environment | "Sala limpia dentro de la sala limpia" alrededor de un equipo o cabina. |
| das Ballroom-Konzept | concepto de sala abierta ("ballroom") | ballroom concept | Una gran nave con flujo continuo de techo, sin mini-entornos individuales. |
| die Zwangsfolge, -n | secuencia obligatoria de proceso | mandatory process sequence | Ventana de tiempo prescrita entre pasos (ej. wafer al aire tras limpieza). |
| der/die Reinraumbeauftragte(r) | responsable/encargado de sala limpia | cleanroom officer | Hace mediciones periódicas (mensuales) en puntos fijos definidos. |
| die Gebläsestufe, -n | nivel/velocidad del ventilador de la cabina | fan speed level | Gebläse = ventilador/soplador; niveles numerados (ej. Stufe 1–6). |
| das Reinraumpapier | papel de sala limpia | cleanroom paper | Más denso y liso que el papel normal; genera muchas menos partículas. |
| der Reinraumoverall, -s | overol/mono de sala limpia | cleanroom suit/coverall | Genera muchas menos partículas que la ropa normal. |
| der Mundschutz | mascarilla | face mask | Parte del EPP de sala limpia junto con cofia, overol y guantes. |
| die PSA (persönliche Schutzausrüstung) | EPP (equipo de protección personal) | PPE (personal protective equipment) | Sigla muy usada en contexto de seguridad industrial. |
| die Nitrilhandschuhe (pl.) | guantes de nitrilo | nitrile gloves | Evitan que la piel de las manos genere partículas. |

## 2. Sala limpia — medición de partículas y microscopía

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Partikelmessgerät, -e (CEM) | contador de partículas (modelo CEM) | particle counter (CEM model) | Partikel = partícula, Messgerät = aparato de medición. |
| das Handpartikelmessgerät, -e | contador de partículas manual/portátil | handheld particle counter | Hand- = manual, portátil (vs. equipo de pie fijo). |
| der Partikelzähler, - | contador de partículas (principio de funcionamiento) | particle counter | Bomba de vacío + láser + fotodiodo + electrónica contadora. |
| der Ansaugstutzen, - | boquilla/tubuladura de succión | suction nozzle/inlet | ansaugen = aspirar, succionar; Stutzen = tubo corto de conexión. |
| die Spülzeit, -en | tiempo de purga/enjuague (automático) | purge/rinse time | spülen = enjuagar — mismo verbo que "fregar los platos". |
| die Vergleichsmessung, -en | medición comparativa/de referencia | reference/comparison measurement | Vergleich = comparación. |
| die Verteilung, -en | distribución (estadística) | distribution | No confundir con Verteidigung (defensa) — casi idénticas al oído. |
| die Messzelle, -n | celda/zona de medición | measuring cell | Zona por donde pasa el haz láser dentro del contador de partículas. |
| das Streulicht | luz dispersada/dispersión de luz | scattered light | streuen = dispersar; a mayor partícula, mayor dispersión, menos luz al fotodiodo. |
| die Fotodiode, -n | fotodiodo | photodiode | Recibe el pulso de luz dispersada; a mayor partícula, mayor pulso. |
| die Sichtkontrolle, -n | control/inspección visual | visual inspection | Primer paso (macroscópico) del análisis de un wafer, antes del microscopio. |
| der Fettfinger, - | marca de dedo grasosa (huella) | greasy fingerprint | Fett = grasa; señal típica de mal uso de guantes. |
| die CD-Messung (Critical Dimensions) | medición de dimensiones críticas | critical dimension (CD) measurement | Verifica que una estructura esté dentro de tolerancia. |
| der Querschliff, -e | corte transversal (metalográfico) | cross-section | Se corta el die, se embute en resina, se pule y se examina al microscopio. |
| das Rasterelektronenmikroskop (REM) | microscopio electrónico de barrido (SEM) | scanning electron microscope (SEM) | Mayor resolución y profundidad de campo que el óptico. |
| der Scrap | pieza rechazada/desechada | scrap | Anglicismo usado tal cual en la industria alemana; fuera de tolerancia. |
| das Messschraubenokular (MSO) | ocular micrométrico filar | filar micrometer eyepiece | Mide estructuras en wafers/máscaras; requiere calibración previa. |
| die Kalibrierung | calibración | calibration | Relación entre skalenteile (divisiones) y un patrón conocido; ≠ Eichen (verificación legal). |
| der Kalibrierfaktor, -en | factor de calibración | calibration factor | µm por división = distancia en el patrón ÷ diferencia de lecturas. |
| das Fenster, - (Maske/Struktur) | ventana (estructura) | window (structure) | Área abierta entre dos Stege. |
| der Steg, -e | puente/línea (estructura) | line/bridge (structure) | Elemento sólido entre dos ventanas de una máscara/estructura. |
| die Stegbreite, -n | ancho de línea | line width | Distancia entre dos bordes de estructura. |
| die Nebelvisualisierung | visualización con niebla | fog/mist visualization | Técnica para ver el flujo de aire (DI-FOG). |
| das Nebelgerät, -e (DI-FOG) | generador de niebla | fog generator | Ultrasónico, con agua DI (sin partículas). |
| die Ausströmgeschwindigkeit | velocidad de salida (de aire) | outflow velocity | Medida en pruebas de flujo laminar. |

## 3. Sala limpia — manejo de obleas (Waferhandling)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Waferhandling | manejo de obleas | wafer handling | Aparece muy deformado en el audio ("Molverhändling") — siempre es Wafer + Handling. |
| die Vakuumpinzette, -n | pinza de vacío | vacuum tweezers | Succión por vacío en la punta; solo toca la cara inactiva. |
| der Wafer-Carrier, - / die Horde | carrier / cesta portaobleas | wafer carrier | Numeración de arriba (1) hacia abajo (25); solo se abre bajo flujo laminar. |
| die aktive/inaktive Seite (des Wafers) | cara activa / cara inactiva (del wafer) | active/inactive side | La cara activa lleva el proceso; nunca se apoya la pinza ahí. |
| der Kratzer, - | rayón (daño superficial) | scratch | Daño irreversible del material. |
| der Krater, - | cráter (daño) | crater (damage) | Rayón ancho y profundo, más severo que el Kratzer. |
| die Prozessstufe, -n | etapa del proceso | process stage | Determina, junto al tamaño de partícula, el método de inspección a usar. |

## 4. Limpieza (Reinigung) — química y métodos

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Nassreinigung | limpieza química húmeda | wet cleaning | nass = mojado/húmedo, vs. limpieza física (soplado con N₂). |
| die Partikelverunreinigung, -en | contaminación por partículas | particle contamination | — |
| die organische/molekulare Verunreinigung | contaminación orgánica/molecular | organic/molecular contamination | Ej. restos de fotorresina. |
| die atomare Verunreinigung | contaminación atómica | atomic contamination | Metales pesados en la red cristalina. |
| die ionische Verunreinigung | contaminación iónica | ionic contamination | Compuestos alcalinos. |
| die Tolerierbarkeit | tolerabilidad (de la contaminación) | tolerability (of contamination) | Concepto clave: 100% limpio no es alcanzable ni necesario. |
| das Standard Clean (SC1/SC2) | limpieza estándar (SC1/SC2) | Standard Clean (SC1/SC2) | También llamada RCA, Huang A&B, limpieza Kern. |
| die RCA-Reinigung / Kernsche Reinigung | limpieza RCA / limpieza Kern | RCA clean / Kern clean | "Kernsche" viene de Werner Kern, su inventor real (no es error de transcripción). |
| SC1 (Standard Clean 1) | SC1 — NH₄OH + H₂O₂ | SC1 (ammonium hydroxide + peroxide) | Para contaminación orgánica; siempre con ultrasonido/megasónico. |
| SC2 (Standard Clean 2) | SC2 — HCl + H₂O₂ | SC2 (hydrochloric acid + peroxide) | Para contaminación metálica; después de SC1, con baño intermedio de agua. |
| das NH₄OH | hidróxido de amonio (amoniaco) | ammonium hydroxide | Componente de SC1. Nota: en solución acuosa es más correcto llamarlo "solución de amoníaco" (Ammoniaklösung), ya que el NH₄OH puro no existe aislado. |
| die Ammoniaklösung | solución de amoníaco | ammonia solution | Nombre químicamente más preciso que "hidróxido de amonio". |
| das H₂O₂ (Wasserstoffperoxid) | peróxido de hidrógeno | hydrogen peroxide | Componente de SC1 y SC2; forma capa protectora de óxido. |
| das HCl (Salzsäure) | ácido clorhídrico | hydrochloric acid | Componente de SC2. |
| die Piranha-Säure | ácido piraña | piranha solution/acid | H₂SO₄ + H₂O₂; reacción exotérmica, muy corrosiva. |
| das Königswasser | agua regia | aqua regia | HCl + HNO₃ concentrados; disuelve oro. |
| die Flusssäure (HF) | ácido fluorhídrico | hydrofluoric acid (HF) | Usada en BHF/DHF y grabado de óxido. |
| das BHF / DHF (gepuffertes HF) | HF tamponado | buffered HF (BHF/DHF) | Repone iones fluoruro para mantener la tasa de grabado estable. |
| die Komplexbildung | formación de complejos | complexation | Mecanismo por el que SC1/SC2 disuelven metales pesados. |
| die Kavitation / Kavitationsblase, -n | cavitación / burbuja de cavitación | cavitation / cavitation bubble | Generada por ultrasonido, implosiona en la superficie. |
| die Megasonic-Reinigung | limpieza megasónica | megasonic cleaning | Frecuencia más alta que el ultrasonido normal. |
| die Eigenresonanz (des Wafers) | resonancia propia (de la oblea) | wafer natural resonance | Puede anular el efecto del ultrasonido si coincide con su frecuencia. |
| der Spin Rinse Dry (SRD) | secado por rociado y centrifugado | spin rinse dry (SRD) | Rocía con DI-agua y seca centrifugando con N₂. |
| das Marangoni-Verfahren | proceso/secado Marangoni | Marangoni drying | Vapor de IPA rompe el menisco de agua, evita película residual. |
| der Meniskus | menisco | meniscus | Curvatura de la superficie del líquido al retirar el wafer del baño. |
| das Isopropanol (IPA) | isopropanol | isopropyl alcohol (IPA) | Último paso de limpieza líquida; se evapora rápido, sin residuo. |
| die Oberflächenspannung | tensión superficial | surface tension | Responsable de que el agua "se pegue" al wafer si no se rompe el menisco. |
| die Trocknungsflecken (pl.) | manchas de secado | water/drying marks | Residuos si la humedad no se elimina bien antes de evaporarse sola. |
| die Delamination | delaminación | delamination | Una capa se despega de la base — falla grave, casi siempre irrecuperable. |
| die Metal Fence, -s | filamento metálico residual ("cerca") | metal fence | Defecto tras CMP/grabado de metal; se elimina con cepillo. |
| das Reinstwasser / DI-Wasser | agua ultrapura / desionizada | ultrapure water / DI water | "Desionizado" describe solo ausencia de iones. |
| das Mischbettfilter, - | filtro de lecho mixto | mixed-bed filter | Retira iones para producir agua desionizada. |
| der Schwebstofffilter, - | filtro de partículas en suspensión (HEPA/ULPA) | particulate (HEPA/ULPA) filter | Última etapa de filtrado de aire, y también parte del tratamiento de agua ultrapura. |
| die Neutralisationsreaktion | reacción de neutralización | neutralization reaction | Base del mecanismo de revelado (Entwickeln). |

## 5. Seguridad ESD/EGB y estructura física del Reinraum

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| ESD (elektrostatische Entladung) | descarga electrostática | electrostatic discharge (ESD) | Evento que se quiere evitar. |
| EGB (elektrostatisch geschützter Bereich) | área protegida contra electrostática | EPA (electrostatic protected area) | Zona/medida que evita el ESD. |
| das MOS-Bauelement, -e / der MOSFET | dispositivo MOS / transistor MOSFET | MOS device / MOSFET | Basado en el principio de un condensador; el más vulnerable a ESD. |
| das Dielektrikum, Dielektrika | dieléctrico | dielectric | Capa de óxido entre metal y silicio; lo que se destruye en un evento ESD. |
| der Räumungsalarm | alarma de desalojo (no de incendio) | evacuation drill alarm | Se sale vestido igual, sin cambiarse, por la esclusa. |
| der Evakuierungsalarm | alarma de evacuación/incendio | fire/emergency evacuation alarm | Única situación en la que no hace falta cambiarse de ropa al salir. |
| die Schleuse, -n | esclusa (zona de transición de acceso) | airlock / load lock | Ahí se retiran las capas de empaque antes de entrar al Reinraum. |
| die Ableitfähigkeit | capacidad de descarga a tierra | dissipative capability | Distinto de Leitfähigkeit (conductividad general); dirige la carga hacia el suelo. |
| der Lochplattentisch / der Lochboden | mesa perforada / suelo perforado | perforated table/floor | Permiten flujo de aire vertical sin obstáculos. |
| die Zwischendecke, -n | plenum / falso techo | plenum | Espacio del filtro final antes de insuflar aire a la sala de producción. |
| die Technikebene / die Medienebene | nivel técnico / nivel de medios | utility level | Bombas de vacío, tanques de química húmeda, bajo el suelo perforado. |
| VLSI-Qualität | calidad VLSI | VLSI-grade purity | Grado de pureza exigido a los reactivos que entran al Reinraum. |
| die Hilfsstoffe (pl.) | insumos / sustancias auxiliares | auxiliary materials | Fuente de partículas frecuentemente subestimada. |
| die Versorgungsleitung, -en | línea/tubería de suministro | supply line | También considerada fuente de partículas en el Reinraum. |
| der Grobfilter, - | prefiltro / filtro grueso | pre-filter | Primera etapa de filtrado de aire. |

## 6. Formación / administración (Ausbildung)

| Alemán | Español | Nota de memorización |
|---|---|---|
| der Ausbildungsrahmenplan | plan marco de formación (currículo oficial) | Rahmen = marco; define qué debe aprender cada oficio regulado. |
| die IHK (Industrie- und Handelskammer) | Cámara de Industria y Comercio | Fija el Ausbildungsrahmenplan y cobra cuotas obligatorias a las empresas. |
| die Abgabe(n) | cuota(s)/aportación(es) obligatoria(s) | Pagos obligatorios de las empresas a la IHK. |
| die Bedienungsanleitung | manual de instrucciones/manual de uso | bedienen = operar un equipo; solo se entrega dentro del Reinraum. |
| der Arbeitsplan | plan de trabajo/procedimiento operativo | Se redacta antes de entrar al Reinraum, paso a paso. |
| das Zettel | hoja/formulario de registro en papel | Reemplazó a un sistema anterior de registro. |

---

## 7. Electrónica (Elektrotechnik) — circuito básico, Kirchhoff, medición

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Spannungserzeugung | generación de tensión | Spannung = tensión, Erzeugung = generación. |
| der Grundstromkreis | circuito eléctrico básico | Grund- = base/fundamental + Stromkreis = circuito. |
| das Widerstandsnetzwerk | red de resistencias | Widerstand + Netzwerk. |
| der Leiter / der Halbleiter | conductor / semiconductor | Halb- = medio/semi. |
| die Potentialdifferenz | diferencia de potencial | Concepto de tensión eléctrica. |
| geschlossener Stromkreis | circuito cerrado | Requisito para que fluya corriente. |
| der Widerstand | resistencia | Oposición al paso de corriente. |
| das Ohmsche Gesetz (R = U/I) | ley de Ohm | R en Ohm, U en Volt, I en Ampere. |
| die Induktion | inducción | Ej. dinamo de bicicleta. |
| die Photovoltaik / das Fotoelement / die Solarzelle / die Fotodiode | fotovoltaica / elemento fotoeléctrico / célula solar / fotodiodo | La Fotodiode es bidireccional. |
| das Thermoelement | termopar | Unión cobre/Konstantan; rango ≈ −250°C a 1400°C. |
| die Quellenspannung (Uq) / Betriebsspannung (UB) / Versorgungsspannung | tensión de fuente / de servicio / de alimentación | Tres nombres para el mismo concepto según contexto. |
| der Innenwiderstand (Ri) | resistencia interna (de la fuente) | Típico 0,2–10 Ω. |
| der Lastwiderstand (RL) / der Verbraucher | resistencia de carga / consumidor | Equivalente resistivo de cualquier aparato conectado. |
| die Leitungshin / die Leitungsrück | conductor de ida / conductor de vuelta | Dirección del cableado en el esquema. |
| die Reihenschaltung | conexión en serie | Las resistencias se suman; corriente igual en todos. |
| die Parallelschaltung | conexión en paralelo | Tensión igual en todos; corrientes se suman. |
| der Spannungsteiler (unbelastet) | divisor de tensión (sin carga) | UR2 = Uq·R2/(R1+R2). |
| der Gesamtwiderstand (Rges) | resistencia total | Suma (serie) o suma de inversos (paralelo). |
| das Kirchhoffsche Gesetz | ley de Kirchhoff | Físico alemán Gustav Kirchhoff. |
| der Knotenpunktsatz (1. Kirchhoffsches Gesetz) | ley de los nudos | ΣI entrante = ΣI saliente en un nudo. |
| der Maschensatz (2. Kirchhoffsches Gesetz) | ley de las mallas | ΣU en malla cerrada = 0V. |
| die elektrische Leistung (P) | potencia eléctrica | P = U·I = I²·R = U²/R; unidad Watt. |
| die Arbeit (A) | trabajo (energía) | U = A/Q (Q en Coulomb). |
| die Widerstandsmessung | medición de resistencia | Siempre spannungsfrei; óhmetro en paralelo. |
| die Spannungsmessung | medición de tensión | Voltímetro en paralelo. |
| die Strommessung | medición de corriente | Amperímetro en serie; hay que interrumpir el cable. |
| spannungsfrei | sin tensión / libre de tensión | Condición obligatoria antes de medir resistencia. |
| die Spule | bobina | Componente que aprovecha el efecto magnético. |
| der Transformator | transformador | Ej. reducir 50V a 20V. |
| das Relais | relé | Componente basado en efecto magnético. |
| die chemische Wirkung | efecto químico (de la corriente) | Ej. depósito de cobre. |
| die Oberflächenveredelung | recubrimiento/tratamiento superficial | veredeln = refinar/mejorar. |
| die Lichtwirkung | efecto luminoso (de la corriente) | Ej. filamento de wolframio incandescente. |

## 8. Electrónica — Entflechten y divisor de tensión con carga

| Alemán | Español | Nota de memorización |
|---|---|---|
| das Entflechten | desenredar / simplificar (red de resistencias) | Redibujar identificando nudos compartidos, sin cambiar tensiones/corrientes. |
| der Knoten | nudo (de un circuito) | El instructor lo pronunciaba "Note"; nudo "cruz" (X) y nudo "estrella" (*). |
| die Brücke (protoboard) | puente (conector corto) | Se retira para insertar el amperímetro en serie. |
| das Amperemeter / Ampermeter | amperímetro | Se conecta siempre en serie. |
| der belastete Spannungsteiler | divisor de tensión con carga | Resistencia de carga (RL) en paralelo a R2. |
| der unbelastete Spannungsteiler | divisor de tensión sin carga | UR2 = Uq·R2/(R1+R2). |
| R2,L | resistencia equivalente de R2 en paralelo con RL | R2,L = (R2·RL)/(R2+RL). |
| der Verbraucher | consumidor / carga | Dispositivo que usa la energía (ej. lámpara). |
| das Querstromverhältnis (q) | relación de corriente transversal | q = I_R2/I_RL; típicamente 3–10 (5 recomendado). |
| der Laststrom (I_RL) | corriente de carga | Corriente que llega al consumidor. |

## 9. Electrónica — Multímetro, errores de medición, resistencias como componente

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Spannungsrange / der Messbereich / der Spannungsbereich | rango de medición / rango de tensión | Range es anglicismo; el término formal es Messbereich. |
| die Genauigkeit | precisión | Contrapuesto a Toleranz (tolerancia admitida de error). |
| die Toleranz | tolerancia | 1,5% típico analógico, 0,5% típico digital. |
| der Endwert | valor de fondo de escala | El % de tolerancia analógica se calcula sobre el Endwert, no sobre el valor leído. |
| der absolute Messfehler | error absoluto | F = k·Bereich/100; en digital se suma el error de dígitos. |
| der relative Messfehler | error relativo | f = F·100/Anzeigewert; aumenta cuanto menor es el valor medido dentro del rango. |
| der Anzeigewert / der Messwert | valor mostrado / valor medido | Lo que se lee en pantalla o aguja del instrumento. |
| das Digit (± X Digit) | dígito(s) de la última cifra mostrada | En digital: error = %+dígitos. |
| die Messkategorie / CAT 1-4 (Überspannungskategorie) | categoría de medición / de sobretensión | Marcada en la carcasa; a más categoría, más protección frente a sobretensión. |
| der Zangwandler [A CONFIRMAR] | pinza amperimétrica / transformador de pinza | Mide corriente sin cortar el cable; término exacto no verificado en el audio. |
| der Festwiderstand | resistencia fija | Valor no ajustable. |
| der Schichtwiderstand / der Kohleschichtwiderstand | resistencia de capa / de capa de carbón | Kohle = carbón, por el material de la capa resistiva. |
| der Metallfilmwiderstand | resistencia de película metálica | Mayor precisión típica que la de carbón. |
| der SMD-Widerstand | resistencia SMD | Surface Mounted Device = dispositivo de montaje superficial. |
| der Drahtwiderstand | resistencia bobinada / de hilo | Draht = alambre enrollado sobre núcleo cerámico. |
| das Potentiometer | potenciómetro | Ajustable manualmente; 3 conexiones: entrada, salida, cursor. |
| das Trimmpotentiometer | potenciómetro de ajuste / trimmer | Versión pequeña, solo ajustable con herramienta. |
| die Schleife (bei Poti) | cursor / contacto deslizante | Punto medio móvil que define la tensión de salida. |
| der PTC-Widerstand (Kaltleiter) | PTC / conductor en frío | A mayor temperatura, mayor resistencia. |
| der NTC-Widerstand (Heißleiter) | NTC / conductor en caliente | A mayor temperatura, menor resistencia. |
| PTC / NTC (Positive/Negative Temperature Coefficient) | coeficiente de temperatura positivo/negativo | PTC sube con la temperatura, NTC baja. |
| der Varistor (spannungsabhängiger Widerstand) | varistor (resistencia dependiente de la tensión) | Por debajo de la tensión umbral casi no conduce. |
| das Zinkoxid | óxido de zinc | Material de varistor para tensiones mayores (hasta ~1,5 kV). |
| das Siliziumcarbid | carburo de silicio | Material de varistor para tensiones menores. |
| der LDR (lichtabhängiger Widerstand) / Fotowiderstand | fotorresistencia | A más oscuridad, mayor resistencia. |
| das DMS (Dehnungsmessstreifen) | galga extensiométrica | Dehnung = deformación; usada en tecnología de pesaje. |
| der magnetabhängige Widerstand | resistencia dependiente del campo magnético | Símbolo con letra B (inducción). |
| die Induktion (B) | inducción (magnética) | Letra B en esquemas de sensores magnéticos. |
| der Curie-Punkt / die Curie-Temperatur | punto de Curie / temperatura de Curie | Temperatura a partir de la cual un material pierde propiedades magnéticas. |
| die E-Reihe (E6, E12, E24, E48, E96) | serie de valores normalizados (de resistencias) | Tolerancias: E6=±20%, E12=±10%, E24=±5%. |
| die Auswahl (aus der Reihe) | selección (de la tabla de la serie) | Se toma el valor igual o mayor al calculado. |
| das Nominal / der Nominalwert | valor nominal | Valor "de catálogo" de un componente. |

## 10. Electrónica — LED y diodos básicos

| Alemán | Español | Nota de memorización |
|---|---|---|
| die LED / Leuchtdiode | LED / diodo emisor de luz | Leuchten = brillar/emitir luz. |
| die Anode / die Kathode | ánodo / cátodo | Pata larga = ánodo (+); pata corta = cátodo (−). |
| die Reflektorwanne | copa reflectora (dentro del LED) | Base donde se apoya el chip LED. |
| der Golddraht / Bonddraht | hilo de oro / hilo de conexión | Conecta el chip LED al terminal opuesto. |
| der LED-Chip | chip LED | Parte semiconductora (unión P-N) donde se genera la luz. |
| das Kunststoffgehäuse | encapsulado/carcasa de plástico | El color del plástico no determina el color de luz. |
| die Durchlassrichtung | dirección de conducción directa | Polarización en la que el LED conduce y emite luz. |
| die Sperrrichtung | dirección de bloqueo (inversa) | El LED no conduce ni emite luz. |
| die Sperrschicht | zona de carga espacial / unión P-N | Recombinación de huecos y electrones, libera luz. |
| P-dotiert / N-dotiert | dopado tipo P / tipo N | P rica en huecos, N rica en electrones. |
| das Loch / die Löcher | hueco / huecos (portador positivo) | Plural: das Loch → die Löcher. |
| der Elektronenüberschuss | exceso de electrones | Corrientes altas en polarización directa fuerte. |
| die Durchbruchspannung / der Durchbruch | tensión de ruptura / ruptura | Polarización inversa con campo eléctrico muy alto. |
| der Vorwiderstand | resistencia limitadora (para LED) | R_V = (U_alimentación − V_F)/I_F. |
| die Durchlassspannung (V_F) | tensión directa (del LED) | Rojo 0,6–1,6V; amarillo/verde 1,8V; azul 3V; blanco 3,5V. |
| der Durchlassstrom (I_F) | corriente directa (del LED) | Estándar: 20mA (algunos 25mA). |

## 11. Electrónica — Kondensator (condensador)

| Alemán | Español | Nota de memorización |
|---|---|---|
| der Kondensator (Bauelement) | condensador (componente) | Acopla y almacena energía, no de forma permanente. |
| die Kapazität (C) [Farad] | capacidad | C = ε₀·εr·A/l. |
| das Dielektrikum | dieléctrico | Aire, agua, cerámica, papel/película. |
| die Feldkonstante (ε₀) | constante/permitividad de campo eléctrico (del vacío) | ε₀ = 8,85×10⁻¹² F/m. |
| die Permittivität (εr) | permitividad relativa | Aire=1, agua≈80, cerámica≈100–10.000. |
| der Elektrolytkondensator (Elko) | condensador electrolítico | Tiene polaridad definida (+/−); riesgo de explosión si se invierte. |
| der Folienkondensator | condensador de película (foil) | Lámina enrollada como dieléctrico. |
| der Keramikkondensator | condensador cerámico | Permitividad relativa alta. |
| die Zeitkonstante (τ = R·C) | constante de tiempo | 1τ ≈ 63%; 5τ ≈ 99,8% de carga. |
| die Ladung / die Entladung | carga / descarga (del condensador) | U_C(t) = U₀·(1−e^(−t/τ)); I(t) = I₀·e^(−t/τ). |
| der Ladungsvorgang / der Entladungsvorgang | proceso de carga / proceso de descarga | Curvas complementarias, visibles en el osciloscopio. |
| Kondensatoren parallel | condensadores en paralelo | Las capacidades se SUMAN (al revés que las resistencias). |
| Kondensatoren in Reihe | condensadores en serie | Dos: C=(C1·C2)/(C1+C2). Tres o más: 1/C=1/C1+1/C2+1/C3. |

## 12. Electrónica — Osciloscopio y fuentes de tensión

| Alemán | Español | Nota de memorización |
|---|---|---|
| das Oszilloskop | osciloscopio | Cognado directo. |
| das Spannung-pro-Kästchen | tensión por división (volts/div) | Escala vertical, ajustable por canal. |
| das Zeit-pro-Kästchen | tiempo por división (time/div) | Escala horizontal, común a ambos canales. |
| der Tastkopf | punta de prueba (del osciloscopio) | Requiere compensación para señal cuadrada. |
| die Kompensation (Tastkopf) | compensación (de la punta de prueba) | Ajuste con tornillo hasta obtener onda cuadrada ideal. |
| das Verhältnis (1:1 / 1:10) | relación / factor de atenuación de la punta | 1:10 = amplitud mostrada 10 veces menor que la real. |
| der Kanal (Kanal 1 / Kanal 2) | canal (1 / 2) | Cada canal tiene su propio ajuste de tensión-por-división. |
| die Autoeinstellung / Auto (Taste) | autoajuste (botón Auto) | Ajusta automáticamente tensión y tiempo por división. |
| der Kursor (Cursor-Modus) | cursor (modo manual) | Línea móvil para leer valores exactos. |
| die Masse (Oszilloskop) | masa / tierra (de medición) | Punto de referencia común. |
| der Leerlauf | vacío / circuito abierto | R_carga → ∞, I=0, U=U_Q completa. |
| der Kurzschluss | cortocircuito | R_carga → ~0; I_max = U_Q/R_i. |
| der Normalbetrieb | funcionamiento normal | 0 < R_carga < ∞. |
| die Leistungsanpassung | adaptación de potencia (máxima transferencia) | Cuando R_carga = R_i; P_max = U_Q²/(4·R_i). |
| die Spannungsquellen in Reihe | fuentes de tensión en serie | Tensiones y resistencias internas se suman. |
| die Spannungsquellen parallel | fuentes de tensión en paralelo | La tensión no cambia; aumenta la corriente disponible. |
| der Ausgleichsstrom | corriente de compensación | I = (U_Q1−U_Q2)/(R_i1+R_i2); puede ser peligrosa. |
| kontaktloses Laden | carga inalámbrica / sin contacto | Demostrado con bobina tipo Tesla. |

## 13. Electrónica — corriente alterna (Wechselstrom) y seguridad eléctrica

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Sinuskurve / sinusförmig | curva senoidal / de forma sinusoidal | Forma característica de la corriente/tensión alterna. |
| die Halbwelle (positiv/negativ) | semionda (positiva/negativa) | Cada mitad del ciclo de la sinusoide. |
| die Periodendauer (T) | periodo (duración) | Unidad: segundos. |
| die Frequenz (f = 1/T) | frecuencia | Unidad: Hertz (Hz). |
| die Kreisfrequenz (ω, Omega) | frecuencia angular / circular | ω = 2·π·f; unidad rad/s. |
| der Augenblickswert | valor instantáneo | u(t) = Û·sin(ω·t). |
| der Scheitelwert (Û) | valor pico / de cresta | Amplitud máxima de la sinusoide. |
| das Bogenmaß / der Radiant | medida en radianes | Unidad angular alternativa al grado. |
| die spezifische Widerstand (ρ, Rho) | resistividad específica | R = ρ·l/A; unidad Ω·mm²/m. [A CONFIRMAR: valor exacto de cobre citado en clase]. |
| die Querschnittsfläche (A) | sección transversal (del cable) | Área de corte del conductor; unidad mm². |
| der Wirkwiderstand | resistencia óhmica pura / activa | Independiente de la frecuencia. |
| der Blindwiderstand | reactancia | Depende de la frecuencia. |
| der induktive Widerstand (XL) | reactancia inductiva | XL = ω·L = 2·π·f·L. |
| der kapazitive Widerstand (XC) | reactancia capacitiva | XC = 1/(ω·C) = 1/(2·π·f·C). |
| die Phasenverschiebung (φ, Phi) | desfase / desplazamiento de fase | En un elemento inductivo, la corriente se retrasa respecto a la tensión. |
| die Induktivität (L) [Henry, H] | inductancia | Unidad Henry; propiedad de la bobina. |
| der Fehlerstromschutzschalter (FI) | interruptor diferencial (RCD) | Corta el circuito ante fuga de corriente a tierra. |
| die Erde / geerdet | tierra / puesto a tierra | Conductor de protección. |
| die Loslassschwelle | umbral de "no poder soltar" | Corriente a partir de la cual no se puede soltar el contacto. |
| die Wahrnehmbarkeitsschwelle | umbral de percepción | ~0,5–1 mA en AC. |
| das Herzkammerflimmern | fibrilación ventricular | Efecto de corrientes altas (>0,5A) sobre el corazón. |

## 14. Electrónica — Impedancia, resonancia y osciloscopio avanzado

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Impedanz (Z) | impedancia | impedance | Z = √(R² + X²); resistencia total en corriente alterna. |
| der Scheinwiderstand | resistencia aparente (=Impedanz) | apparent resistance / impedance | Sinónimo de Impedanz en este contexto. |
| die Reihenschwingkreis | circuito resonante serie | series resonant circuit | R, L, C en serie; en resonancia: Z mínima, I máxima. |
| die Parallelschwingkreis | circuito resonante paralelo | parallel resonant circuit | En resonancia: Z máxima, I mínima. |
| die Resonanz / die Resonanzfrequenz (fr) | resonancia / frecuencia de resonancia | resonance / resonant frequency | fr = 1/(2π√(L·C)); ahí XL = XC. |
| der Scheinleitwert (Y) | conductancia aparente/admitancia | admittance | Y = 1/Z = √(G² + B²). |
| der Wirkleitwert (G) | conductancia activa | conductance | G = 1/R. |
| der Blindleitwert (B) | susceptancia | susceptance | B = 1/X (BL o BC según el elemento). |
| der Gütefaktor (Q) | factor de calidad | quality factor | El instructor aclaró que no entra en el examen. |
| die obere/untere Grenzfrequenz | frecuencia de corte superior/inferior | upper/lower cutoff frequency | Relacionadas con Q y fr. |
| die Effektivspannung (U_eff) | tensión eficaz (RMS) | RMS voltage | U_eff = U_spitze/√2 ≈ 0,707·U_spitze. |
| die Spitzenspannung (U_spitze, Û) | tensión de pico | peak voltage | Valor instantáneo máximo. |
| die Spitze-Spitze-Spannung (U_ss, VPP) | tensión pico a pico | peak-to-peak voltage | Entre el punto máximo y el mínimo de la señal. |
| die Kopplung (DC/AC) | acoplamiento (DC/AC) | coupling (DC/AC) | AC filtra el offset de continua. |
| der Trigger (Auto/Normal/Single) | disparo (automático/normal/único) | trigger | Controla cuándo el osciloscopio "congela" la señal. |
| der Eisenkern | núcleo de hierro | iron core | Dentro de la bobina/transformador. |
| die Windung(en) | vuelta(s) (de una bobina) | winding(s)/turns | Ej. 300 vs 900 Windungen. |

---

## 15. Fundamentos de semiconductores — historia de la industria

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| der Halbleiter, - | semiconductor | semiconductor | halb = medio, Leiter = conductor. |
| das Halbleiterbauelement, -e (BE) | componente/dispositivo semiconductor | semiconductor device | Abreviado "BE" en las diapositivas. |
| die integrierte Schaltung, -en (IC) | circuito integrado | integrated circuit (IC) | Schaltung = circuito/conmutación. |
| das diskrete Bauelement, -e | componente discreto | discrete component | Opuesto a "integrado". |
| der Gleichrichter, - | rectificador | rectifier | gleich + richten = "enderezar igual" → un solo sentido de corriente. |
| die Vakuumröhre, -n | tubo de vacío/válvula termoiónica | vacuum tube | También "Braunsche Röhre" (tubo catódico histórico). |
| der Transistor, -en | transistor | transistor | — |
| das Schaltelement, -e | elemento de conmutación | switching element | schalten = conmutar/encender-apagar. |
| das Moore'sche Gesetz | ley de Moore | Moore's law | Duplicación de transistores por superficie cada ~18 meses; no es ley física. |
| die Kernladungszahl / Ordnungszahl | número atómico | atomic number | Determina el orden en la tabla periódica. |
| das Schlüsseltechnologie, -n | tecnología clave/estratégica | key technology | Como se declaró la microelectrónica en la RDA. |
| das Embargo, -s | embargo | embargo | Restricción de exportación de tecnología a la RDA. |
| der Ionenimplanter, - | implantador de iones | ion implanter | Equipo para dopaje por implantación. |
| die Waferfabrik, -en (Fab) | fábrica de obleas (wafer) | fab | Comúnmente abreviado "Fab". |
| der Standort, -e | sede/emplazamiento (industrial) | site/location | — |
| ausgliedern (sich ausgliedern) | escindirse (una empresa) | to spin off | Siemens → Infineon → Qimonda. |
| insolvent (sein) | estar en quiebra/insolvencia | to be insolvent | Qimonda ging insolvent. |
| die Zuliefererfirma, -en | empresa proveedora | supplier company | — |
| das Ausbildungscenter, - | centro/escuela de formación | training center | — |
| organische Halbleiter (pl.) | semiconductores orgánicos | organic semiconductors | Ej.: Pentacen, Tetracen. No forman cristal, son flexibles. |
| das Pentacen | pentaceno | pentacene | Semiconductor orgánico usado en pantallas flexibles. |
| das Tetracen | tetraceno | tetracene | [A CONFIRMAR ortografía exacta en audio: "Fentasen/Tetrazen"], confirmado por diapositiva. |
| der Verbindungshalbleiter, - | semiconductor compuesto/de compuesto | compound semiconductor | Ej. GaAs, InAs. |
| das Galliumarsenid (GaAs) | arseniuro de galio | gallium arsenide | Tóxico (arsénico), más caro y frágil que el silicio. |

## 16. Fundamentos de semiconductores — bandas, dopaje, unión PN

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Valenzband, ¨-er | banda de valencia | valence band | Electrones ligados al átomo. |
| das Leitungsband, ¨-er | banda de conducción | conduction band | Electrones libres, conducen corriente. |
| die Bandlücke, -n (GAP) / Sperrschicht / verbotene Zone | banda prohibida | band gap / forbidden zone | En HL ≈0,08–3 eV [A CONFIRMAR: valores contradictorios entre sesiones para Leiter/Nichtleiter]. |
| das Elektronenvolt (eV) | electronvoltio | electron volt | 1 eV = 1,6×10⁻¹⁹ J. |
| der Avalanche-Effekt / Lawineneffekt | efecto avalancha | avalanche effect/breakdown | Ionización en cadena; ruptura catastrófica de un aislante a alta tensión. |
| das Elektronengas | gas de electrones (nube electrónica) | electron gas/sea | Explica la alta conductividad de los metales. |
| der spezifische Widerstand | resistencia específica/resistividad | resistivity | Unidad Ω·cm. |
| die Atombindung / Ionenbindung / Metallbindung | enlace covalente / iónico / metálico | covalent / ionic / metallic bond | Tipos de enlace químico relevantes para conductividad. |
| die Edelgaskonfiguration | configuración de gas noble | noble gas configuration | 8 electrones en la capa externa. |
| die Eigenleitung | conducción intrínseca | intrinsic conduction | nº electrones = nº huecos. |
| dotieren / die Dotierung | dopar / dopaje | to dope / doping | — |
| der dotierte Halbleiter | semiconductor dopado | doped semiconductor | Se añade otro material (aleación, difusión, implantación, epitaxia). |
| das Donatorniveau / der Elektronendonator | nivel donador / donador de electrones | donor level / electron donor | Cerca de banda de conducción; aporta electrones → tipo N (ej. P, As). |
| das Akzeptorniveau / der Elektronenakzeptor | nivel aceptor / aceptor de electrones | acceptor level / electron acceptor | Cerca de banda de valencia; genera huecos → tipo P (ej. B, Ga). |
| N-dotiert / N-Halbleiter | dopado tipo N | N-type semiconductor | Mayoría: electrones. |
| P-dotiert / P-Halbleiter | dopado tipo P | P-type semiconductor | Mayoría: huecos. |
| das Elektronenloch, ¨-er / die Löcher | hueco / huecos electrónicos | electron hole | Concepto de "vacante" de electrón; portador positivo. |
| die Lochleitung | conducción por huecos | hole conduction | Técnicamente electrones saltando de hueco en hueco. |
| der Ladungsträger | portador de carga | charge carrier | Electrones y huecos en un semiconductor. |
| der PN-Übergang, ¨-e | unión PN | PN junction | Frontera entre zona P y N; base del diodo. |
| die Dotierwanne, -n | pozo/región dopada | doped well | Forma visual de "bañera" en los esquemas. |
| der Channeling-Effekt / Tunneleffekt | efecto de canalización | channeling effect | Iones atraviesan la red sin frenarse por mala orientación cristalina. |
| das Gate All-Around | puerta envolvente (tecnología GAA) | gate-all-around (GAA) | Tecnología de transistor más reciente. |
| das MOSFET | MOSFET | MOSFET | Metal-Oxide-Semiconductor Field-Effect-Transistor. |
| das CMOS | CMOS | CMOS | Complementary MOS; combina N+P-MOSFET. |
| der Enhancement-Typ / der Depletion-Typ | tipo de enriquecimiento / de vaciamiento | enhancement type / depletion type | Enhancement = normalmente apagado; depletion = normalmente conductor. |
| der ohmsche Kontakt, -e | contacto óhmico | ohmic contact | Relación lineal I-V, para conexiones normales. |
| der Schottky-Kontakt, -e | contacto Schottky | Schottky contact | Se usa deliberadamente solo en diodos. |
| die Elektromigration | electromigración | electromigration | Movimiento de átomos metálicos por corriente eléctrica alta. |
| die Diffusionsbarriere, -n | barrera de difusión | diffusion barrier | Ej. Tantal para cobre, Platino para oro. |
| das Tantal | tantalio | tantalum | Barrera de difusión para el cobre. |

## 17. Fundamentos de semiconductores — diodos

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| der Durchlassstrom (I_F) | corriente en directa | forward current | Corriente cuando el diodo conduce. |
| die Durchlassspannung (U_F) | tensión en directa | forward voltage | Si ≈0,7V (0,7–1,2V); Ge ≈0,3–0,6V. |
| der Sperrstrom (I_S/I_R) | corriente en inversa (fuga) | reverse/leakage current | Muy pequeña, casi cero en teoría. |
| die Sperrspannung (U_R) | tensión en inversa | reverse voltage | Diodo en polarización inversa. |
| die Gleichrichterdiode | diodo rectificador | rectifier diode | Convierte AC en DC. |
| die Z-Diode (Zenerdiode) | diodo Zener | Zener diode | Anillo negro; funciona en ruptura controlada en inversa. |
| die Kapazitätsdiode (Varicap) | diodo varicap | varactor diode | Actúa como condensador variable según tensión aplicada. |
| die Leistungsdiode | diodo de potencia | power diode | Mayor tensión/corriente admisible (ej. 380V/2,5A). |
| die 1N4004 (Gleichrichterdiode) | diodo 1N4004 (rectificador) | 1N4004 (rectifier diode) | Modelo estándar de diodo rectificador mencionado en clase. |

---

## 18. Fabricación de obleas (Waferherstellung)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| der Quarzsand / Kiesel | arena de cuarzo / cuarzo (piedra) | quartz sand / silica rock | Materia prima, es SiO₂. |
| das Rohsilizium (MGS-Silizium) | silicio bruto/en bruto (grado metalúrgico) | metallurgical grade silicon (MGS) | Primera etapa tras la reducción. |
| die Reduktion | reducción (química, con carbono) | reduction (carbothermic) | Quarz + Kohlenstoff → Rohsilizium. |
| das Trichlorsilan (SiHCl₃) | triclorosilano | trichlorosilane | Intermedio líquido/gaseoso, base de la destilación; se produce en el Kaltwandreaktor. |
| die fraktionierende Destillation | destilación fraccionada | fractional distillation | Separa impurezas del triclorosilano. |
| der Kaltwandreaktor, -en | reactor de pared fría | cold-wall reactor | Donde se deposita el polisilicio de alta pureza (Siemens-Prozess). |
| das Polysilizium / Reinstsilizium | polisilicio / silicio de altísima pureza | polysilicon / high-purity silicon | — |
| das Monokristall(in) / Polykristall(in) / amorph | monocristal(ino) / policristal(ino) / amorfo | monocrystalline / polycrystalline / amorphous | Orden de largo alcance vs. corto alcance vs. ninguno. |
| das Czochralski-Verfahren | proceso/método Czochralski | Czochralski process (CZ) | Tira del cristal desde un crisol fundido; más barato, dopaje menos homogéneo. |
| das Float-Zone-Verfahren (FZ, tiegelfreies Zonenziehen) | proceso de zona flotante | float-zone process (FZ) | Sin crisol, mayor pureza/resistividad, limitado a ~200 mm, más caro. |
| der Impfkristall, -e | cristal semilla | seed crystal | Define la orientación del lingote. |
| der Ingot, -s / der Einkristall, -e | lingote (monocristal) | ingot / single crystal | — |
| die Segregation | segregación (de impurezas) | segregation | Empuje de impurezas hacia la zona fundida en el método FZ. |
| das Abdrehen | torneado (del lingote) | grinding/turning to diameter | — |
| der Flat, -s / der Notch / die Kerbe | corte plano / muesca (marcas de orientación) | flat / notch | Flat: obleas pequeñas, uno o dos cortes (Primary/Secondary indican orientación y dopaje N/P). Notch: desde 150–200 mm, leído automáticamente por robots. |
| die Innenlochsäge, -n | sierra de agujero interior | inner-diameter (ID) saw | Corte más homogéneo, menor rendimiento. |
| die Drahtsäge, -n | sierra de hilo | wire saw | Mayor rendimiento, algo más de daño superficial. |
| das Läppen | lapeado (pulido químico-mecánico, adelgazado) | lapping (CMP for thinning) | Sinónimo alemán de CMP en este contexto. |
| die CMP (Chemical Mechanical Planarization) | planarización químico-mecánica | chemical mechanical planarization (CMP) | Término internacional estándar. |
| die Slurry | suspensión abrasiva (para CMP) | slurry | Disolvente + partícula abrasiva + agente oxidante. |
| das Schleifen | rectificado (mecánico) | grinding | Genera daño superficial. |
| das Polieren | pulido | polishing | Última etapa de planarización. |
| die Waferdicke, -n | espesor de la oblea | wafer thickness | ~725-775 µm para 300 mm. |
| die Kristallorientierung, -en | orientación cristalina | crystal orientation | Fijada al crecer el lingote. |
| die Millerschen Indizes (pl.) | índices de Miller | Miller indices | Tres números entre paréntesis (100/110/111) describen el plano cristalino. |
| der Gitterfehler, - | defecto de red (cristalina) | lattice defect | Punto, línea, superficie, volumen. |
| anisotropes Ätzen | grabado anisótropo | anisotropic etching | Depende de la orientación cristalina; con KOH graba distinto según (100)/(111). |
| das MEMS (mikroelektromechanisches System) | sistema microelectromecánico | MEMS | Sensores de presión, aceleración, etc. |
| die Waferspezifikation, -en | especificación de la oblea | wafer specification | Hoja con diámetro, dopaje, resistividad, etc. |
| der Bow / Warp (Wafer) | arqueo / deformación de la oblea | wafer bow / warp | Medición de estrés; afecta litografía y procesos posteriores. |

---

## 19. Oxidación térmica

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die thermische Oxidation | oxidación térmica | thermal oxidation | Crece SiO₂ consumiendo el silicio del wafer (Aufwachsen). |
| das Aufwachsen | crecimiento (de capa a partir del sustrato) | (oxide) growth | Diferente de "Abscheidung" (deposición: material 100% externo). |
| die Trockenoxidation | oxidación seca | dry oxidation | Si + O₂ → SiO₂; usada como óxido de puerta (Gateoxid). |
| die Feuchtoxidation | oxidación húmeda | wet oxidation | Si + 2H₂O + O₂ → SiO₂ + 2H₂O; usada como Maskenoxid. |
| das Gateoxid, -e | óxido de puerta | gate oxide | Producto típico de oxidación seca. |
| das Maskenoxid, -e | óxido de máscara | mask oxide | Producto típico de oxidación húmeda. |
| diffusionslimitiert | limitado por difusión | diffusion-limited | Fase tardía (C) del crecimiento de óxido. |
| das Tempern | temperado/recocido | annealing (furnace) | Proceso de horno aparte que sana daños de red. |
| der Horizontalofen | horno horizontal | horizontal furnace | Gas cae por gravedad → menos homogéneo. |
| der Vertikalofen | horno vertical | vertical furnace | Más homogéneo, más difícil de cargar. |
| das Quarzrohr, -e | tubo de cuarzo | quartz tube | Cámara del horno de oxidación. |
| der Dreizonenofen | horno de tres zonas | three-zone furnace | Tipo de horno de resistencia clásico. |
| die Zonenheizung | calefacción por zonas | zone heating | 3–5 zonas, temperaturas distintas. |
| der Bubbler, - | burbujeador | bubbler | Como narguile invertido; N₂/gas arrastra vapor de agua para oxidación húmeda. |
| der Heiztubus | tubo de calentamiento (camisa exterior) | heating tube/jacket | Rodea al tubo de cuarzo. |
| das Glasboot, -e | bote de vidrio (portaobleas) | (glass) wafer boat | Usado en procesos batch. |
| der Dummy-Wafer, - | oblea ficticia | dummy wafer | Solo ocupa espacio/volumen en el horno. |
| der Testwafer, - | oblea de prueba | test wafer | Para pruebas destructivas. |
| die Vier-Spitzenmessung | medición de cuatro puntas | four-point probe measurement | Prueba destructiva (deja marcas). |
| zerstörende / zerstörungsfreie Prüfung | prueba destructiva / no destructiva | destructive / non-destructive test | Ej. microscopio óptico = no destructiva. |
| die Homogenitätsmessung | medición de homogeneidad | uniformity measurement | Mín. 5–13 puntos por oblea. |
| die Eingriffsgrenze, -n | límite de intervención (control) | control limit | Calculado a partir de la tolerancia. |
| der Bird's Beak / Vogelschnabel-Defekt | defecto de pico de pájaro | bird's beak defect | Oxidación lateral bajo la máscara. |
| der Graphitträger, - | portador de grafito | graphite carrier | Usado en RTP, medido por IR/láser. |
| der Hauptstrom / Nebenstrom (Gas) | corriente principal / secundaria (de gas) | main flow / bypass flow | — |
| das MFC (Durchflussregeleinheit) | controlador de flujo másico | mass flow controller (MFC) | — |
| das RTP (Rapid Thermal Processing) | procesamiento térmico rápido | rapid thermal processing (RTP) | Término general (lámparas halógenas), proceso de oblea individual. |
| das RTA (Rapid Thermal Annealing) | recocido térmico rápido | rapid thermal annealing (RTA) | Repara defectos de red cristalina. |
| das RTO (Rapid Thermal Oxidation) | oxidación térmica rápida | rapid thermal oxidation (RTO) | Óxidos muy finos, proceso de oblea individual. |
| das Ramp up / Ramp down | rampa de subida / bajada (de temperatura) | ramp up / ramp down | — |
| das Knallgas | gas detonante (mezcla H₂/O₂) | oxyhydrogen/detonating gas | Se evita manteniendo el O₂ en exceso. |

---

## 20. Litografía — fotorresinas y química

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Lithografie | litografía | lithography | Proceso de estructuración más importante. |
| der Lack, -e / der Resist | fotorresina | photoresist | Lack = Resist, sinónimos. |
| der Positivlack | resina positiva | positive photoresist | Expuesto → soluble. |
| der Negativlack | resina negativa | negative photoresist | No expuesto → soluble; más resistente al grabado. |
| der Umkehrlack | resina de inversión | image reversal resist | Puede comportarse como ambas según proceso. |
| das Phenolharz (Novolack) | resina fenólica (novolaco) | phenolic resin (novolak) | Hidrófila, soluble en agua per se; tipo de resina positiva. |
| das DNQ (Diazonaphthochinon) | DNQ (diazonaftoquinona) | DNQ (diazonaphthoquinone) | Componente fotoactivo, actúa de "portero". |
| die Wolffsche Umlagerung | reordenamiento de Wolff | Wolff rearrangement | DNQ → carbeno/ceteno bajo UV. |
| die Carbonsäure, -n | ácido carboxílico | carboxylic acid | Producto final tras exposición del DNQ; neutralizado por el revelador. |
| das Cap (DNQ-Phenolharz) | "tapa" (DNQ unido al fenol) | cap (bound DNQ) | DNQ unido covalentemente vía puente de oxígeno a una OH del Phenolharz. |
| der Lawineeffekt (en resinas) | efecto de avalancha (amplificación química) | avalanche/cascade effect | Amplificación química en resinas CAR. |
| der Photoacid Generator (PAG) | generador fotoquímico de ácido | photoacid generator (PAG) | Componente fotoactivo de resinas negativas tipo SU8. |
| das Triarylsulfoniumsalz | sal de triarilsulfonio | triarylsulfonium salt | Tipo de PAG usado en SU8; anión SBF6⁻. |
| die Epoxygruppe, -n | grupo epóxido | epoxy group | SU8 tiene 8 por molécula de resina. |
| das Crosslinking / die Quervernetzung | reticulación / enlace cruzado | crosslinking | Reacción entre grupos epóxido abiertos. |
| der chemisch verstärkte Lack (CAR) | resina químicamente amplificada | chemically amplified resist (CAR) | SU8 es el ejemplo típico. |
| das Bisphenol A | bisfenol A | bisphenol A | Monómero base de la resina SU8. |
| das Cyclopentanon | ciclopentanona | cyclopentanone | Disolvente de SU8. |
| das Aceton | acetona | acetone | Disolvente/hinchante para remover resina. |

## 21. Litografía — proceso, máscaras y exposición

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Prebake / Softbake / Hardbake | prebake / softbake / hardbake | prebake / softbake / hardbake | Prebake: deshidrata la superficie. Softbake: evapora disolvente. Hardbake: endurece definitivamente. |
| das HMDS (Hexamethyldisilazan) | HMDS (hexametildisilazano) | HMDS (hexamethyldisilazane) | Hidrofiliza→hidrofobiza la superficie; pregunta de examen segura. |
| die Randwinkelmessung | medición de ángulo de contacto | contact angle measurement | Mide hidrofobicidad. |
| hydrophil / hydrophob | hidrófilo / hidrófobo | hydrophilic / hydrophobic | Atrae agua / repele agua. |
| das Spin-on-Verfahren | aplicación por centrifugado | spin-on / spin coating | Fuerza centrífuga reparte la resina. |
| der Randwulst, -"e | reborde/burbuja de borde | edge bead | Resina más gruesa en el borde de la oblea. |
| die Randentlackung (EBR) | remoción de resina de borde | edge bead removal (EBR) | Rocío de disolvente en el borde. |
| das Retikel, - / die Maske, -n | retículo / máscara | reticle / mask | Vidrio + cromo. |
| der Maskenblank, -s | placa base de máscara | mask blank | Vidrio con cromo, material de partida antes de estructurar. |
| das Halbzeug | semiproducto | semi-finished material | Material ya recortado, listo para trabajar. |
| bedampfen | recubrir por evaporación | to (vapor-)coat | Chrom bedampfen = recubrir con cromo por deposición. |
| der Elektronenstrahlschreiber, - | escritor de haz de electrones | e-beam writer | Escribe la máscara maestra directamente, sin exposición por inundación; preciso, lento. |
| die Mastermaske, -n | máscara maestra | master mask | Primera máscara, origen de todas las demás. |
| das Pellicle, -s | pellicle (película protectora) | pellicle | Protege el retículo de partículas. |
| die Kontaktbelichtung | exposición por contacto | contact lithography | 1:1, máscara sobre la oblea. |
| die Proximity-Belichtung | exposición de proximidad | proximity lithography | Pequeño espacio, sin contacto directo. |
| die Projektionsbelichtung | exposición por proyección | projection lithography | Reducción óptica. |
| der Stepper, - | stepper | stepper | Flutbelichtung por posición, la mesa se mueve. |
| der Scanner, - | scanner | scanner | Rendija móvil, mejor resolución, más lento. |
| das Step-and-Scan-Verfahren | step-and-scan | step-and-scan | Combinación de ambos, máxima precisión. |
| die numerische Apertur (NA) | apertura numérica | numerical aperture (NA) | Determina resolución y profundidad de foco. |
| die Fokustiefe / DOF | profundidad de foco | depth of focus (DOF) | DOF = k·λ/NA². |
| die Auflösungsgrenze | límite de resolución | resolution limit | d_min = k·λ/NA. |
| die EUV-Lithografie | litografía EUV | EUV lithography | ~13,5 nm; requiere espejos multicapa y vacío. |
| das DUV (Deep Ultraviolet) | ultravioleta profundo | deep ultraviolet (DUV) | Estándar de litografía a 193 nm hasta ~2015. |
| der Mehrschichtspiegel / Multilayer-Spiegel | espejo multicapa | multilayer mirror | Sustituye a las lentes en litografía EUV. |
| die Beugung / Diffraktion | difracción | diffraction | Determina el patrón de interferencia en la máscara. |
| die Interferenz | interferencia | interference | Constructiva/destructiva entre ondas de luz difractada. |
| die Streubelichtung | exposición dispersa (por reflexión) | flare / stray exposure | Distinta de la difracción. |
| die Antireflexschicht, -en | capa antirreflejante | anti-reflective coating (ARC) | Evita reflexión, no la difracción; composición química exacta [A CONFIRMAR]. |

## 22. Litografía — revelado, medición y defectos

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Entwicklung | revelado | development | Con base + agua. |
| der Entwickler, - | revelador | developer | Neutraliza el ácido carboxílico; base del mecanismo de revelado (neutralización). |
| der Dunkelabtrag | pérdida en oscuro | dark erosion | Pequeña pérdida de resina no expuesta. |
| der Gelblichtbereich | zona de luz amarilla | yellow room | Evita exposición UV no controlada. |
| die CD-Messung (Critical Dimension) | medición de dimensión crítica | critical dimension (CD) measurement | Estructuras de prueba tipo peine. |
| die Overlay-Messung | medición de superposición | overlay measurement | Vía REM; shift/magnification/rotation. |
| das Rework | repetición (de litografía) | rework | Único proceso de fabricación repetible libremente. |
| der Lacksteg, -e | puente/línea de resina | resist line/bridge | Puede volverse más angosta por sobreexposición. |
| die Überbelichtung / die Unterbelichtung | sobreexposición / subexposición | overexposure / underexposure | Afectan el ancho final de línea. |
| die Kometenbildung | formación de "cometas" (defecto de resina) | comet defect | Partícula rodeada de resina que fluye alrededor, no la cubre. |
| die Striemenbildung | formación de estrías | streaking defect | Consecuencia visual de la Kometenbildung tras el spin-coating. |
| unterätzen | socavar (por grabado) | to undercut (etch) | Partícula queda rodeada/liberada durante el grabado. |
| die Kerbe, -n | muesca/marca de orientación | notch | Se fresa en el lingote para orientar el wafer (ver también sección 18). |
| die Durchschlagsspannung | tensión de ruptura dieléctrica | dielectric breakdown voltage | Analogía: chispazo de un encendedor piezoeléctrico. |
| der Funkenüberschlag | chispazo/arco eléctrico | spark-over / dielectric breakdown | Ocurre al superar la Durchschlagsspannung. |
| das NDA (Non-Disclosure Agreement) | acuerdo de confidencialidad | non-disclosure agreement (NDA) | Necesario al subcontratar la fabricación de máscaras. |

---

## 23. Grabado (Ätzen)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Ätzen | grabado | etching | Desgaste de superficie, químico y/o físico. |
| der Ätzabtrag | desgaste por grabado | etch removal | Diferencia antes/después del proceso. |
| die Ätzrate, -n | tasa de grabado | etch rate | Desgaste/tiempo. |
| die Selektivität | selectividad | selectivity | Relación de tasas de grabado entre materiales. |
| isotrop / anisotrop | isótropo / anisótropo | isotropic / anisotropic | Independiente / dependiente de la dirección cristalina. |
| der Anisotropiefaktor | factor de anisotropía | anisotropy factor | A = 1 − R_L/R_V. |
| das Nassätzen | grabado húmedo | wet etching | Límite práctico ~0,5 µm de resolución. |
| das Trockenätzen | grabado seco | dry etching | Químico y/o físico (sputter). |
| das Sputterätzen | grabado por pulverización catódica | sputter etching | Físico, baja selectividad, alta anisotropía. |
| das reaktive Ionenätzen (RIE) | grabado por iones reactivos | reactive ion etching (RIE) | Combina componente química y física. |
| der Bosch-Prozess (RIE/DRIE) | proceso Bosch | Bosch process (DRIE) | Ciclos alternos de grabado/pasivación. |
| die Passivierung | pasivación | passivation | Capa protectora temporal en el ciclo Bosch. |
| das Plasma | plasma | plasma | Gas ionizado, conductor eléctrico. |
| die Endpunkterkennung | detección de punto final | endpoint detection | Reflectometría/espectrometría en tiempo real. |
| BHF / DHF (gepuffertes HF) | HF tamponado | buffered HF (BHF/DHF) | Repone iones fluoruro (ver también sección 4). |

---

## 24. Dopaje (Dotierung) — difusión e implantación

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Diffusion (Dotierung) | difusión (dopaje) | diffusion (doping) | Fuente sólida/líquida/gaseosa, alta temperatura. |
| die erschöpfliche Quelle | fuente agotable | exhaustible source | Concentración superficial decreciente. |
| die unerschöpfliche Quelle | fuente inagotable | infinite/inexhaustible source | Concentración superficial constante. |
| der Diffusionskoeffizient | coeficiente de difusión | diffusion coefficient (D) | Depende del tamaño/material del átomo; se obtiene de tablas. |
| die Feststoffdiffusion | difusión desde fuente sólida | solid-source diffusion | Ej. dopaje vía PSG. |
| die Feststofflöslichkeit | solubilidad en estado sólido | solid solubility | Límite máximo de concentración de dopante en la red. |
| die Vorbelegung / Pre-Deposition | predeposición | pre-deposition | Etapa donde se satura la concentración superficial de dopante. |
| das B₂H₆ (Diboran) | diborano | diborane | Fuente gaseosa de boro, tóxico/inflamable. |
| das PH₃ (Monophosphan) | fosfina | phosphine | Fuente gaseosa de fósforo. |
| das POCl₃ (Phosphoroxychlorid) | oxicloruro de fósforo | phosphorus oxychloride (POCl₃) | Fuente líquida/vapor de fósforo. |
| das Phosphorpentoxid (P₂O₅) | pentóxido de fósforo | phosphorus pentoxide (P₂O₅) | Producto intermedio de la reacción del POCl₃. |
| das Phosphorsilikatglas (PSG) / Bor-/Phosphorsilikatglas | vidrio de silicato de fósforo/boro | boro-/phosphosilicate glass (PSG/BSG) | Fuente sólida de dopaje formada sobre el wafer. |
| das BBr₃ (Bortribromid) | tribromuro de boro | boron tribromide (BBr₃) | Fuente líquida de boro. |
| die Implantation (Ionenimplantation) | implantación (iónica) | ion implantation | Física, alto voltaje, en vacío. |
| der Massenseparator, -en | separador de masas | mass separator | Campo electromagnético filtra iones por masa. |
| das Channeling (Implantation) | canalización | channeling | Penetración excesiva de iones por buena alineación de planos cristalinos. |
| das Streuoxid, -e | óxido de dispersión | scatter oxide | Dispersa iones antes de entrar, evita channeling. |
| die Strahlenschäden (Kristallgitter) | daños por radiación (red cristalina) | radiation/lattice damage | Requiere RTA posterior para reparar. |
| Mittelstrom-/Hochstrom-/Hochenergie-Implanter | implantador de corriente media/alta/alta energía | medium current / high current / high energy implanter | [A CONFIRMAR diferencia exacta entre los tres]. |

---

## 25. Deposición (Abscheidung) — CVD y PVD

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Abscheidung | deposición | deposition | Material 100% aportado desde fuera (vs. Aufwachsen). |
| die CVD (chemische Gasphasenabscheidung) | CVD (deposición química en fase vapor) | chemical vapor deposition (CVD) | Reacción de gases sobre superficie caliente. |
| homogene Reaktion | reacción homogénea | homogeneous reaction | Ocurre en fase gas (no deseada en CVD). |
| heterogene Reaktion | reacción heterogénea | heterogeneous reaction | Ocurre en la superficie (deseada en CVD). |
| das Schauerhead, -s | cabezal difusor ("ducha" de gas) | showerhead | Dirige el flujo de gas hacia la oblea. |
| das Silan (SiH₄) | silano | silane | Precursor de Si₃N₄, SiO₂, etc. |
| das Wolframhexafluorid (WF₆) | hexafluoruro de wolframio | tungsten hexafluoride | Precursor de W metálico por CVD. |
| die PVD (physikalische Gasphasenabscheidung) | PVD (deposición física en fase vapor) | physical vapor deposition (PVD) | Aufdampfen/Sputtern. |
| das Aufdampfen | evaporación (térmica) | (thermal) evaporation | Metal se calienta hasta el punto de ebullición. |
| der Schiffchenverdampfer, - | evaporador de barquilla | boat evaporator | Método histórico, poco reproducible. |
| der Elektronenstrahlverdampfer, - | evaporador de haz de electrones | electron-beam evaporator | Estándar actual para evaporación. |
| der Tiegel, - | crisol | crucible | Contiene el metal a evaporar. |
| die Dampfkeule, -n | nube/pluma de vapor metálico | vapor plume | Forma de "kugelausschnitt" (sector esférico), no semiesfera. |
| das Planetengetriebe, - | engranaje planetario | planetary gear | Rotación adicional de la oblea sobre su eje durante evaporación. |
| der tote Winkel | zona muerta/ángulo muerto | shadowing / dead zone | Metal no llega bajo el saliente de resina. |
| das Via-Stacking | apilamiento de vías | via stacking | Contactos apilados entre niveles metálicos. |
| das Sputtern (Kathodenzerstäubung) | sputtering / pulverización catódica | sputtering | Iones de argón arrancan átomos del target. |
| das Target, -s | blanco (de sputtering) | (sputter) target | Material que se pulveriza (= cátodo). |
| die mittlere freie Weglänge | recorrido/camino libre medio | mean free path | Debe ser larga para que el metal llegue a la oblea (ver también sección 30, vacío). |
| das DC-Sputtern | sputtering de corriente continua | DC sputtering | Solo para targets conductores. |
| das RF-Sputtern (Wechselspannung) | sputtering de radiofrecuencia | RF sputtering | Necesario para targets aislantes. |
| das Magnetron | magnetrón | magnetron | Imán en anillo tras el cátodo; aumenta la tasa de sputtering localmente. |
| die Race Tracks / der Racetrack / Erosionsgraben | pistas de desgaste del target / zanja de erosión | race tracks (target erosion pattern) | Desgaste anular, riesgo de perforación. |
| die Verweilzeit | tiempo de permanencia (de electrones en el plasma) | residence/dwell time | Relevante en el diseño del magnetrón. |
| der Koppelkondensator, -en | condensador de acoplamiento | coupling capacitor | Necesario con targets conductores en RF-Sputtern. |
| die Biasspannung | voltaje de polarización (bias) | bias voltage | Se acumula por electrones atrapados en el target. |
| das reaktive Sputtern | sputtering reactivo | reactive sputtering | Gas de grabado retira átomos mal colocados. |
| das Ionenstrahl-/Atomstrahlsputtern | sputtering por haz de iones/átomos | ion-beam / atom-beam sputtering | Alta precisión, ej. máscaras de cromo. |
| die Abscheiderate (vs. Sputterrate) | tasa de depósito (vs. tasa de arranque) | deposition rate (vs. sputter/etch rate) | "Sputterrate" suele referirse en la práctica a la de depósito. |
| der Lift-off-Prozess | proceso de lift-off (despegue) | lift-off process | Socavado de resina + disolvente levanta el metal sobrante. |
| der Unterschnitt, -e | socavado (perfil de resina) | undercut (resist profile) | Ángulo ~45°; clave para el lift-off (requiere resina negativa). |

---

## 26. Metalización y mecanismos de falla

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Aluminiumspiking | picos de aluminio (spiking) | aluminum spiking | Interdifusión Al-Si, cortocircuita uniones p-n. |
| die Austauschdiffusion | interdifusión / difusión de intercambio | mutual/exchange diffusion | Al y Si difunden mutuamente. |
| das Aluminium-Silizium-Target (~1% Si) | target de aluminio-silicio (~1% Si) | Al-Si target (~1% Si) | Predopaje para evitar spiking en contactos. |
| die Elektronenmigration / Elektromigration | electromigración | electromigration | Alta densidad de corriente arrastra átomos metálicos. |
| das Hillock-Wachstum | crecimiento de montículos (hillocks) | hillock growth | Material desplazado se acumula, deforma capas superiores. |
| der Ausdehnungskoeffizient | coeficiente de dilatación (térmica) | (thermal) expansion coefficient | Ajustable en SiO₂ vía oxidación seca/húmeda. |
| die schlechte Kantenabdeckung | mala cobertura de bordes/escalones | poor step coverage | Típico del sputtering (deposición direccional). |
| die Hochdruckbehandlung (Reflow) | tratamiento de alta presión / reflujo | high-pressure reflow | ~700 bar N₂, rellena huecos con Al blando. |
| das Spin-On-Dotierung | dopaje spin-on | spin-on dopant (SOD) | Fuente líquida de dopaje, altamente dopada. |
| die Galvanik | galvanoplastia / electrodeposición | electroplating | Ej. "Aufkupfern" en placas de circuito impreso. |

## 27. CMP (planarización química-mecánica)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das CMP (chemisch-mechanisches Planarisieren) | CMP (planarización química-mecánica) | chemical-mechanical planarization (CMP) | Combina ataque químico + abrasión mecánica. |
| der Damaszen-Prozess | proceso Damasceno | damascene process | Estructuración indirecta vía relleno + pulido. |
| die Poliermatte, -n | paño/manta de pulido | polishing pad | No es papel de lija. |
| der Conditioner, - | acondicionador (del paño de pulido) | pad conditioner | Mantiene el paño uniformemente desgastado. |
| das Time-/Blind-Polish | pulido por tiempo / "a ciegas" | time-based (blind) polish | Cuando no se detecta bien el punto final. |
| das Dishing | hundimiento (dishing) | dishing | Metal más blando se sobre-pule frente al aislante. |
| die Erosion (CMP) | erosión (CMP) | erosion | Dishing extremo, fallo irreparable. |

## 28. Técnicas de medición de proceso (Messtechnik)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Prozessmesstechnik | metrología de proceso | in-line/process metrology | Partículas, anchos, espesores, durante el proceso. |
| die Wafermesstechnik | metrología de oblea | wafer (electrical) test | Funcionalidad del chip, al final (backend). |
| die Schwellspannung | tensión umbral | threshold voltage | Ej. diodo de Si: 0,7 V. |
| die Fremdstoffkonzentration | concentración de contaminantes | contamination/impurity concentration | Medida disolviendo el chip en ácido. |
| der Master-Die / Left Die | die maestro / de referencia | master/reference die | Imagen de comparación en control de defectos. |
| die Interferometrie | interferometría | interferometry | Requiere conocer el material (índice de refracción). |
| die Ellipsometrie | elipsometría | ellipsometry | Mide cambio de polarización; no requiere conocer el material. |
| der Polarisator, -en | polarizador | polarizer | Limita la luz a un plano de vibración. |
| die Vier-Spitzen-Messung | medición de cuatro puntas | four-point probe measurement | Elimina resistencia de contacto y de cable. |
| der Flächenwiderstand | resistencia de capa (por área) | sheet resistance | Se usa para calcular espesor de capa conductora. |
| die Tiefenschärfe | profundidad de campo | depth of field | REM: varias capas enfocadas a la vez. |
| die Nadelkarte, -n | tarjeta de agujas | probe card | Contacta simultáneamente los pads de prueba. |
| der Good Die / Bad Die | die bueno / die malo | good die / bad die | Clasificación tras el test eléctrico. |

## 29. Backend (ensamblaje y empaquetado)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Rückseitenschleifen | adelgazamiento/rectificado de cara posterior | backgrinding (wafer thinning) | Reduce el grosor al mínimo activo necesario. |
| das Bluetape | cinta azul (dicing tape) | blue/dicing tape | Se estira para separar los chips tras el serrado. |
| das Wire Bonding (Drahtbonden) | conexión por hilo (wire bonding) | wire bonding | Reibschweißverfahren (soldadura por fricción). |
| das Ultraschallbonden (US) | bonding por ultrasonidos | ultrasonic (US) bonding | Cabezal plano, sin fundir el hilo, dirección única. |
| das Thermosonic-Bonden | bonding termosónico | thermosonic bonding | Bola de oro fundida + presión, libertad direccional 360°. |
| der Pull-Test | ensayo de tracción | pull test | Ideal: rotura en el centro del lazo, no en el pad. |
| der Shear-Test | ensayo de cizalladura | shear test | Evalúa adherencia del pad/bondstelle. |
| das C4-Verfahren (Flipchip) | proceso C4 / flip-chip | C4 (Controlled Collapse Chip Connection) | Todos los contactos en una cara, bolitas de soldadura. |
| der Underfill | adhesivo de relleno (underfill) | underfill | Estabiliza mecánicamente el flip-chip. |
| das Substrat, -e | sustrato (mini placa intermedia) | substrate (interposer-like) | Agrupa contactos antes de la placa final. |
| das Chipgehäuse, - | encapsulado del chip | chip package | Protección mecánica, térmica y química. |
| die Voralterung (Burn-in) | pre-envejecimiento / burn-in | burn-in | Ciclos térmicos extremos simulan vida útil. |
| der Reflow-Ofen | horno de reflujo | reflow oven | Soldadura de componentes SMD. |

---

## 30. Técnica de vacío (Vakuumtechnik)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Vakuum | vacío | vacuum | Del latín vacuus = vacío/libre. |
| der Unterdruck | presión negativa / depresión | negative pressure / vacuum | Opuesto de Überdruck. |
| der Überdruck | sobrepresión | overpressure | Ej.: sistemas de aire comprimido. |
| der Rezipient, die Rezipienten | recipiente/cámara de vacío | vessel / chamber (recipient) | Sinónimo técnico de Kammer/Behälter. |
| der Atmosphärendruck | presión atmosférica | atmospheric pressure | ≈ 1013 mbar = 1 bar. |
| das Torr / das Millibar (mbar) | Torr / milibar | Torr / millibar | 1 Torr ≈ 1 mbar; Torr en desuso oficial en Europa desde los 70. |
| das Quecksilberbarometer | barómetro de mercurio | mercury barometer | Inventado por Torricelli. |
| das Grobvakuum / Feinvakuum / Hochvakuum (HV) / Ultrahochvakuum (UHV) | vacío grueso / fino / alto / ultra alto | rough / medium-fine / high / ultra-high vacuum | Grob hasta 1 mbar; Fein hasta 10⁻³; HV hasta 10⁻⁷; UHV por debajo. |
| die Teilchenanzahldichte | densidad de partículas (numérica) | particle number density | Moléculas de gas por unidad de volumen a una presión dada. |
| die mittlere freie Weglänge | camino libre medio | mean free path | Distancia recorrida por una molécula antes de chocar con otra. |
| die Kontinuumströmung / Knudsenströmung / molekulare Strömung | flujo continuo / de Knudsen / molecular | continuum / Knudsen / molecular flow | Continuum: vacío grueso. Knudsen: transición. Molecular: alto vacío. |
| die Vakuumpumpe, -n | bomba de vacío | vacuum pump | — |
| die Gastransferpumpe | bomba de transferencia de gas | gas transfer pump | Expulsa el gas hacia afuera. |
| die gasbindende Vakuumpumpe | bomba de vacío que retiene el gas | gas-binding / capture pump | El gas queda atrapado dentro de la bomba. |
| die Verdrängervakuumpumpe | bomba de desplazamiento | positive displacement pump | Crea un espacio que se agranda y luego se comprime. |
| die kinetische Vakuumpumpe | bomba cinética | kinetic pump | Acelera las moléculas con alta energía. |
| die Vorvakuumpumpe / Hochvakuumpumpe | bomba de prevacío/respaldo / bomba de alto vacío | backing/roughing pump / high vacuum pump | La de prevacío siempre es necesaria antes de la de alto vacío. |
| die Hubkolbenpumpe | bomba de pistón alternativo | piston pump / reciprocating pump | Ejemplo más simple del principio de desplazamiento. |
| die Drehschieberpumpe | bomba rotativa de paletas | rotary vane pump | Usada como bomba de prevacío; trabaja con aceite. |
| das Gasballastventil | válvula de lastre de gas | gas ballast valve | Evita que la humedad se condense y se mezcle con el aceite. |
| der Ölabscheider | separador de aceite | oil mist separator | Retira restos de aceite del aire de escape. |
| die Wälzkolbenpumpe | bomba de lóbulos (Roots) | Roots pump / lobe pump | Dos rotores en forma de "8" que giran en direcciones opuestas. |
| die Kreiskolbenpumpe | bomba de pistón rotativo (tipo Wankel) | rotary piston pump | Comparada con el motor Wankel. |
| die Turbomolekularpumpe | bomba turbomolecular | turbomolecular pump | Rotor de aspas a 60.000–100.000 rpm; nunca arrancar desde presión atmosférica. |
| das Magnetlager | cojinete magnético | magnetic bearing | Sin contacto físico → desgaste mínimo. |
| die Schleuse, -n (Vakuum) | esclusa de vacío | load lock | Permite mover obleas sin romper el vacío principal. |
| der Pufferraum / Puffer | precámara / buffer | buffer chamber / pre-chamber | También llamado "Pre-Chamber". |
| die Ionenzerstäuberpumpe (Ionen-Getter-Pumpe) | bomba iónica de pulverización (getter) | ion getter pump / sputter-ion pump | Usa titanio como material de sacrificio; casi sin desgaste. |
| die Kryopumpe | criobomba | cryopump | Trabaja por debajo de -270 °C, con circuito de helio. |
| die Leckrate | tasa de fuga | leak rate | Se calcula como ΔP × V / Δt. |
| die Druckanstiegsmessung | medición de subida de presión | pressure rise test | Método estándar de control de estanqueidad. |
| der Bilanzraum, -räume [A CONFIRMAR] | tramo / espacio de balance del sistema | test volume / segment | Sección delimitada por válvulas para medir su propia tasa de fuga. |
| der Helium-Lecktester | detector de fugas por helio | helium leak detector | Método estándar en la industria de semiconductores. |
| die Sprühpistole | pistola pulverizadora | spray gun | Para aplicar helio de forma puntual. |
| die Schnüffelsonde | sonda rastreadora (de fugas) | sniffer probe | Alternativa: inundar con helio y rastrear con sonda. |
| die Abpumpkurve | curva de vaciado | pump-down curve | Presión vs. tiempo, en papel logarítmico. |
| das Membranvakuummeter / kapazitive Membranvakuummeter | manómetro de membrana (mecánico / capacitivo) | diaphragm gauge / capacitance manometer | Mecánico: hasta ≈1 mbar. Capacitivo: hasta ≈10⁻⁵ mbar, independiente del gas. |
| das Wärmeleitvakuummeter (Pirani) | manómetro de conductividad térmica (Pirani) | thermal conductivity (Pirani) gauge | Depende del gas; usa un puente de Wheatstone. |
| das Glühkathoden-/Kaltkathoden-Ionisationsvakuummeter | manómetro de ionización de cátodo caliente / frío | hot/cold cathode ionization gauge | Ambos dependen del gas; el de cátodo caliente es el más preciso en vacío profundo. |
| gasartabhängig / gasartunabhängig | dependiente / independiente del tipo de gas | gas-species dependent / independent | — |
| ausheizen | desgasificar por calentamiento (hornear la cámara) | bakeout | Libera moléculas adheridas a las superficies. |
| die Wheatstonesche Brücke | puente de Wheatstone | Wheatstone bridge | Circuito usado en el Pirani para medir cambios de resistencia. |

---

## 31. [A CONFIRMAR] — términos y valores pendientes (consolidado, deduplicado)

- **Fragmento inicial ininteligible / nombres propios**: "Belacker" (¿zona o equipo?); "Metrix" (¿modelo de cabina?); "MR25" (¿modelo de cabina vertical?); modo de transporte "beithinig"; "über den Lift" (¿lift-off?); nombres de sede "Finien"/"Sensor Berlin"; "Tellanlage" (¿TEL-Anlage / Tokyo Electron?).
- **der Zangwandler**: pinza amperimétrica (clamp ammeter); término exacto en alemán no verificado con certeza en ningún audio.
- **Umbrales de tensión CAT3/CAT4**: cifras contradictorias entre sesiones de electrotécnica (600V/1000V intercambiados).
- **Material NTC "Titanium O2/O3"**: el propio instructor dijo no estar seguro; probablemente óxido de titanio u otro óxido cerámico.
- **Material del LED blanco**: "GaN"/"InGaN" mencionado con vacilación por el instructor.
- **Resistividad específica del cobre**: el audio dice "0,070 Ω·mm²/m", pero el valor estándar es ≈0,0178 — posible error de transcripción.
- **Fórmula exacta de la fase (φ = ωt + π/2)**: confirmar signo exacto contra el Tabellenbuch.
- **Material semiconductor "In N"**: probablemente Indiumnitrid (InN), no confirmado con certeza total.
- **Valor de banda prohibida (band gap) para Nichtleiter/aislantes**: valores contradictorios entre sesiones (a veces "<0,08 eV", lo cual contradice la física estándar).
- **Tetracen/Pentacen**: ortografía exacta confirmada por diapositiva, pero el audio decía algo como "Fentasen/Tetrazen".
- **Mecanismo exacto del platino como barrera de difusión para el oro**: el propio docente indicó no saberlo con certeza.
- **Ángulo exacto del grabado anisótropo con KOH**: se mencionó tanto 54,7° (valor estándar para (111) sobre oblea (100)) como "63 grados" — posible error de transcripción o del propio docente.
- **Concentración máxima exacta de dopante (B/P) que puede absorber el silicio**: el docente no dio cifras exactas.
- **Tamaño/capacidad de la nueva planta de Jenoptik en Dresde (2025)**: desconocido por el docente.
- **Diferencia exacta entre implantador de Mittelstrom, Hochstrom y Hochenergie**: no precisada.
- **Destino de los subproductos de las fuentes de difusión** (cloro del POCl₃, bromuro del BBr₃): no explicado.
- **Función exacta del oxígeno adicional en diagramas de difusión con POCl₃**: no aclarada.
- **Mecanismo exacto por el que los iones hidroxilo permanecen en la superficie tras el prebake**: no aclarado.
- **Rendimiento energético de un filamento de wolframio incandescente**: citado como ~90–95%, cifra no del todo clara.
- **Composición química exacta de la capa antirreflejante (ARC)**: el profesor no la precisó.
- **Espesor de resina residual, pregunta 14 del examen**: ¿50 nm o 250 nm? La solución modelo usa 250 nm de forma consistente.
- **Orden exacto de pasos en difusión con PSG** (oxidación fina antes o después de introducir POCl₃): presentado como suposición, no confirmado.
- **Si el bromo difunde de forma medible en silicio durante la difusión de boro con BBr₃**: no confirmado.
- **Técnica exacta de medición de espesor de capa en el laboratorio**: ¿reflectometría o espectrometría? El profesor dudó en clase.
- **Ancho de estructura (línea) actual usado en el laboratorio de prácticas**: ~100 nm, sin confirmar.
- **der Bilanzraum**: término en inglés no confirmado ("balance volume" o "test volume").
- **DIN 28400**: norma DIN de terminología de vacío mencionada, número exacto no escuchado con claridad.
- **"Nam Research"** (fabricante de equipos de vacío mencionado por el instructor): grafía/nombre exacto no verificado.

## 32. Puntos poco claros de la clase (ambigüedades conceptuales del profesor, no de transcripción)

- El valor de banda prohibida dado para Nichtleiter ("menos de 0,08 eV") contradice la física estándar; probablemente el instructor se refería a los conductores (banda casi nula).
- Discrepancia entre U_total medida y U_R+U_L en el circuito serie RL, no resuelta en vivo (posible resistencia interna de fuente/amperímetro no considerada).
- El factor de calidad (Q) y las frecuencias de corte se mencionaron pero el instructor aclaró que no entran en el examen.
- El docente reconoció desconocer en detalle la aplicación de semiconductores orgánicos más allá de pantallas flexibles (ej. si se pueden fabricar circuitos integrados sobre ellos).
- Discusión no cerrada del todo sobre si el ángulo de grabado anisótropo cambia "durante" el proceso o si queda fijado solo por la orientación cristalina del lingote (el docente aclaró que es esto último, pero hubo confusión inicial).
- El ángulo exacto del "unterätzen" isotrópico bajo la resina no quedó cuantificado (solo cualitativo).
- La explicación de por qué el boro/fósforo no se oxidan antes que el silicio quedó parcialmente especulativa.
- El profesor reconoció no saber con precisión de qué compuestos químicos está hecha una capa antirreflejante típica en litografía.
- No quedó claro si el CVD a presión atmosférica (APCVD) permite o no epitaxia; el profesor se mostró seguro de que no, pero sin mayor justificación técnica.
- No se dio una explicación cuantitativa firme de por qué la tasa de fuga calculada para todo el sistema de vacío fue ~3 veces más alta que la tasa medida en el único punto de fuga confirmado.
- No quedó claro por qué, tras cerrar la primera válvula de un circuito de vacío, la presión subió mucho más rápido de lo esperado (interpretado como indicio temprano de fuga, sin confirmación explícita).

---

## 33. Subtemas del temario aún no cubiertos (según lo procesado hasta el 17 jul 2026)

- Alineación de máscaras en detalle (más allá de lo tocado en litografía general).
- CO2 snow jet (mencionado en el temario original, no cubierto en ninguna transcripción hasta la fecha).
- Cálculos de sedimentación de partículas y tiempo de recorrido (aparecen en el Test Reinraumkurs resuelto, conviene practicarlos aparte).
- Yield/test más allá de Good Die/Bad Die (mencionado como pendiente en el material del 13 jul).

---

## 34. Elementos químicos relevantes (nombre alemán, número atómico y valencia)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Silizium | silicio | silicon (Si) | Z=14, grupo IV, valencia 4. Semiconductor base de toda la industria. |
| der Sauerstoff | oxígeno | oxygen (O) | Z=8, valencia 2. Oxidación térmica, SiO₂. |
| der Wasserstoff | hidrógeno | hydrogen (H) | Z=1, valencia 1. Knallgas (H₂/O₂), oxidación húmeda. |
| das Bor | boro | boron (B) | Z=5, grupo III, valencia 3. Dopante aceptor (tipo p); B₂H₆, BBr₃. |
| der Phosphor | fósforo | phosphorus (P) | Z=15, grupo V, valencia 3/5. Dopante donador (tipo n); PH₃, POCl₃. |
| das Aluminium | aluminio | aluminum (Al) | Z=13, grupo III, valencia 3. Metalización clásica; spiking con Si. |
| das Gold | oro | gold (Au) | Z=79, valencia 1/3. Wire bonding (bolita de oro), requiere barrera de Pt. |
| das Platin | platino | platinum (Pt) | Z=78, valencia 2/4. Barrera de difusión para el oro. |
| das Wolfram | wolframio / tungsteno | tungsten (W) | Z=74, valencia hasta 6 (en WF₆). Relleno de contactos/vías por CVD. |
| das Titan | titanio | titanium (Ti) | Z=22, valencia hasta 4 (en TiO₂). Posible material NTC [A CONFIRMAR]. |
| der Stickstoff | nitrógeno | nitrogen (N) | Z=7, valencia 3/5. Gas inerte de proceso (bubbler, reflow a alta presión). |
| das Kupfer | cobre | copper (Cu) | Z=29, valencia 1/2. Metalización avanzada (Damaszen-Prozess), electrodeposición. |
| das Chrom | cromo | chromium (Cr) | Z=24, valencia 2/3/6. Recubrimiento de máscaras litográficas (Maskenblank). |
| das Gallium | galio | gallium (Ga) | Z=31, grupo III, valencia 3. GaAs, GaN/InGaN (LED). |
| das Arsen | arsénico | arsenic (As) | Z=33, grupo V, valencia 3/5. Tóxico; componente del GaAs. |
| das Zink | zinc | zinc (Zn) | Z=30, valencia 2. Óxido de zinc como material de varistor. |
| der Kohlenstoff | carbono | carbon (C) | Z=6, valencia 4. Reducción carbotérmica del cuarzo → silicio bruto; SiC. |
| das Quecksilber | mercurio | mercury (Hg) | Z=80, valencia 1/2. Barómetro de mercurio (histórico, Torricelli). |
| das Helium | helio | helium (He) | Z=2, valencia 0 (noble). Detección de fugas de vacío. |
| das Tantal | tantalio | tantalum (Ta) | Z=73, valencia 5. Barrera de difusión para el cobre. |
| das Indium | indio | indium (In) | Z=49, grupo III, valencia 3. InGaN, posible InN [A CONFIRMAR]. |
| das Argon | argón | argon (Ar) | Z=18, valencia 0 (noble). Gas de sputtering (bombardeo iónico). |
| das Chlor | cloro | chlorine (Cl) | Z=17, valencia -1 (común). Subproducto de la difusión con POCl₃. |
| das Fluor | flúor | fluorine (F) | Z=9, valencia -1 (común). HF/BOE para grabado húmedo de óxido. |

---

## 35. Práctica (HP) — Horno de oxidación: equipo y operación (20 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| der Beladungstisch, -e | mesa de carga | loading table | Se acopla frente a la puerta abierta del horno. |
| der Endlageschalter, - | interruptor de fin de carrera (de puerta) | door limit switch / interlock | Debe estar "abierto" para que la puerta pueda abrirse; si está "cerrado" bloquea la apertura. |
| die Ladezone / Mitte / Gaszone | zona de carga / zona media / zona de gas | load zone / center zone / gas zone | Las tres zonas de temperatura del horno tubular. |
| der Beladungsvorgang | proceso de carga | loading process | — |
| der Trägerarm, -e | brazo portador | carrier arm | Sirve para deslizar el Glas Carrier dentro/fuera del tubo. |
| der Führungsring, -e | anillo guía (de vidrio) | (glass) guide ring | Frágil; se rompe con movimientos bruscos del gancho. |
| das Rudolph-/Filmetrics-Schichtdickenmessgerät | medidor de espesor de capa Rudolph/Filmetrics | Rudolph/Filmetrics film thickness gauge | Sustituye al antiguo "Rudolph"; ~15.000€, basado en reflectometría/interferometría simulada. Grafía correcta "Filmetrics" (no "Filmmetrics"), confirmada por la guía oficial del 21 jul. |

## 36. Práctica (HP) — Belackung, HMDS y spin coating: equipo y variables (20–21 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| der Exsikkator, -en | exsicador / desecador | desiccator | Cúpula de vidrio donde se satura el aire con vapor de HMDS. |
| der Flammpunkt | punto de inflamación | flash point | HMDS: 17°C — bajo, por eso requiere precauciones (aunque aquí sin riesgo por sistema abierto sin chispas). |
| der Haftvermittler, - | promotor de adherencia | adhesion promoter | HMDS descrito así en el objetivo del Versuch 1. |
| die Hydrophilität | hidrofilicidad | hydrophilicity | Sustantivo correspondiente a *hydrophil* (adjetivo ya cubierto en sección 21). |
| die Hydrophobilität / Hydrophobizität | hidrofobicidad | hydrophobicity | Sustantivo correspondiente a *hydrophob* (sección 21). |
| der Benetzungswinkel, - | ángulo de mojado (de contacto) | contact/wetting angle | Sinónimo funcional de *Randwinkel* (sección 21); término usado en la guía de práctica del 21 jul. |
| die CEE 100 | equipo de recubrimiento por centrifugado (modelo) | spin coater (model CEE 100) | Beschichter usado en el Praktikum. |
| der AR-P 3120 | fotorresina positiva (modelo/marca) | positive photoresist (AR-P 3120) | Lack usado en Versuch 2. |
| die TEPLA 200 (Anlage) | equipo de plasma (modelo) | plasma asher (model TEPLA 200) | Usado para eliminar el HMDS por veraschen con O₂. |
| der Bearbeitungscarrier, - | carrier de proceso | processing carrier | Sostiene el wafer dentro del recipiente de vidrio durante la exposición a HMDS. |
| der Handbelacker, - / "Polos" | aplicador manual de resina (nombre de equipo: Polos) | manual spin coater/applicator (device name: Polos) | "Polos" es el nombre propio del aparato, no una abreviatura — confirmado por Mely. |
| der Handentlacker "Polos" | removedor manual de resina (mismo equipo: Polos) | manual resist stripper (same device: Polos) | Mismo aparato "Polos" reutilizado con disolvente (Aceton) en vez de resina. |
| der halbautomatische Lacker, - | aplicador semiautomático | semi-automatic resist coater | Dosificación automática, colocación manual de la oblea. |
| die Dosierspitze, -n [A CONFIRMAR ortografía, audio: "Usierspitze"] | boquilla/punta dosificadora | dispensing tip/nozzle | Cánula plástica gruesa; solo el instructor la cambia. Posiblemente relacionada con "Dispensnadel" (21 jul) — mismo tipo de componente descrito en dos prácticas distintas. |
| die Dispensnadel, -n | aguja dosificadora | dispense needle | Se inserta en el Beschichter para aplicar la resina; solo el instructor la cambia. |
| die Dispensabdeckung, -en | tapa/cubierta de la dosificación | dispense cover/cap | Se retira antes de instalar la Dispensnadel. |
| das Belackungsprogramm, -e | programa de recubrimiento (recipe) | coating recipe/program | "Programm 0" en el protocolo. |
| die Drehzahl, -en | velocidad de giro (rpm) | spin speed (RPM) | Variable del Versuch 1 (2000–6000 U/min). |
| die Schleuderzeit, -en | tiempo de centrifugado | spin time | Variable del Versuch 2 (10–60 seg). |
| die Wafermap, -s | mapa de oblea | wafer map | Representación espacial del espesor en 13 puntos, vista 3D y vista de pájaro (Vogelperspektive). |
| der Chuck, -s | mandril de vacío (portaobleas del spinner) | (vacuum) chuck | Sostiene el wafer centrado durante el spin-coating. |
| die Saugpinzette, -n [A CONFIRMAR, audio: "Zaubpinzette"] | pinza de succión | vacuum tweezers (spring type) | Con contrapeso, distinta de la pinza de vacío por tubo. |
| die Positionierhilfe / Positionierungshilfe, -n | ayuda de posicionamiento | positioning aid | Brazo con bisagra sin resorte fijo para centrar la oblea sobre el chuck; grafía documentada de ambas formas (20 y 21 jul). |
| ACT TEMP (Taste) | botón de temperatura actual | actual temperature button | En la hotplate, muestra la temperatura real de la placa (vs. temperatura objetivo). |
| die 25%-Heizung (Taste) | modo de calentamiento al 25% | 25% heating mode | Evita sobrepaso (Überschwingen) de temperatura al calentar. |
| die Zwischenauswertung, -en | evaluación intermedia | intermediate evaluation | Sección del protocolo donde se grafican/interpretan resultados parciales. |
| die Gesamtauswertung | evaluación global/final | overall evaluation | Sección final del protocolo con preguntas de síntesis. |

## 37. Práctica (HP) — Litografía de contacto: MA106 (20 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| die MA106 | equipo de exposición por contacto (modelo) | contact aligner (model MA106) | Usado en el Praktikum al no funcionar el stepper ni la MA25. |
| die Überdeckungsstruktur, -en | estructura de superposición / overlay | overlay structure | Mide desalineación X/Y entre máscara nueva y capa previa. |
| die Kantenverschiebung | desplazamiento de borde | edge shift | Una de las magnitudes que revela la estructura de overlay. |
| der Testchip, -s | chip de prueba | test chip | Área sin circuito funcional, solo estructuras de justaje/resolución. |
| die Justagemarke, -n | marca de alineación | alignment mark | Cruces, triángulos, cuadrados grabados en la máscara base. |

## 38. Práctica (HP) — Grabado en plasma de oxígeno (20 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| das Radikal, -e (chem.) | radical (químico) | radical | Partícula neutra con electrón desapareado, muy reactiva. |
| der Barrel Etcher / Fassätzer, - | grabador tipo barril | barrel etcher | Cámara tubular con plasma envolvente, usado para veraschen de resina. |
| der Faradaysche Käfig, -e | jaula de Faraday | Faraday cage | Blinda iones/electrones; solo deja pasar radicales neutros hacia el wafer. |
| die Verweilzeit (Gasteilchen) | tiempo de permanencia (partícula de gas, en cámara de grabado) | residence time (gas particle) | A mayor presión, mayor tiempo de permanencia → más isotropía. Mismo término (Verweilzeit) usado en la sección 25 para electrones en el plasma de sputtering — contexto distinto. |
| der Gaswäscher, - | lavador de gases / scrubber | gas scrubber | Quema/neutraliza los gases de escape del proceso. |

## 39. Práctica (HP) — Grabado húmedo con HF: seguridad y operación (20 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| die Hexafluorokieselsäure (H₂SiF₆) | ácido hexafluorosilícico | hexafluorosilicic acid | Producto de la reacción SiO₂ + 6HF. |
| der Fluorwasserstoff | fluoruro de hidrógeno (gas) | hydrogen fluoride (gas) | Distinto de "Flusssäure" (la solución acuosa, sección 4). |
| die Deprotonierung | desprotonación | deprotonation | Parte del mecanismo por el que el O del SiO₂ termina como H₂O. |
| das Kaskadensystem | sistema en cascada (de enjuague) | cascade rinse system | Mínimo dos baños de DI-agua en serie tras el HF. |
| das Calciumgluconat-Gel | gel de gluconato de calcio | calcium gluconate gel | Primeros auxilios estándar para quemaduras por HF; retira iones fluoruro. |

## 40. Práctica (HP) — Sputtering y vacío: equipo (20 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| die CreaMed 300 | equipo de sputtering (modelo) | sputtering tool (model CreaMed 300) | Equipo compacto del Praktikum. |
| das Drosselventil / Butterfly-Ventil, -e | válvula de mariposa / estrangulación | throttle (butterfly) valve | Regula finamente la presión de cámara sin alterar la turbobomba. |
| der Sperrschieber, - | compuerta de corte (total) | gate valve | Protege la turbobomba durante carga/ventilación. |
| der Magdeburger Halbkugelversuch | experimento de los hemisferios de Magdeburgo | Magdeburg hemispheres experiment | Analogía histórica para ilustrar la fuerza del vacío. |

## 41. Práctica (HP) — Mediciones eléctricas: Wafertest y MOSFET (20 jul)

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| der Manipulator, -en | manipulador (estación de puntas) | probe station manipulator | Sostiene y posiciona la oblea bajo las agujas de medición. |
| die Messnadel, -n / der Nadelhalter, - | aguja de medición / portaagujas | probe needle / needle holder | Numeradas, correspondientes a canales en la caja adaptadora. |
| die Adapterbox, -en | caja adaptadora | adapter box | Conecta las agujas a los instrumentos de medición. |
| das LC-Meter, - | medidor LC (inductancia-capacitancia) | LC meter | Usado para medir condensadores. |
| die Schleusenspannung / Arbeitsspannung | tensión de codo / tensión de trabajo | knee voltage / turn-on voltage | Sinónimo de Schwellspannung (sección 28); Si≈0,7V, Ge≈0,2–0,3V. |
| die Ausgangskennlinie, -n | curva característica de salida | output characteristic curve | I_D vs. U_DS para distintos U_GS de un MOSFET. |
| die Transferkennlinie, -n | curva de transferencia | transfer characteristic curve | Segunda curva estándar de caracterización de MOSFET. |
| der Sättigungsbereich | región de saturación | saturation region | Del transistor MOSFET. |
| das Shrink / die Shrink-Variante, -n | variante reducida (de un componente) | shrink variant / device scaling | Mismo diseño fabricado en tamaños sucesivamente menores. |
| die Gate-Source-Spannung (U_GS) | tensión compuerta-fuente | gate-source voltage | — |
| die Drain-Source-Spannung (U_DS) | tensión drenador-fuente | drain-source voltage | — |
| der Drainstrom (I_D) | corriente de drenador | drain current | — |

---

## 42. Elektrotechnik / Digitaltechnik — Grundlagen (21 ago)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Digitaltechnik | técnica digital | digital technology | Contrapuesta a Analogtechnik: solo dos estados (an/aus). |
| das Digitalsignal, -e | señal digital | digital signal | Solo valores 0 y 1, no periódico, solo valores positivos (normalmente). |
| das Analogsignal, -e | señal analógica | analog signal | Continuo, todos los valores posibles entre dos extremos. |
| binär | binario | binary | Bit = binary digit, "cifra de dos valores". |
| das Bit | bit | bit | Binary Digit; unidad mínima de información digital. |
| der Logikpegel, - | nivel lógico | logic level | Valor de tensión asociado a cada estado de señal (0/1). |
| positive Logik | lógica positiva | positive logic | 0 = L (Low, tensión baja/ausente), 1 = H (High, tensión alta/presente). Estándar en la práctica. |
| negative Logik | lógica negativa | negative logic | Asignación invertida: 0 = tensión presente, 1 = tensión ausente. Poco común. |
| der Low-Pegel (L) | nivel bajo | low level (L) | Tensión baja / señal "0" en lógica positiva. |
| der High-Pegel (H) | nivel alto | high level (H) | Tensión alta / señal "1" en lógica positiva. |
| die integrierte Schaltung (IC) | circuito integrado | integrated circuit (IC) | Muchos componentes individuales en una sola carcasa. |
| das DIL-Gehäuse (Dual In-Line) | encapsulado DIL (doble hilera) | dual in-line package (DIP) | Dos hileras de pines enfrentadas; separación estándar 2,54 mm (= 1 pulgada, origen histórico de Bell Labs/EE.UU.). |
| der Pin, -s | pin/terminal | pin | Cada conexión externa de un IC. |
| die Kennmarke, -n | marca de identificación (muesca/punto) | orientation notch/dot | Indica dónde empieza la numeración de pines (siempre pin 1 junto a la marca). |
| das Datenblatt, ¨-er | hoja de datos | datasheet | Fuente para verificar asignación exacta de pines (alimentación, tierra, etc.). |

## 43. Elektrotechnik — Logikfamilien TTL y CMOS

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Logikfamilie, -n | familia lógica | logic family | Grupo de circuitos con el mismo tipo de nivel/tecnología (ej. TTL, CMOS). |
| die TTL (Transistor-Transistor-Logik) | TTL (lógica transistor-transistor) | transistor-transistor logic (TTL) | Construida con transistores bipolares; tensión de alimentación fija +5V ±0,25V DC. |
| das CMOS (komplementäre Metall-Oxid-Halbleiter) | CMOS | complementary metal-oxide semiconductor (CMOS) | Construida con FET (N-Kanal + P-Kanal complementarios); rango de alimentación amplio 3–15V. |
| die Betriebsspannung (UB/UCC) | tensión de alimentación | supply voltage | TTL: 5V fijo. CMOS: 3–15V, típico 5 ó 10V. |
| die Belastbarkeit (des Ausgangs) | capacidad de carga (de la salida) | output drive capability | TTL generalmente más alta que CMOS por su construcción interna. |
| die Arbeitsgeschwindigkeit | velocidad de trabajo | switching speed | CMOS ≈10× más lento que TTL en la comparación de la clase (depende de subfamilia). |
| der Störabstand (Noise Margin) | margen de ruido | noise margin | Diferencia entre el pegel de salida garantizado y el de entrada reconocido; TTL≈0,4V; CMOS a 5V≈1,45V, a 15V≈2,95V. CMOS tiene mayor margen de ruido. |
| der verbotene Bereich | zona prohibida (entre High y Low) | forbidden/undefined region | Rango de tensión donde el nivel lógico no está garantizado. |
| das Und-Glied / UND-Gatter | puerta AND ("Y") | AND gate | — |
| das Standard-TTL (74XX) | TTL estándar (serie 74) | standard TTL (74-series) | Numeración según orden histórico de aparición, no según tipo de función. |
| das Low-Power-TTL (74L) | TTL de baja potencia | low-power TTL (74L) | ~10% del consumo del TTL estándar, pero ~3× más lento. |
| das High-Speed-TTL (74H) | TTL de alta velocidad | high-speed TTL (74H) | 2× más rápido que el estándar, pero 2× más consumo. |
| das Schottky-TTL (74S) | TTL Schottky | Schottky TTL (74S) | Tiempo de conmutación muy bajo, consumo muy alto. Nombrado por Walter Schottky (Bell Labs). |
| das Low-Power-Schottky-TTL (74LS) | TTL Schottky de baja potencia | low-power Schottky TTL (74LS) | Velocidad ≈ estándar, consumo ≈1/5 del estándar; combinación óptima muy usada. |
| die Signallaufzeit, -en | tiempo de propagación de señal | propagation delay | Tiempo que tarda la señal en atravesar una puerta/circuito; del orden de nanosegundos, se acumula al encadenar puertas. |
| der Pull-up-Widerstand, ¨-e | resistencia de pull-up | pull-up resistor | Conectada a UB; asegura nivel High definido cuando la entrada no está forzada a Low. Se usa para adaptar TTL→CMOS. |
| der Pull-down-Widerstand, ¨-e | resistencia de pull-down | pull-down resistor | Conectada a masa; asegura nivel Low definido por defecto. |
| der offene Eingang | entrada abierta / no conectada | floating/open input | TTL: interpretado como High por diseño interno. CMOS: prohibido dejarlo abierto — debe fijarse siempre a H o L. |
| die Pegelanpassung | adaptación de niveles | level shifting | Necesaria al combinar TTL y CMOS con distinta tensión de alimentación. |
| die galvanische Kopplung | acoplamiento galvánico | galvanic coupling | Ventaja de CMOS mencionada frente a TTL en la comparación de propiedades. |
| die Verlustleistung | potencia disipada | power dissipation | CMOS generalmente menor que TTL (salvo alta frecuencia). |
| der Integrationsgrad | grado de integración | integration density | CMOS permite mayor densidad de empaquetado que TTL (construcción por áreas vs. por capas). |

## 44. Elektrotechnik — ESD (Electrostatic Discharge), continuación de EGB (sección 5)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die ESD (Electrostatic Discharge) | ESD (descarga electrostática) | electrostatic discharge (ESD) | Término internacional; equivalente a ESD alemán "elektrostatische Entladung" (sección 5). |
| die Ladungserzeugung | generación de carga (electrostática) | charge generation | Ocurre al frotar/separar dos cuerpos (ej. quitarse un suéter). |
| der Ladungsübertritt | transferencia de carga | charge transfer | Al contacto entre dos cuerpos inicialmente neutros. |
| die Potenzialunterschied, -e | diferencia de potencial | potential difference | Causa del flujo de carga al tocar un cuerpo conductor o tierra. |
| das SEP (Semiconductor ESD Program, Infineon) | programa ESD de Infineon | Semiconductor ESD Program (SEP, Infineon) | Estrategia interna de Infineon: sensibilización + protección interna (diseño) + protección externa. |
| die ESD-Härtung | endurecimiento ESD (del diseño del chip) | ESD hardening (design) | Medidas de diseño interno del circuito para resistir descargas. |
| die ESD-Schutzzone (EPA) | zona de protección ESD | ESD protected area (EPA) | Zona señalizada, acceso solo a personal capacitado y equipado. |
| das Ableitwiderstand-Fenster | rango de resistencia de disipación (piso/mesa) | dissipative resistance range | Ni demasiado bajo (descarga brusca) ni demasiado alto (no disipa) — ver Ableitfähigkeit sección 5. |
| das Handgelenk-Erdungsband | pulsera de puesta a tierra (muñeca) | wrist grounding strap | Se prueba siempre antes de entrar a la zona ESD. |
| der Fingerling, - | dedal antiestático | anti-static finger cot | Usado en casos especiales sobre indicación. |
| das ESD-Label | etiqueta ESD | ESD warning label | Debe quedar visible al abrir el embalaje externo antes de entrar a la zona ESD. |
| das Styropor | poliestireno expandido | expanded polystyrene (styrofoam) | Ejemplo de material altamente cargable a evitar como relleno en zona ESD. |
| der Ionisator, -en | ionizador | ionizer | Neutraliza cargas en materiales aislantes que no se pueden conectar a tierra (ej. en el Reinraum). |
| das Pick-and-Place-Prinzip | principio pick-and-place | pick-and-place principle | Minimiza el deslizamiento de componentes (fuente de carga triboeléctrica) en máquinas modernas de montaje. |
| der ESD-Koordinator, -en | coordinador ESD | ESD coordinator | Rol organizativo dentro de la estrategia de protección de Infineon. |
| die Auslieferung | entrega/despacho (al cliente final) | delivery/shipment | La protección ESD debe cubrir toda la cadena, desde la fabricación de la oblea hasta la entrega. |

## 45. Elektrotechnik — Logikgatter y Boolesche Algebra

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Boolesche Algebra | álgebra booleana | Boolean algebra | Nombrada por George Boole (matemático inglés, 1815–1864); base matemática de la lógica digital. |
| die logische Grundfunktion, -en | función lógica básica | basic logic function | Las tres básicas: UND, ODER, NICHT. |
| das UND-Glied / AND-Gatter | puerta AND | AND gate | Símbolo europeo (IEC/DIN): rectángulo con "&"; símbolo US: forma de "D". Salida 1 solo si todas las entradas son 1. |
| das ODER-Glied / OR-Gatter | puerta OR | OR gate | Símbolo europeo: rectángulo con "≥1". Salida 1 si al menos una entrada es 1. |
| das NICHT-Glied / NOT-Gatter (Inverter) | puerta NOT (inversor) | NOT gate (inverter) | Invierte la señal: 0→1, 1→0. |
| das NAND-Glied | puerta NAND | NAND gate | AND + negación (círculo en la salida); IC 7400 fue el primer circuito estándar TTL de este tipo. |
| das NOR-Glied | puerta NOR | NOR gate | OR + negación. |
| das XOR-Glied (Exklusiv-Oder) | puerta XOR (O exclusivo) | exclusive OR (XOR) | Salida 1 solo si las entradas son distintas entre sí. |
| das XNOR-Glied (Exklusiv-Nicht-Oder) | puerta XNOR (NO-O exclusivo) | exclusive NOR (XNOR) | Salida 1 solo si las entradas son iguales. |
| das Gatter, - | puerta (lógica) | (logic) gate | Un IC lógico suele contener varias puertas del mismo tipo (ej. 4× AND de 2 entradas en un DIL de 14 pines). |
| die Wahrheitstabelle, -n | tabla de verdad | truth table | Lista todas las combinaciones de entrada con su salida correspondiente. |
| das Kommutativgesetz | ley conmutativa | commutative law | A·B = B·A (y análogo para OR); igual que en aritmética. |
| das Assoziativgesetz | ley asociativa | associative law | (A·B)·C = A·(B·C); permite reducir puertas de más de 2 entradas a combinaciones de 2. |
| das De-Morgansche Gesetz (1. und 2.) | leyes de De Morgan (1ª y 2ª) | De Morgan's laws (1st & 2nd) | NAND(A,B) = A̅ OR B̅ ; NOR(A,B) = A̅ AND B̅. Permiten sustituir UND/ODER por combinaciones de NAND/NOR. |
| NAND- und NOR-Glieder als Universalbausteine | puertas NAND/NOR como bloques universales | NAND/NOR as universal gates | Cualquier función lógica (AND, OR, NOT) puede construirse solo con NAND o solo con NOR; ahorra tipos de IC distintos. |
| die Negation | negación | negation | Barra sobre la variable (Querstrich); invierte el valor lógico. |
| der Ablaufplan, ¨-e | diagrama de temporización / flujo | timing diagram / flow chart | Representa la evolución temporal de señales de entrada y salida. |
| die SPS (speicherprogrammierbare Steuerung) | PLC (controlador lógico programable) | programmable logic controller (PLC) | Ej. Siemens S7; implementa la misma lógica booleana de forma programada en vez de con cableado/IC discretos. |

## 46. Elektrotechnik — Zahlensysteme (sistemas numéricos)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Zahlensystem, -e | sistema numérico | number system | Conjunto de símbolos y reglas para representar cantidades. |
| die Basis (eines Zahlensystems) | base (de un sistema numérico) | base/radix | Cantidad de símbolos distintos disponibles (10 en decimal, 2 en binario, 16 en hexadecimal). |
| das Dezimalsystem (Basis 10) | sistema decimal (base 10) | decimal system (base 10) | Origen: los 10 dedos de la mano. |
| das Dualsystem / Binärsystem (Basis 2) | sistema dual/binario (base 2) | binary system (base 2) | Único sistema representable directamente por "corriente sí/no" en un circuito. |
| das Oktalsystem (Basis 8) | sistema octal (base 8) | octal system (base 8) | Usado históricamente para representar números de máquina de forma más compacta que el binario. |
| das Hexadezimalsystem (Basis 16) | sistema hexadecimal (base 16) | hexadecimal system (base 16) | Cifras 0–9 y A–F (A=10 … F=15); estándar para representar código de máquina/memoria. |
| die Potenz, -en | potencia (matemática) | power/exponent | x⁰=1, x¹=x; cada posición de una cifra vale (base)^(posición). |
| der Exponent, -en | exponente | exponent | Indica la posición/potencia de la base. |
| die Ziffer, -n | cifra/dígito | digit | Símbolo individual de un sistema numérico. |
| die Umwandlung (von Zahlensystemen) | conversión (entre sistemas numéricos) | number system conversion | Ej. decimal→binario por divisiones sucesivas entre 2, guardando los restos. |
| der Rest, -e (bei Division) | resto (de una división) | remainder | En la conversión decimal→binario: 0 o 1 según si la división es exacta o no. |
| der Index (als Basis-Kennzeichnung) | subíndice (para indicar la base) | subscript (radix notation) | Ej. 143₁₀ (decimal) vs. 8F₁₆ (hexadecimal); la misma cifra puede significar valores distintos según la base. |
| das Byte, -s | byte | byte | 8 bits. |
| das Kilobyte (KB) | kilobyte | kilobyte (KB) | 2¹⁰ = 1024 bytes (no 1000, por convención binaria). |
| das Megabyte (MB) | megabyte | megabyte (MB) | 2²⁰ = 1.048.576 bytes. |
| das Nibble / Halbbyte [A CONFIRMAR ortografía en audio: "Zitrat"/"Halbbeik"] | nibble / semibyte (4 bits) | nibble | 4 bits = 1 cifra hexadecimal; el audio deformó el término, probablemente "Nibble". |
| die Codierung | codificación | encoding | Representación de caracteres/información como números. |
| der Morsecode | código Morse | Morse code | Ejemplo histórico de codificación binaria (punto/raya). |
| der ASCII-Code (American Standard Code for Information Interchange) | código ASCII | ASCII code | Codificación estándar de caracteres; 7 bits = 127 caracteres (letras, cifras, signos, control); extensión a 8 bits = 256. |
| der Unicode | Unicode | Unicode | Extensión moderna, 16 bits, cubre alfabetos no latinos. |
