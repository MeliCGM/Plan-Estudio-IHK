# TQ2 – Transkription (Deutsch, bereinigt) – Sitzung 2026-08-20

> Themenblock: Elektrotechnik/Transistortechnik – Wiederholung Bipolartransistor, Feldeffekttransistoren
> (JFET, MOSFET), bistabile/monostabile/astabile Kippstufen, NE555, praktischer Aufbau am Steckbrett,
> Gespräch über Ingenieur-/Techniker-Laufbahnen in der Halbleiterindustrie.
> Bereinigt aus Rohtranskript. Persönliche Anekdoten und Nebengespräche sind separat am Ende markiert.

---

## 1. Wiederholung: Bipolartransistor als Schalter

Der bipolare Transistor (gestern behandelt) wurde als Schalter mit Arbeitspunkten besprochen. Wichtig: die
Grenzwerte (Arbeitslinien) dürfen nicht überschritten werden, da Halbleiter wärmeempfindlich sind und sonst
dauerhaft geschädigt werden.

Der NPN-Transistor wird ausschließlich mit Gleichspannung betrieben (nicht mit Wechselspannung), weil die
Polarität am PN-Übergang konstant bleiben muss – in eine Richtung sperrt der Übergang.

**Begriff "bipolar":** Der Transistor braucht einen Potenzialunterschied (zwei verschiedene Potenziale), um
über Basis-Emitter und Basis-Kollektor gesteuert zu werden. Deswegen "bi" = zwei. Beim Feldeffekttransistor
dagegen genügt ein einzelnes Potenzial (unipolar), um den Kanal zu steuern.

## 2. Feldeffekttransistoren – Übersicht

Transistoren gliedern sich in **Bipolartransistoren** (Bipolarer Sperrschicht-Transistor: NPN/PNP – bereits
behandelt) und **unipolare Feldeffekttransistoren (FET)**. Beim FET wird der Kanal durch ein elektrisches Feld
gesteuert, nicht durch einen Stromfluss zur Steuerung.

Zwei Hauptfamilien:
- **Sperrschicht-Feldeffekttransistor (JFET)** – ältester FET-Typ, historisch der erste Feldeffekttransistor,
  heute wenig verwendet.
- **IGFET / MOSFET** (Insulated-Gate FET / Metall-Oxid-Halbleiter-Feldeffekttransistor) – aktuelle
  Standardbauform.

Anschlüsse beim FET: **Gate (G)** = Tor/Steuerung, **Drain (D)** = Abfluss, **Source (S)** = Quelle. Die
Elektronen fließen von Source zum Drain durch den Kanal.

## 3. JFET – Aufbau und Funktion (selbstleitend)

Beim JFET ist im Ruhezustand bereits ein leitfähiger Kanal vorhanden (**selbstleitend**): ohne angelegte
Gate-Spannung leuchtet eine angeschlossene Lampe zwischen Source und Drain sofort.

Analogie des Dozenten (Kino-Vorhang): Solange keine Spannung am Gate anliegt, ist "der Vorhang offen" –
man sieht/leitet alles. Wird eine Spannung angelegt (Sperrrichtung des internen PN-Übergangs), "zieht sich
der Vorhang langsam zu": die Raumladungszone am PN-Übergang breitet sich aus, der Kanal wird enger, die
Leitfähigkeit sinkt. Bei ausreichend hoher Gate-Source-Spannung (**Abschnürspannung U_P**, Pinch-off-Spannung)
ist der Kanal vollständig geschlossen, es fließt kein Strom mehr.

Schichtaufbau: P-dotierter Wafer als Trägermaterial, darauf ein N-Kanal (schwach N-dotiert), darin wieder
stärker N-dotierte Bereiche für Source/Drain-Kontakte. Isolierung durch Siliziumoxid, darüber Aluminium als
Leiterbahn.

Kennlinie: Bei U_GS = 0 V fließt ein hoher Drainstrom; mit steigender (sperrender) U_GS sinkt der Drainstrom,
bis er bei U_GS = U_P (z. B. 4 V im Beispiel) auf null fällt.

Schaltzeichen: eckiger Kreis (kein Kreis mehr wie beim Bipolartransistor), Pfeilrichtung zeigt den Kanaltyp an
(N-Kanal: Pfeil nach innen; P-Kanal: Pfeil nach außen).

## 4. MOSFET – Grundaufbau

**MOSFET = Metall-Oxid-Halbleiter-Feldeffekttransistor.** Früher war die Gate-Elektrode aus Metall (später
Aluminium, ab den 1980ern häufiger Polysilizium; seit ca. 2007 durch neue High-k-Technologien teilweise
wieder Metall). Korrekterer Name wäre eigentlich "MISFET" (Metall-Isolator-Halbleiter), aber "MOSFET" bleibt
die gebräuchliche Bezeichnung.

Anschlüsse: **Drain, Source, Gate**, zusätzlich **Substrat/Bulk (B)** als vierter Anschluss.

Aufbau (Beispiel N-MOS): P-dotiertes Grundsubstrat, darin zwei N-dotierte Zonen (Source, Drain). Auf der
Substratoberfläche zwischen den beiden Zonen liegt eine dünne Oxidschicht, darüber die Metall- bzw.
Gate-Elektrode. Legt man eine positive Spannung zwischen Gate und Substrat an, wandern freie Elektronen im
P-Substrat zur Oxidschicht und bilden dort einen n-leitenden Kanal zwischen Source und Drain (Ladungsträger-
**Anreicherung**). Da G und Substrat durch das Oxid (Nichtleiter) getrennt sind, fließt dabei kein
Gate-Strom – lediglich eine Potenzialdifferenz (elektrisches Feld) wirkt.

## 5. Anreicherungstyp vs. Verarmungstyp; N-Kanal vs. P-Kanal

- **Anreicherungstyp (Enhancement):** Im Ruhezustand ist kein Kanal vorhanden (Transistor sperrt). Erst durch
  Anlegen einer ausreichenden Gate-Spannung wird der Kanal erzeugt (Transistor leitet).
- **Verarmungstyp (Depletion):** Im Ruhezustand ist bereits ein Kanal vorhanden (Transistor leitet). Durch
  Anlegen der Gate-Spannung wird der Kanal abgebaut (Transistor sperrt).

Beide Typen existieren als N-Kanal- und P-Kanal-Variante → insgesamt vier MOSFET-Grundtypen. Beim P-Kanal
läuft alles mit umgekehrter Polarität und mit Löchern statt Elektronen als Ladungsträger.

Wichtiger Unterschied zum JFET: Beim JFET wird der Kanal in seiner **Größe** verändert (wie ein
zusammendrückbarer Wasserschlauch). Beim MOSFET wird der Kanal **erzeugt oder entfernt** (wie ein flexibles
Netz, das sich bildet oder auflöst).

## 6. MOSFET und ESD

MOSFETs (und CMOS-Bauteile) können durch elektrostatische Entladung (ESD) leicht zerstört werden, da das
Gate-Oxid nicht spannungsfest genug für hohe elektrostatische Ladungen ist. Schutzmaßnahmen: keine
elektrostatisch aufladende Kleidung, geerdeter Arbeitsplatz, Erdungsarmband – dieselben ESD/EGB-Maßnahmen wie
im Reinraum.

## 7. CMOS – Grundprinzip

**CMOS = Complementary Metal-Oxide-Semiconductor.** Kombination eines P-Kanal- und eines N-Kanal-MOSFET in
einer bestimmten Verschaltung (Inverter): Eingang, Ausgang, Betriebsspannung U_B.

Verhalten:
- Offener Eingang: beide Transistoren gesperrt, kein Durchgang.
- Eingang an Masse (0 V): T1 (P-Kanal) leitend → Ausgang U_A = U_B (High).
- Eingang an U_B: T1 sperrt, T2 (N-Kanal) leitet → Ausgang U_A = 0 V (Low).

Der CMOS-Inverter arbeitet **invertierend** ("im Werte verhalten"): Eingang High → Ausgang Low, und
umgekehrt. Vorteil gegenüber Bipolartransistoren: geringer Energieverbrauch, da im statischen Zustand kein
Strom zum Halten des Schaltzustands fließt – nur beim Umschalten selbst wird Energie (zum Bewegen der
Ladungsträger) benötigt. Deshalb steigt der Strombedarf mit der Taktfrequenz: je schneller geschaltet wird,
desto mehr Energie pro Zeiteinheit wird benötigt, um die Elektronen zu bewegen.

## 8. Grundlagen der Informationsspeicherung – von der Selbsthaltung zum Flipflop

Ausgangsfrage: Ein einfacher Schalter (oder Transistor als Schalter) hält ein Signal nur, solange die Energie
anliegt. Ein Taster gibt nur einen kurzen Impuls. Um mit digitalen Signalen zu rechnen oder Zustände zu
verarbeiten (z. B. Zählen), muss Information **gespeichert** werden.

Historischer Bogen: mechanische Speicherung (Uhrwerk, Federspannung, Abakus/Rechenschieber, Zahnräder in
mechanischen Rechenmaschinen) → elektromechanische Speicherung mit **Relais** (Zuse-Rechner, Enigma) →
elektronische Speicherung mit **Transistoren**.

**Selbsthaltung mit Relais:** Ein Taster schaltet Strom zu einer Lampe UND parallel zu einer Relaisspule. Das
Relais zieht an und schließt einen eigenen Kontakt parallel zum Taster. Der Taster kann losgelassen werden –
der Relaiskontakt hält den Stromkreis geschlossen, die Lampe bleibt an. Ein zweiter Taster (als Öffner in
Reihe) unterbricht den Haltestromkreis und schaltet die Lampe wieder aus. Dies ist die einfachste Form der
Informationsspeicherung – in der Elektronik mit Transistoren als **Kippstufe**, **Flipflop** oder
**Multivibrator** bezeichnet (Multivibrator = lateinischer Begriff für "hin und her schwingen"; Kippstufe ist
der deutsche Fachbegriff).

Beispiele für bistabile Zustände im Alltag: Wecker (gestellt/nicht gestellt), Ampel (die Farbe bleibt bis zum
nächsten Signalwechsel), Aufzugtür (bleibt offen, bis erneut ein Signal kommt), Schranke (bleibt oben, bis das
Durchfahrsignal endet).

## 9. Bistabile Kippstufe (RS-Flipflop) mit Transistoren

Aufbau: zwei NPN-Transistoren Q1/Q2 kreuzweise gekoppelt (Kollektor von Q1 über Widerstand an Basis von Q2 und
umgekehrt), zwei Eingänge **Set (S)** und **Reset (R)**, zwei Ausgänge **U_out1** und **U_out2**,
Versorgungsspannung U_B.

Beim ersten Einschalten ist der Zustand undefiniert (bauteilabhängig, welcher Transistor zuerst leitet).
Angenommen Q2 leitet zuerst: U_out2 liegt auf Masse (Low/0), Q1 ist gesperrt (da keine ausreichende
Basisspannung mehr anliegt) → U_out1 = High (≈ U_B).

Wird der Set-Taster betätigt (Basis von Q1 über 0,7 V gehoben), schaltet Q1 durch → U_out1 wird Low. Dadurch
fällt die Basisspannung von Q2 auf 0, Q2 sperrt → U_out2 wird High. Der Zustand bleibt **ohne** weiteres
Eingangssignal stabil gespeichert – erst der Reset-Taster kippt die Schaltung zurück.

Set und Reset dürfen **niemals gleichzeitig** aktiv sein – das erzeugt einen undefinierten Zustand.

Schematische Darstellung: R (Reset), S (Set), Q und Q̄ (Q-quer) als komplementäre Ausgänge.

### Praktischer Aufbau am Steckbrett (Fehlersuche)

Beim Nachbau am Steckbrett traten wiederholt Fehler auf: Lampenzustände tauschten sich beim Vertauschen von
Bauteilen (Transistoren, LEDs), obwohl Bauteiltests (Diodentester) alle Bauteile als intakt auswiesen. Nach
ausführlicher Fehlersuche (Verkabelung mehrfach kontrolliert, Bauteile getauscht, externe Spannungsquelle
erhöht) wurde vermutet, dass das Steckbrett selbst durch häufige Benutzung defekt war (Abrieb von
Bauteilanschlüssen erzeugt ungewollte Mikroverbindungen/Kapazitäten zwischen benachbarten Kontaktschienen).
Bei erhöhter Betriebsspannung (über die vorgesehenen 9 V hinaus) verhielt sich die eigentlich bistabile
Schaltung zeitweise wie eine monostabile (spontanes Zurückspringen) – nicht abschließend geklärt, vermutlich
durch eine parasitäre Kapazität im Board verursacht.

## 10. Monostabile Kippstufe (Monoflop)

Unterschied zur bistabilen Schaltung: Ein Widerstand wird durch einen **Kondensator** ersetzt. Der Kondensator
lädt/entlädt sich zeitabhängig (RC-Glied) statt sprunghaft zu schalten.

Funktionsprinzip: Im Ruhezustand ist Q1 leitend, der Kondensator wird über R geladen. Ein kurzer Impuls am
Taster schaltet Q2 durch, wodurch an der Basis von Q1 kurzzeitig eine negative Spannung anliegt (durch die im
Kondensator gespeicherte Ladung) und Q1 sperrt. Der Kondensator entlädt sich anschließend über einen Widerstand
in Richtung 0 V; sobald die Basisspannung von Q1 wieder ca. 0,7 V erreicht, schaltet Q1 automatisch zurück in
den Ruhezustand – ohne weiteres äußeres Signal.

**Zeitformel (instabiler Zustand):** t_m = 0,7 · R · C

Beispielrechnung: R = 4,7 kΩ, C = 220 µF → t_m = 0,7 · 4700 · 0,00022 ≈ **0,72 Sekunden**.

Anwendungsbeispiel: Treppenhausbeleuchtung – kurzer Tastendruck schaltet Licht ein, es bleibt für eine feste,
über R und C einstellbare Zeit an und erlischt danach automatisch, unabhängig davon, wie oft während dieser
Zeit erneut gedrückt wird (beim nicht nachtriggerbaren Monoflop).

Weitere Anwendungen: Impulsverlängerung, Impulsverzögerung, Frequenzteilung, Dämmerungsschalter, Zeitglied für
Endverstärker. **Nicht** geeignet für Gleichrichtung oder direkte Frequenzmodulation.

Frage im Unterricht: Wie viele Ausgangsspannungszustände kann die monostabile Kippstufe im Betrieb annehmen?
→ **Zwei** (0 V / U_B, bzw. Low/High) – trotz "mono" im Namen bezieht sich das auf die Zahl der *stabilen*
Zustände (einer), nicht auf die Zahl der möglichen Spannungswerte.

## 11. Astabile Kippstufe (Multivibrator)

Kein stabiler Zustand: Die Schaltung kippt selbstständig und dauerhaft zwischen zwei Zuständen hin und her
(z. B. Blinklicht). Aufbau: symmetrische Schaltung mit zwei Transistoren, zwei Kollektorwiderständen, zwei
Basiswiderständen und **zwei** Kondensatoren (RC-Kopplung auf beiden Seiten – im Unterschied zum Monoflop mit
nur einem Kondensator).

Zeitformeln je Halbperiode:
- T1 = 0,7 · R2 · C2 (oder allgemein 0,7 · R · C für die jeweilige Seite)
- Bei symmetrischem Aufbau (R1 = R2, C1 = C2): T1 = T2 = T/2, Periodendauer **T = 1,4 · R · C**
- Frequenz: **f = 1/T**

Bei unsymmetrischem Aufbau (unterschiedliche R/C je Seite) ergeben sich unterschiedlich lange An-/Aus-Zeiten
(unsymmetrisches Rechtecksignal) – Beispiel im Unterricht: ca. 1 s an / 3,4 s aus.

Kontrollfrage zur Symmetrie: Wenn R1·C2 = R2·C1 (z. B. 10 kΩ·22 nF = 22 kΩ·10 nF), ist das Ausgangssignal
trotz unterschiedlicher Einzelwerte **symmetrisch**.

Anwendungen: Taktgeber (z. B. für Schieberegister, Lauflicht), Sirenen, Blinklicht. Wichtig für Digitaltechnik:
Ein sauberes Rechtecksignal (steile Flanken zwischen 0 und 1) ist notwendig – mit Transistor-Multivibratoren
allein ist das Signal oft nicht ideal rechteckig.

## 12. Der Timer-Baustein NE555

Der **NE555** ist ein integrierter Schaltkreis (IC), der seit ca. 50 Jahren existiert und intern ein
RS-Flipflop sowie zwei Operationsverstärker (Komparatoren) enthält. Er lässt sich sehr universell als
bistabile, monostabile oder astabile Kippstufe beschalten – mit deutlich weniger diskreten Bauteilen als beim
Aufbau mit einzelnen Transistoren.

Gehäuseform: **DIP-Gehäuse** (Dual-Inline-Gehäuse/DIL), 8 Pins, Pin-1-Position durch eine **Notch/Kerbe** (oder
Punktmarkierung) am Gehäuse gekennzeichnet; Nummerierung läuft von dort gegen den Uhrzeigersinn.

Vorteil gegenüber einfachen CMOS-Logikbausteinen: höhere maximale Ausgangslast (bis 200 mA beim NE555 vs. ca.
20 mA bei einfachen CMOS-Gattern) – kann direkt Relais o. Ä. schalten.

Beschaltungen: RS-Flipflop (Set/Reset über je einen Eingang), Monoflop (ein Kondensator + Taster; es gibt
nachtriggerbare und nicht nachtriggerbare Varianten), Astabiler Multivibrator (mit einstellbarer, ggf.
Potentiometer-gesteuerter Taktfrequenz).

In der Praxis werden diskrete Transistor-Kippstufen kaum noch eingesetzt – meist wird ein IC wie der NE555
oder integrierte Logikbausteine (z. B. CMOS 4001, RS-Flipflop-Baustein) verwendet.

## 13. Normänderung bei Schaltzeichen

Hinweis zur aktuellen Norm (seit 2006 geändert, noch nicht überall im Tabellenbuch aktualisiert): Bauteile zur
**Strom-/Durchflusssteuerung** (z. B. Widerstand, Diode) werden mit **R** gekennzeichnet (R = Begrenzung/
Stabilisierung). Bauteile zur **Bereitstellung wahrnehmbarer Funktion** (z. B. Leuchtdiode/LED, die Licht
erzeugt) werden mit **P** gekennzeichnet. Für den NE555-Kontext: Buchstabe **Q** steht in der neueren Norm für
"Steuerung von Zugang oder Durchfluss" (nicht "Motorschutz", wie zunächst vermutet).

## 14. Simulation und Praxisrelevanz in der Industrie

Diskussion über den Stellenwert von Schaltkreissimulation (z. B. mit Falstad/Software wie SPICE) in Ausbildung
und Industrie: Bauteile am Steckbrett gehen durch elektrostatische Aufladung häufig kaputt; Simulationssoftware
zeigt das theoretische Verhalten korrekt, bevor teure reale Testwafer gefertigt werden (Durchlaufzeit für einen
Testwafer: bis zu 60 Tage für eine volle Prozesslinie; bereits eine einzelne Ebene/Lithografieschritt kann
mehrere Tage dauern). Ein MOSFET benötigt bereits 4–5 Prozessebenen (P-Wanne, zwei N-Kanäle, Isolation/Gate,
Aluminiummetallisierung).

KI wurde im Gespräch als aktuelles Werkzeug in Simulation und Prozessüberwachung erwähnt, mit der Einschränkung,
dass sie nur aus bereits vorhandenen Daten lernt und (Stand der Diskussion) noch nicht eigenständig neue
Zusammenhänge kreativ erschließt – menschliche Erfahrung bleibt bei Fehlersuche und Prozessoptimierung
weiterhin notwendig.

Anekdote zur Bedeutung von Detailwissen in der Fertigung: Bei einem Hersteller (Infineon oder GlobalFoundries)
verursachte einfallendes Sonnenlicht auf ein optisches Reflexions-Messgerät systematische Messfehler zu einer
bestimmten Tageszeit; die Lösung war das Abdunkeln des Geräts mit Folie. Ähnliches Prinzip bei
Reinraum-Transportsystemen (AMHS/OHT): Reflexionen an Aluminiumwänden können die optischen Sensoren der
Transportwagen fälschlich zum Anhalten bringen – Lösung: matte/schwarze Folien an reflektierenden Ecken.

## 15. Gespräch über Berufsbilder in der Halbleiterindustrie

- **Prozessingenieur:** definiert und überwacht Prozessparameter (z. B. Ätzrate, Polierzeit bei CMP),
  arbeitet mit statistischer Prozesskontrolle (SPC), um ein stabiles Prozessfenster zu halten; qualifiziert
  neue Verbrauchsmittel und neue Produkte für bestehende Prozesse.
- **Equipment-Ingenieur:** verantwortlich für Wartung, Ersatzteile, Verfügbarkeit der Anlage – reagiert, wenn
  der Prozessingenieur einen Anlagenfehler vermutet.
- **Modulingenieur:** verantwortlich für eine Gruppe zusammengehöriger Prozessebenen (z. B. das
  Metallisierungsmodul).
- **Techniker/Instandhalter (Wartungstechniker):** führt Reparatur und Wartung durch; arbeitsteilig je nach
  Unternehmen unterschiedlich stark von Ingenieursaufgaben abgegrenzt (bei Infineon eher Techniker-lastig,
  bei GlobalFoundries als US-Firma "Maintenance Technology", MT).
- **Field-Ingenieur (bei Zulieferern wie Applied Materials):** nimmt neue Anlagen beim Kunden in Betrieb,
  fährt neue Prozesse ein.
- Der Begriff **Foundry** (z. B. GlobalFoundries) bezeichnet einen Auftragsfertiger: Andere Unternehmen
  entwerfen einen Chip und lassen ihn dort in Serie produzieren; die Foundry selbst entwickelt in der Regel
  keine eigenen Produkte (im Gegensatz z. B. zu Infineon, das ein eigenes Produktportfolio hat).
- Diskussion über akademische vs. praktische Laufbahnen: In Deutschland wird formalen Abschlüssen (Zeugnissen)
  in Einstellungsprozessen viel Gewicht gegeben, auch wenn praktische Berufserfahrung fachlich oft ebenso oder
  wertvoller ist. Networking/Branchenkontakte ("man kennt sich") spielen für Stellenwechsel eine große Rolle.
  Aktuell wird in Dresden mit einem erhöhten Fachkräftebedarf gerechnet, u. a. durch den Bau neuer Fabriken
  (z. B. ESMC).

---

## Persönliche Anekdoten und Nebengespräche (separat, nicht prüfungsrelevant)

- Der Dozent erzählte, dass er früher als Haarmodell in einem Friseursalon gearbeitet hat, um seine Haare/
  seinen Bart dunkel färben zu lassen, kurz bevor er sein Bewerbungsfoto machen musste.
- Gespräch über Ausbildungskosten: Ein Klassensatz Steckbrett-Ausrüstung (Marke Festo) kostet ca. 30.000 €;
  Anschaffungen müssen daher lange genutzt werden, auch wenn die Boards durch Verschleiß zunehmend Fehler
  verursachen.
- Diskussion über Arbeitszeitregelungen: Ein Teilnehmer (Richie) erläuterte, dass er über eine
  Transfergesellschaft mit null vertraglichen Wochenarbeitsstunden eine frühere Abreisezeit (15:15 Uhr statt
  15:30 Uhr) hat als andere Teilnehmer, die über das Arbeitsamt finanziert werden.
- Kurze Erwähnung, dass Frau Bartels in der Mittagspause vorbeikam, vermutlich wegen des Praktikumsplatzes.
- Nebengespräch über Elektronikausbildung an Universität vs. Ausbildung/Aufstiegsfortbildung, sowie über
  Bewerbungsprozesse, HR-Abteilungen und die Bedeutung formaler Zeugnisse in Deutschland.

