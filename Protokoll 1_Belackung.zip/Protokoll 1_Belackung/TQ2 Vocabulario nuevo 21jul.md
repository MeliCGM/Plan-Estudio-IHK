---
title: "TQ2 — Vocabulario nuevo (21 jul)"
subtitle: "Belacken — Versuchsanleitung HL-Labor dca — pendiente de fusionar con el consolidado"
---

| Alemán | Español | Inglés técnico | Nota |
|---|---|---|---|
| der Benetzungswinkel, - | ángulo de mojado (de contacto) | contact/wetting angle | Sinónimo funcional de *Randwinkel* (ya en el consolidado, sección 21); este es el término usado en esta guía de práctica. |
| die Hydrophilität | hidrofilicidad | hydrophilicity | Sustantivo correspondiente a *hydrophil* (adjetivo ya en el glosario). |
| die Hydrophobilität / Hydrophobizität | hidrofobicidad | hydrophobicity | Sustantivo correspondiente a *hydrophob*. |
| der Haftvermittler, - | promotor de adherencia | adhesion promoter | HMDS descrito así en el objetivo del Versuch 1. |
| die CEE 100 | equipo de recubrimiento por centrifugado (modelo) | spin coater (model CEE 100) | Beschichter usado en el Praktikum. |
| der AR-P 3120 | fotorresina positiva (modelo/marca) | positive photoresist (AR-P 3120) | Lack usado en Versuch 2. |
| die TEPLA 200 (Anlage) | equipo de plasma (modelo) | plasma asher (model TEPLA 200) | Usado para eliminar el HMDS por veraschen con O₂. |
| der Bearbeitungscarrier, - | carrier de proceso | processing carrier | Sostiene el wafer dentro del recipiente de vidrio durante la exposición a HMDS. |
| der Handbelacker "Polos" | aplicador manual de resina (nombre de equipo: Polos) | manual spin coater/applicator (device name: Polos) | "Polos" es el nombre propio del aparato, no una abreviatura — confirmado por Mely. |
| der Handentlacker "Polos" | removedor manual de resina (mismo equipo: Polos) | manual resist stripper (same device: Polos) | Mismo aparato "Polos" reutilizado con disolvente (Aceton) en vez de resina, según el protocolo. |
| die Dispensnadel, -n | aguja dosificadora | dispense needle | Se inserta en el Beschichter para aplicar la resina; solo el instructor la cambia. |
| die Dispensabdeckung, -en | tapa/cubierta de la dosificación | dispense cover/cap | Se retira antes de instalar la Dispensnadel. |
| das Belackungsprogramm, -e | programa de recubrimiento (recipe) | coating recipe/program | "Programm 0" en el protocolo. |
| die Drehzahl, -en | velocidad de giro (rpm) | spin speed (RPM) | Variable del Versuch 1 (2000–6000 U/min). |
| die Schleuderzeit, -en | tiempo de centrifugado | spin time | Variable del Versuch 2 (10–60 seg). |
| die Wafermap, -s | mapa de oblea | wafer map | Representación espacial del espesor en 13 puntos, vista 3D y vista de pájaro (Vogelperspektive). |
| der Chuck, -s | mandril de vacío (portaobleas del spinner) | (vacuum) chuck | Sostiene el wafer centrado durante el spin-coating. |
| die Positionierhilfe, -n | ayuda de posicionamiento | positioning aid | Referencia para colocar el wafer centrado sobre el chuck (ver también entrada del 20 jul con grafía "Positionierungshilfe"). |
| ACT TEMP (Taste) | botón de temperatura actual | actual temperature button | En la hotplate, muestra la temperatura real de la placa (vs. temperatura objetivo). |
| die 25%-Heizung (Taste) | modo de calentamiento al 25% | 25% heating mode | Evita sobrepaso (Überschwingen) de temperatura al calentar. |
| das Rudolph-/Filmetrics-Schichtdickenmessgerät | medidor de espesor de capa Rudolph/Filmetrics | Rudolph/Filmetrics film thickness gauge | Grafía "Filmetrics" tomada tal cual de la guía oficial (corrige la anotación [A CONFIRMAR] del 20 jul, que decía "Filmmetrics"). |
| die Zwischenauswertung, -en | evaluación intermedia | intermediate evaluation | Sección del protocolo donde se grafican/interpretan resultados parciales. |
| die Gesamtauswertung | evaluación global/final | overall evaluation | Sección final del protocolo con preguntas de síntesis. |

**Nota:** términos como HMDS, Randwinkelmessung, hydrophil/hydrophob, Spin-on-Verfahren, Randwulst, Randentlackung (EBR), Positivlack y Hotplate ya estaban cubiertos en el consolidado o en el archivo del 20 jul — no se repiten aquí.
