# TQ2 - Vocabulario acumulado aleman-espanol

> Archivo vivo: sube esta misma version junto con cada nueva transcripcion para que se sumen los terminos nuevos sin duplicar los existentes.

## Transcripcion 1 (2026-07-05) - Reinraum / Partikelmessung

| Alemán | Español | Nota de memorización |
|---|---|---|
| das Partikelmessgerät (CEM) | contador de partículas (modelo CEM) | *Partikel* = partícula, *Messgerät* = aparato de medición. |
| das Handpartikelmessgerät | contador de partículas manual/portátil | *Hand-* = manual, portátil. |
| der Ansaugstutzen | boquilla/tubuladura de succión | *ansaugen* = aspirar; *Stutzen* = tubo corto de conexión. |
| die Spülzeit | tiempo de purga/enjuague (automático) | *spülen* = enjuagar. |
| die Laminarbox | cabina de flujo laminar | Flujo de aire de arriba hacia abajo. |
| die Nitrilhandschuhe | guantes de nitrilo | Evitan que la piel genere partículas. |
| die Vergleichsmessung | medición comparativa/de referencia | *Vergleich* = comparación. |
| die Verteilung | distribución (estadística) | No confundir con *Verteidigung* (defensa). |
| der Ausbildungsrahmenplan | plan marco de formación (currículo oficial) | *Rahmen* = marco. |
| die IHK (Industrie- und Handelskammer) | Cámara de Industria y Comercio | Fija el Ausbildungsrahmenplan. |
| die Abgabe(n) | cuota(s)/aportación(es) obligatoria(s) | Pagos de empresas a la IHK. |
| die Bedienungsanleitung | manual de instrucciones/manual de uso | *bedienen* = operar un equipo. |
| der Arbeitsplan | plan de trabajo/procedimiento operativo | Se redacta antes de entrar al Reinraum. |
| der Fed-Standard (Fed-Std-209) | norma federal EE.UU. (obsoleta) de sala limpia | Precedente del ISO 14644. |
| das Zettel | hoja/formulario de registro en papel | Reemplazó a un sistema anterior. |

---

## Transcripción 2 (2026-07-06) - Elektrotechnik Grundlagen / Spannungserzeugung / Kirchhoff / Leistung / Medición

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Spannungserzeugung | generación de tensión | *Spannung* = tensión, *Erzeugung* = generación. |
| der Grundstromkreis | circuito eléctrico básico | *Grund-* = base + *Stromkreis* = circuito. |
| das Widerstandsnetzwerk | red de resistencias | *Widerstand* + *Netzwerk*. |
| der Kondensator | condensador | Cognado directo; ver Transcripción 5 (tema completo Auf-/Entladung). |
| der Wechselstromkreis | circuito de corriente alterna | *Wechsel-* = alterno (vs. *Gleich-* = continuo). |
| das Oszilloskop | osciloscopio | Cognado directo; práctica extensa en Transcripción 5. |
| die Ladungsträger | portadores de carga | *Ladung* = carga, *Träger* = portador. |
| der Leiter / der Halbleiter | conductor / semiconductor | *Halb-* = medio/semi. |
| die Potentialdifferenz | diferencia de potencial | Concepto de tensión eléctrica. |
| geschlossener Stromkreis | circuito cerrado | Requisito para que fluya corriente. |
| der Widerstand | resistencia | Oposición al paso de corriente. |
| das Ohmsche Gesetz (R = U/I) | ley de Ohm | R en Ohm, U en Volt, I en Ampere. |
| die Induktion | inducción | Ej. dinamo de bicicleta (Fahrraddynamo). |
| die Photovoltaik / das Fotoelement / die Solarzelle / die Fotodiode | fotovoltaica / elemento fotoeléctrico / célula solar / fotodiodo | Fotodiode es bidireccional. |
| das Thermoelement | termopar | Unión Kupfer (cobre)/Konstantan; rango ≈ −250°C a 1400°C. |
| die Leitungshin / die Leitungsrück | conductor de ida / conductor de vuelta | Dirección del cableado en el esquema. |
| die Reihenschaltung | conexión en serie | Resistencias se suman; corriente igual en todos los elementos. |
| die Parallelschaltung | conexión en paralelo | Tensión igual en todos; corrientes se suman. |
| der Spannungsteiler (unbelastet) | divisor de tensión (sin carga) | UR2 = Uq·R2/(R1+R2). Ver Transcripción 4 para versión con carga. |
| der Gesamtwiderstand (Rges) | resistencia total | Suma (serie) o suma de inversos (paralelo). |
| das Kirchhoffsche Gesetz | ley de Kirchhoff | Físico alemán Gustav Kirchhoff. |
| der Knotenpunktsatz (1. Kirchhoffsches Gesetz) | ley de los nudos | Suma corrientes entrantes = suma corrientes salientes. |
| der Maschensatz (2. Kirchhoffsches Gesetz) | ley de las mallas | Suma de tensiones en malla cerrada = 0V. |
| die elektrische Leistung (P) | potencia eléctrica | P = U·I = I²·R = U²/R; unidad Watt. |
| die Arbeit (A) | trabajo (energía) | U = A/Q (Q = carga en Coulomb). |
| die Widerstandsmessung | medición de resistencia | Siempre *spannungsfrei*; óhmetro en paralelo. |
| die Spannungsmessung | medición de tensión | Voltímetro en paralelo al objeto medido. |
| die Strommessung | medición de corriente | Amperímetro en serie; interrumpir el cable. |
| spannungsfrei | sin tensión / libre de tensión | Condición obligatoria antes de medir resistencia. |
| die Spule | bobina | Aprovecha el efecto magnético; ver Transcripción 5 (inductancia). |
| der Transformator | transformador | Ej. reducir 50V a 20V; ver Transcripción 5. |
| das Relais | relé | Componente basado en efecto magnético. |
| die chemische Wirkung | efecto químico (de la corriente) | *chemisch* = químico. |
| die Oberflächenveredelung | recubrimiento/tratamiento superficial | *veredeln* = refinar/mejorar. Ej. depósito de cobre. |
| die Lichtwirkung | efecto luminoso (de la corriente) | Ej. filamento de wolframio. |

---

## Transcripción 3 (2026-07-07) - Multímetro, categorías CAT, resistencias como componente, series E

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Spannungsrange / der Messbereich / der Spannungsbereich | rango de medición / rango de tensión | *Range* es anglicismo de clase; término formal: *Messbereich*. |
| die Genauigkeit | precisión | Contrapuesto a *Toleranz*. |
| die Toleranz | tolerancia | ~1,5% analógico, ~0,5% digital. |
| der Endwert | valor de fondo de escala | El % analógico se calcula sobre el *Endwert*, no sobre el valor leído. |
| der absolute Messfehler | error absoluto | F = k·Bereich/100. |
| der relative Messfehler | error relativo | f = F·100/Anzeigewert; aumenta cuanto menor es el valor dentro del rango. |
| der Anzeigewert / der Messwert | valor mostrado / valor medido | Lectura en pantalla o aguja. |
| das Digit (± X Digit) | dígito(s) de la última cifra mostrada | En digital: error = %+dígitos. |
| die Messkategorie / CAT 1-4 (Überspannungskategorie) | categoría de medición / de sobretensión | A mayor categoría, más protección. [A CONFIRMAR: umbrales exactos CAT3/CAT4, el audio los da contradictorios]. |
| der Zangwandler [A CONFIRMAR] | pinza amperimétrica / transformador de pinza | Mide corriente sin cortar el cable; término exacto no verificado en audio. |
| der Festwiderstand | resistencia fija | Valor no ajustable. |
| der Schichtwiderstand / der Kohleschichtwiderstand | resistencia de capa / de capa de carbón | *Kohle* = carbón. |
| der Metallfilmwiderstand | resistencia de película metálica | Mayor precisión típica que la de carbón. |
| der SMD-Widerstand (Surface Mounted Device) | resistencia SMD | Dispositivo de montaje superficial. |
| der Drahtwiderstand | resistencia bobinada / de hilo | *Draht* = hilo/alambre enrollado sobre núcleo cerámico. |
| das Potentiometer | potenciómetro | Ajustable manualmente; 3 conexiones: entrada, salida, cursor (*Schleife*). |
| das Trimmpotentiometer | potenciómetro de ajuste / trimmer | Versión pequeña, solo ajustable con herramienta. |
| die Schleife (bei Poti) | cursor / contacto deslizante | Punto medio móvil que define la tensión de salida. |
| der PTC-Widerstand (Kaltleiter) | PTC / conductor en frío | A mayor temperatura, mayor resistencia. |
| der NTC-Widerstand (Heißleiter) | NTC / conductor en caliente | A mayor temperatura, menor resistencia. |
| PTC / NTC (Positive/Negative Temperature Coefficient) | coeficiente de temperatura positivo/negativo | PTC sube, NTC baja con la temperatura. |
| der Varistor (spannungsabhängiger Widerstand) | varistor | Bajo tensión umbral casi no conduce; al superarla, conduce más. |
| das Zinkoxid | óxido de zinc | Material de varistor para tensiones mayores (hasta ~1,5 kV). |
| das Siliziumcarbid | carburo de silicio | Material de varistor para tensiones menores. |
| der LDR (lichtabhängiger Widerstand) / Fotowiderstand | fotorresistencia | A más oscuridad, mayor resistencia. |
| das DMS (Dehnungsmessstreifen) | galga extensiométrica | *Dehnung* = deformación/estiramiento. |
| der magnetabhängige Widerstand | resistencia dependiente del campo magnético | Símbolo con letra B (inducción). |
| die Induktion (B) | inducción (magnética) | Letra B en esquemas de sensores magnéticos. |
| der Curie-Punkt / die Curie-Temperatur | punto de Curie | Temperatura a partir de la cual se pierde el magnetismo. |
| die E-Reihe (E6, E12, E24, E48, E96) | serie de valores normalizados | Nº = valores por década. Tolerancias: E6=±20%, E12=±10%, E24=±5%. |
| die Auswahl (aus der Reihe) | selección (de la tabla de la serie) | Se toma el valor normalizado igual o mayor al calculado. |
| das Nominal / der Nominalwert | valor nominal | Valor "de catálogo" de un componente. |

---

## Transcripción 4 (2026-07-08) - Entflechten, divisor de tensión con carga, LED, condensador (intro)

| Alemán | Español | Nota de memorización |
|---|---|---|
| das Entflechten | desenredar / simplificar (red de resistencias) | Identificar qué elementos comparten los mismos dos nudos, sin cambiar tensiones/corrientes. |
| der Knoten | nudo (de un circuito) | El instructor lo pronunciaba como "Note" en clase; forma correcta: *Knoten*. |
| die Brücke (en protoboard) | puente (conector corto) | Se retira para insertar el amperímetro en serie. |
| das Amperemeter / Ampermeter | amperímetro | Siempre en serie; interrumpir físicamente el cable/puente. |
| der belastete Spannungsteiler | divisor de tensión con carga | Tiene RL en paralelo a R2, a diferencia del divisor simple. |
| R2,L (Parallelwiderstand aus R2 und RL) | resistencia equivalente de R2 en paralelo con RL | R2,L = (R2·RL)/(R2+RL). |
| der Verbraucher | consumidor / carga | Ej. una lámpara o cualquier RL final. |
| das Querstromverhältnis (q) | relación de corriente transversal | q = I_R2/I_RL; típico entre 3 y 10 (5 recomendado). |
| der Laststrom (I_RL) | corriente de carga | Corriente que llega realmente al consumidor. |
| die LED / Leuchtdiode | LED / diodo emisor de luz | *Leuchten* = brillar/emitir luz. |
| die Anode / die Kathode | ánodo / cátodo | Pata larga = ánodo (+); pata corta = cátodo (−). |
| die Reflektorwanne | copa reflectora (dentro del LED) | Base metálica donde se apoya el chip LED. |
| der Golddraht / Bonddraht | hilo de oro / hilo de conexión (bond wire) | Conecta el chip con el terminal opuesto. |
| der LED-Chip | chip LED | Parte semiconductora donde se genera la luz (unión P-N). |
| das Kunststoffgehäuse | encapsulado/carcasa de plástico | El color del plástico NO determina el color de luz emitido. |
| die Durchlassrichtung | dirección de conducción directa | Polarización en la que el LED conduce y emite luz. |
| die Sperrrichtung | dirección de bloqueo (polarización inversa) | El LED no conduce ni emite luz. |
| die Sperrschicht | zona de carga espacial / unión P-N | Donde se recombinan huecos y electrones, liberando luz. |
| P-dotiert / N-dotiert | dopado tipo P / dopado tipo N | P rica en huecos (*Löcher*); N rica en electrones. |
| das Loch / die Löcher | hueco / huecos (portador positivo) | Plural con -er: das Loch → die Löcher. |
| der Elektronenüberschuss | exceso de electrones | Relacionado con corrientes altas en polarización directa fuerte. |
| die Durchbruchspannung / der Durchbruch | tensión de ruptura / ruptura (breakdown) | Polarización inversa con campo eléctrico muy alto. |
| der Vorwiderstand | resistencia limitadora / serie (para LED) | R_V = (U_alim − V_F)/I_F; obligatoria siempre. |
| die Durchlassspannung (V_F) | tensión directa (del LED) | Rojo 0,6–1,6V; amarillo/verde hasta 1,8V; azul hasta 3V; blanco hasta 3,5V. |
| der Durchlassstrom (I_F) | corriente directa (del LED) | Estándar de referencia: 20mA. |
| die Kapazität (C) [Farad, F] | capacidad (unidad: Faradio) | C = ε₀·εr·A/l. |
| das Dielektrikum | dieléctrico (material aislante entre placas) | Ej. aire, agua, cerámica, papel/película. |
| die Feldkonstante (ε₀) | constante de campo eléctrico (permitividad del vacío) | ε₀ = 8,85×10⁻¹² F/m; valor fijo. |
| die Permittivität (εr) | permitividad relativa | Depende del material: aire=1, agua≈80, cerámica≈100–10.000. |

---

## Transcripción 5 (2026-07-09) - Kondensator (Auf-/Entladung completo), Oszilloskop práctico, Spannungsquelle (Leerlauf/Kurzschluss/Normalbetrieb/Leistungsanpassung), Wechselstrom, Kreisfrequenz, Widerstand im Wechselstromkreis

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Zeitkonstante (τ, Tau) | constante de tiempo | τ = R·C; determina la velocidad de carga/descarga del condensador. |
| die Ladung (Kondensator) / die Entladung | carga / descarga (del condensador) | U_C(t) = U_max·(1−e^(−t/τ)); I(t) = I₀·e^(−t/τ). |
| der Ladungsvorgang / der Entladungsvorgang | proceso de carga / proceso de descarga | Curvas complementarias en el osciloscopio. |
| Kondensatoren parallel | condensadores en paralelo | Las capacidades se SUMAN (al revés que las resistencias en paralelo — fuente típica de confusión). |
| Kondensatoren in Reihe | condensadores en serie | Dos: C=(C1·C2)/(C1+C2). Tres o más: 1/C=1/C1+1/C2+1/C3. |
| der Elektrolytkondensator (Elko) | condensador electrolítico | Tiene polaridad; riesgo de explosión si se invierte. |
| das Spannung-pro-Kästchen | tensión por división (osciloscopio) | Escala vertical del osciloscopio, ajustable por canal. |
| das Zeit-pro-Kästchen | tiempo por división (osciloscopio) | Escala horizontal, común a ambos canales. |
| der Tastkopf | punta de prueba (del osciloscopio) | Requiere compensación (*Kompensation*) para señal cuadrada sin redondeos. |
| die Kompensation (Tastkopf) | compensación (de la punta de prueba) | Ajuste con tornillo/potenciómetro en la punta hasta obtener onda cuadrada ideal. |
| das Verhältnis (1:1 / 1:10) | relación / factor de atenuación de la punta | 1:10 = la amplitud mostrada es 10 veces menor que la real. |
| der Kanal (Kanal 1 / Kanal 2) | canal (1 / 2) | Cada canal del osciloscopio tiene su propio ajuste de tensión-por-división. |
| die Autoeinstellung / Auto (Taste) | autoajuste (botón Auto) | Ajusta automáticamente tensión y tiempo por división. |
| der Kursor (Cursor-Modus) | cursor (modo manual) | Línea horizontal o vertical móvil para leer valores exactos en un punto. |
| die Masse (Oszilloskop) | masa / tierra (de medición) | Punto de referencia común; una sola masa es suficiente normalmente. |
| der Leerlauf | vacío / circuito abierto | Sin consumidor conectado; R_carga → ∞, I=0, U=U_Q completa. |
| der Kurzschluss | cortocircuito | R_carga → ~0; I_max = U_Q/R_i (resistencia interna). |
| der Normalbetrieb | funcionamiento normal | 0 < R_carga < ∞. |
| die Leistungsanpassung | adaptación de potencia (máxima transferencia) | Ocurre cuando R_carga = R_i; P_max = U_Q²/(4·R_i). Mitad de energía se disipa en R_i (ineficiente, usado en antenas). |
| der Innenwiderstand (Ri) | resistencia interna (de la fuente) | Ver también Transcripción 2. |
| die Spannungsquellen in Reihe | fuentes de tensión en serie | Tensiones y resistencias internas se suman según polaridad. |
| die Spannungsquellen parallel | fuentes de tensión en paralelo | La tensión no cambia; aumenta la corriente disponible al consumidor. |
| der Ausgleichsstrom | corriente de compensación | I = (U_Q1−U_Q2)/(R_i1+R_i2); puede ser peligrosamente alta si se conectan fuentes distintas en lazo cerrado sin carga. |
| die Sinuskurve / sinusförmig | curva senoidal / de forma sinusoidal | Forma característica de la corriente/tensión alterna. |
| die Halbwelle (positiv/negativ) | semionda (positiva/negativa) | Cada mitad del ciclo de la sinusoide. |
| die Periodendauer (T) | periodo (duración) | Unidad: segundos. |
| die Frequenz (f = 1/T) | frecuencia | Unidad: Hertz (Hz), nombrada por el científico Heinrich Hertz. |
| der Fehlerstromschutzschalter (FI) | interruptor diferencial (RCD) | Corta el circuito ante fuga de corriente a tierra; protege contra electrocución. |
| die Erde / geerdet | tierra / puesto a tierra | Conductor de protección; evita descarga al tocar un aparato defectuoso. |
| die Loslassschwelle | umbral de "no poder soltar" | Corriente a partir de la cual los músculos se contraen y no se puede soltar el contacto. |
| die Wahrnehmbarkeitsschwelle | umbral de percepción | Corriente mínima detectable por el cuerpo humano (~0,5–1 mA en AC). |
| das Herzkammerflimmern | fibrilación ventricular | Efecto de corrientes altas (>0,5A) sobre el corazón. |
| die Kreisfrequenz (ω, Omega) | frecuencia angular / frecuencia circular | ω = 2·π·f; unidad rad/s (no confundir con Hz). |
| der Augenblickswert | valor instantáneo | u(t) = Û·sin(ω·t); tensión en un momento t específico. |
| der Scheitelwert (Û) | valor pico / valor de cresta | Amplitud máxima de la sinusoide. |
| das Bogenmaß / der Radiant | medida en radianes | Unidad angular alternativa al grado (Gradmaß). |
| die spezifische Widerstand (ρ, Rho) | resistividad específica | R = ρ·l/A; unidad Ω·mm²/m; propia de cada material. [A CONFIRMAR: valor de cobre dado en audio como "0,070", posible error de transcripción — valor estándar ≈0,0178 Ω·mm²/m]. |
| die Querschnittsfläche (A) | sección transversal (del cable) | Área de corte del conductor; unidad mm². |
| der Wirkwiderstand | resistencia óhmica pura / resistencia activa | Independiente de la frecuencia. |
| der Blindwiderstand | reactancia | Depende de la frecuencia; incluye inductiva y capacitiva. |
| der induktive Widerstand (XL) | reactancia inductiva | XL = ω·L = 2·π·f·L. |
| der kapazitive Widerstand (XC) | reactancia capacitiva | XC = 1/(ω·C) = 1/(2·π·f·C). |
| die Phasenverschiebung (φ, Phi) | desfase / desplazamiento de fase | En un elemento inductivo la corriente se retrasa respecto a la tensión. |
| die Induktivität (L) [Henry, H] | inductancia | Unidad Henry; propiedad de la bobina. |
| kontaktloses Laden | carga inalámbrica / sin contacto | Demostrado con bobina tipo Tesla; acoplamiento por campo magnético sin cable físico completo. |

---

### [A CONFIRMAR] - Términos pendientes de verificación (consolidado)

- **CAT3/CAT4 (umbrales de tensión exactos):** contradictorios en el audio de la Transcripción 3.
- **der Zangwandler:** pinza amperimétrica; término exacto no verificado.
- **NTC material "Titanium O2/O3":** el propio instructor dijo no estar seguro (Transcripción 3).
- **Resistividad específica del cobre:** el audio dice "0,070 Ω·mm²/m", pero el valor estándar es ≈0,0178; posible error de transcripción o de habla del instructor (Transcripción 5).
- **Fórmula exacta de la fase (φ = ωt + π/2):** confirmar signo exacto contra el libro de tablas (Tabellenbuch) — el instructor mismo pareció dudar al explicarlo (Transcripción 5).
- Varios nombres propios e instructores mencionados en sesiones previas, aún sin confirmar.

---

*(Los términos ya cubiertos en transcripciones previas de este proyecto no se repiten aquí; súbeme este archivo cada vez y solo agrego lo nuevo.)*
