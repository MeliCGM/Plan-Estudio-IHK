# TQ2 - Vocabulario acumulado aleman-espanol

> Archivo vivo: sube esta misma version junto con cada nueva transcripcion para que se sumen los terminos nuevos sin duplicar los existentes.

## Transcripcion 1 (2026-07-05) - Reinraum / Partikelmessung

| Alemán | Español | Nota de memorización |
|---|---|---|
| das Partikelmessgerät (CEM) | contador de partículas (modelo CEM) | *Partikel* = partícula, *Messgerät* = aparato de medición. CEM es el nombre/marca del modelo usado en el Reinraum. |
| das Handpartikelmessgerät | contador de partículas manual/portátil | *Hand-* = manual, portátil (vs. equipo de pie fijo). |
| der Ansaugstutzen | boquilla/tubuladura de succión | *ansaugen* = aspirar, succionar; *Stutzen* = tubo corto de conexión. |
| die Spülzeit | tiempo de purga/enjuague (automático) | *spülen* = enjuagar — mismo verbo que "fregar los platos" (Geschirr spülen). |
| die Laminarbox | cabina de flujo laminar | Flujo de aire de arriba hacia abajo; obligatoria para todas las mediciones. |
| die Nitrilhandschuhe | guantes de nitrilo | Evitan que la piel de las manos genere partículas. |
| die Vergleichsmessung | medición comparativa/de referencia | *Vergleich* = comparación. |
| die Verteilung | distribución (estadística) | Ojo: no confundir con *Verteidigung* (defensa) — son casi idénticas al oído. |
| der Ausbildungsrahmenplan | plan marco de formación (currículo oficial) | *Rahmen* = marco; documento que define qué debe aprender cada oficio regulado. |
| die IHK (Industrie- und Handelskammer) | Cámara de Industria y Comercio | Entidad que fija el Ausbildungsrahmenplan y cobra cuotas obligatorias a las empresas. |
| die Abgabe(n) | cuota(s)/aportación(es) obligatoria(s) | Pagos obligatorios de las empresas a la IHK. |
| die Bedienungsanleitung | manual de instrucciones/manual de uso | *bedienen* = operar un equipo; solo se entrega dentro del Reinraum. |
| der Arbeitsplan | plan de trabajo/procedimiento operativo | Se redacta antes de entrar al Reinraum, paso a paso. |
| der Fed-Standard (Fed-Std-209) | norma federal EE.UU. (obsoleta) de clasificación de salas limpias | Precedente histórico del ISO 14644; retirada oficialmente en 2001 pero aún citada por costumbre. |
| das Zettel | hoja/formulario de registro en papel | No es un equipo — es una hoja de papel que reemplazó a un sistema anterior. |

---

## Transcripción 2 (2026-07-06) - Elektrotechnik Grundlagen (sesión completa del día)

### Reglas del aula / organización

| Alemán | Español | Nota de memorización |
|---|---|---|
| der Not-Taster | botón de parada de emergencia | *Not-* = emergencia + *Taster* = pulsador. Corta la corriente de toda la fila. |
| die Anwesenheitsliste | lista de asistencia | *Anwesenheit* = presencia/asistencia. |
| die Garderobe | guardarropa/perchero | Para chaquetas y cascos. |
| der Restmüll / der Papiermüll | basura general / papel (residuos) | Separación de contenedores en el aula. |
| die technische Pause / die Drinpause | pausa técnica | Apodada en broma "tschechische Pause" (juego de palabras con "checa") por el instructor. |

### Generación de tensión (Spannungserzeugung)

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Spannungserzeugung | generación de tensión | *Spannung* = tensión, *Erzeugung* = generación/producción. |
| die Ladungsträger | portadores de carga | *Ladung* = carga, *Träger* = portador (de *tragen* = llevar/portar). |
| der Leiter / der Halbleiter | conductor / semiconductor | *Halb-* = medio/semi. |
| die Potentialdifferenz | diferencia de potencial | Segundo concepto de tensión eléctrica, junto con el trabajo para mover cargas. |
| geschlossener Stromkreis | circuito cerrado | Requisito para que fluya corriente. |
| der Widerstand | resistencia | Capacidad de oponerse al paso de corriente. |
| das Ohmsche Gesetz (R = U/I) | ley de Ohm | R en Ohm, U (tensión) en Volt, I (intensidad) en Ampere. |
| die Induktion | inducción | Ejemplo: dinamo de bicicleta (Fahrraddynamo). |
| die Photovoltaik / das Fotoelement / die Solarzelle / die Fotodiode | fotovoltaica / elemento fotoeléctrico / célula solar / fotodiodo | La Fotodiode es bidireccional y genera tensión según intensidad de luz. |
| das Thermoelement | termopar | Unión Kupfer (cobre) + Konstantan (constantán); rango aprox. −250 °C a 1400 °C. |
| der Kaltleiter / der Heißleiter | termistor PTC / termistor NTC | *Kalt-* = frío, *Heiß-* = caliente. Tema de otro curso (MRT). |
| der Piezokristall | cristal piezoeléctrico | Genera tensión al aplicarle presión (Druck). |
| die chemische Reaktion (Batterie) | reacción química (pila) | Ejemplo: pila de limón, electrodos Zink (zinc) y Kupfer (cobre), ~0,6-1 V. |

### Efecto de la corriente sobre el cuerpo humano

| Alemán | Español | Nota de memorización |
|---|---|---|
| die physiologische Wirkung | efecto fisiológico | Categoría general de los cuatro efectos siguientes. |
| die Muskelverkrampfung | contractura/espasmo muscular | "Kleben bleiben am Strom" = quedarse pegado a la corriente. |
| das Herzkammerflimmern | fibrilación ventricular | *Herzkammer* = ventrículo cardíaco, *flimmern* = parpadear/fibrilar. El corazón no tolera tensiones grandes. |
| der Atemstillstand | paro respiratorio | *Atem* = respiración, *Stillstand* = detención. |
| die Verbrennung | quemadura | Cognado con "quemar" en el sentido de combustión. |
| der Spannungsschritt / die Schrittspannung | tensión de paso | Diferencia de potencial entre ambos pies en el suelo, relevante cerca de una descarga (rayo). Recomendación: saltar con pies juntos o dar pasos cortos con pies juntos. |
| die Wärmewirkung | efecto térmico | *Wärme* = calor. |
| der Heizwendel | resistencia calefactora (espiral) | Ejemplo: calentador de agua (Wasserkocher). |
| der Terrassenstrahler | calefactor de terraza | *Terrasse* = terraza, *Strahler* = emisor/foco radiante. |
| die magnetische Wirkung | efecto magnético | Todo conductor con corriente genera un campo magnético a su alrededor. |
| die Rechte-Hand-Regel (implícita) | regla de la mano derecha | Las líneas de campo giran en sentido horario mirando en la dirección de la corriente. |
| die Spule | bobina | Componente que aprovecha el efecto magnético. |
| der Transformator | transformador | Ejemplo: reducir 50V a 20V. |
| das Relais | relé | Tercer ejemplo de componente magnético-relevante. |
| die chemische Wirkung | efecto químico | *chemisch* = químico. |
| die Oberflächenveredelung | recubrimiento/tratamiento superficial (de metales) | *Oberfläche* = superficie, *veredeln* = refinar/mejorar. Ej. depósito de cobre. |
| die Lichtwirkung | efecto luminoso | Ej. filamento de wolframio (Wolframfaden) en lámparas incandescentes; también ionización por rayos. |

### Circuito básico, serie y paralelo (Grundstromkreis, Reihen-/Parallelschaltung)

| Alemán | Español | Nota de memorización |
|---|---|---|
| der Grundstromkreis | circuito eléctrico básico | *Grund-* = base/fundamental + *Stromkreis* = circuito. |
| die Quellenspannung (Uq) / die Betriebsspannung (UB) / die Versorgungsspannung | tensión de la fuente / tensión de servicio / tensión de alimentación | Tres nombres distintos para el mismo concepto según el contexto. |
| der Innenwiderstand (Ri) | resistencia interna (de la fuente) | Suele ser pequeña, del orden de 0,2 a 10 Ω. |
| der Lastwiderstand (RL) / der Verbraucher | resistencia de carga / consumidor | El "Verbraucher" es el equivalente resistivo de cualquier aparato conectado (móvil, lámpara, etc.). |
| die Leitungshin / die Leitungsrück | conductor de ida / conductor de vuelta | Dirección del cableado en el esquema del circuito. |
| die Reihenschaltung | conexión en serie | Las resistencias se suman; la corriente es igual en todos los elementos. |
| die Parallelschaltung | conexión en paralelo | La tensión es igual en todos los elementos; las corrientes se suman. |
| der Spannungsteiler | divisor de tensión | Fórmula: UR2 = Uq·R2/(R1+R2). |
| der Gesamtwiderstand (Rges) | resistencia total | Suma (serie) o suma de inversos (paralelo). |

### Leyes de Kirchhoff y potencia

| Alemán | Español | Nota de memorización |
|---|---|---|
| das Kirchhoffsche Gesetz | ley de Kirchhoff | Llevan el nombre del físico alemán Gustav Kirchhoff. |
| der Knotenpunktsatz (1. Kirchhoffsches Gesetz) | ley de los nudos | Suma de corrientes entrantes = suma de corrientes salientes en un nudo. |
| der Maschensatz (2. Kirchhoffsches Gesetz) | ley de las mallas | Suma de tensiones en una malla cerrada = 0V. |
| die elektrische Leistung (P) | potencia eléctrica | P = U·I = I²·R = U²/R; unidad: Watt (=Volt·Ampere). |
| die Arbeit (A) | trabajo (energía) | En la fórmula U = A/Q (Q = carga en Coulomb). |

### Medición de magnitudes eléctricas

| Alemán | Español | Nota de memorización |
|---|---|---|
| die Widerstandsmessung | medición de resistencia | Siempre en estado sin tensión (spannungsfrei); el óhmetro se conecta en paralelo. |
| die Spannungsmessung | medición de tensión | El voltímetro se conecta en paralelo al objeto de medición. |
| die Strommessung | medición de corriente | El amperímetro se conecta en serie; hay que interrumpir el cable físicamente. |
| der Messbereich | rango de medición | Elegir el más alto si no se conoce el orden de magnitud esperado. |
| die Polarität | polaridad | En voltímetro: borne V al potencial más alto, COM al más bajo. En amperímetro: borne A al potencial más alto. |
| die spannungsrichtige Messschaltung / die stromrichtige Messschaltung | montaje de medición preciso en tensión / preciso en corriente | Dos variantes de medición indirecta de resistencia, cada una con su propia fuente de error. |

---

### Términos sin confirmar

- "Frescube Elektronik" — probablemente error de transcripción de *Grundlagen-Elektronik* [A CONFIRMAR]
- "Herrudiger" — posible nombre propio de instructor/compañero, quizá "Herr Rüdiger" [A CONFIRMAR]
- Apellido deletreado con dudas: "Mietar / Web Rische / Mitter / Mittall" [A CONFIRMAR]
- "Herr Schiasko" — posible apellido real del instructor, usado por los alumnos para dirigirse a él [A CONFIRMAR]
- Nombres de empresas formadoras aparte de Infineon (claro): "Xenon", "Xper" [A CONFIRMAR]
- Referencia a que Kirchhoff "trabajó con/en Porsche" — no se pudo confirmar; probablemente error de transcripción de otra frase [A CONFIRMAR]
- Año exacto y atribución de la lámpara centenaria de wolframio mencionada como ejemplo (¿1901? ¿Edison?) [A CONFIRMAR]
- Valores exactos de R1/R2/R3 en el tercer ejercicio de resistencias en paralelo (apuntes manuscritos, página con caligrafía poco legible) [A CONFIRMAR contra el cuaderno]

---

*(Los términos ya cubiertos en transcripciones previas de este proyecto no se repiten aquí; súbeme este archivo cada vez y solo agrego lo nuevo.)*
