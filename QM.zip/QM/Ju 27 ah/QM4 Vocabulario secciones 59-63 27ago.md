# QM 4 (27 ago) — Vocabulario nuevo, secciones 59–63
_Continúa desde la sección 58 (QM 3, 26 ago). Para adjuntar al archivo de vocabulario acumulado del proyecto._

## 59. Estadística — formación de clases y frecuencias (Excel)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Klasseneinteilung | formación/división en clases | class formation (binning) | Base para construir el histograma. |
| die Klassenzahl / Klassenanzahl (k) | número de clases | number of classes | Valor orientativo k ≈ √n; no es norma fija. |
| die Klassenbreite / Klassenweite | ancho de clase | class width | = Spannweite / Klassenzahl, redondeado a un valor práctico. |
| ZÄHLENWENNS | CONTAR.SI.CONJUNTO (función Excel) | COUNTIFS (Excel function) | Necesaria cuando hay 2+ criterios (límite inferior y superior de clase). |
| die Zuordnungsvorschrift | regla de asignación (a una clase) | assignment rule | Solo un límite lleva "≥"; el otro debe ser "<", para no contar dos veces. |
| die bedingte Formatierung | formato condicional | conditional formatting | Usado aquí para resaltar errores de conteo (celda roja si suma ≠ total). |
| die relative Häufigkeit | frecuencia relativa | relative frequency | Frecuencia de clase / total, en %. |
| die kumulierte/summierte Häufigkeit (fⱼ) | frecuencia acumulada | cumulative frequency | fⱼ = fⱼ₋₁ + frecuencia relativa de la clase actual. |
| ISTZAHL (Excel-Funktion) | ES.NUMERO (función Excel) | ISNUMBER (Excel function) | Usada para evitar error de referencia en la primera fila de la fⱼ acumulada. |

## 60. Estadística gráfica — red de probabilidad y Pareto/ABC

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Ausgleichsgerade, -n | recta de ajuste | best-fit line | Se traza sobre los puntos del papel de probabilidad para leer x̄, 6s y ΔKrit. |
| der Überschreitungsanteil, -e | proporción fuera de tolerancia | out-of-spec proportion | Se lee en el punto donde la recta cruza OGW/UGW. |
| die Pareto-Analyse / ABC-Analyse | análisis de Pareto / análisis ABC | Pareto analysis / ABC analysis | Regla 80/20; aquí aplicada por cantidad de fallos y por costo de fallos. |
| der Rang, ¨-e | rango/posición (en un ranking) | rank | Función RANG en Excel; ordena de mayor a menor frecuencia o costo. |
| die Fehlerkosten (pl.) | costos de fallo/defecto | failure/defect cost | Dato clave junto a frecuencia para priorizar en Pareto. |
| die Kategorie A/B/C | categoría A/B/C | category A/B/C | Umbral (p. ej. 80%/90%) es libre, no normado — herramienta de decisión. |
| das Verbunddiagramm | gráfico combinado | combo chart | Columnas + línea de puntos, con eje secundario para la curva acumulada. |
| Fenster fixieren | inmovilizar paneles | freeze panes | Ansicht → Fenster fixieren; mantiene cabecera/columna visibles al desplazar. |
| das benutzerdefinierte Zahlenformat | formato numérico personalizado | custom number format | Permite mostrar unidad (p. ej. " mm") sin convertir la celda en texto. |

## 61. Capacidad de proceso — definiciones y tamaño de muestra

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Prozessfähigkeit | capacidad de proceso | process capability | "Estudio de la capacidad Y del control de un proceso de fabricación" — dos afirmaciones combinadas. |
| die vorläufige Prozessfähigkeit (PP/PPK) | capacidad de proceso preliminar | preliminary process capability | Mín. 25 submuestras de 5 piezas, periodo ≥ 8 horas. |
| die Langzeitprozessfähigkeit (CP/CPK) | capacidad de proceso a largo plazo | long-term process capability | Periodo ≥ ~20 días de producción, condiciones normales de serie. |
| CP (Prozessfähigkeitsindex) | índice de capacidad de proceso (dispersión) | process capability index (spread) | CP = T / (6×σ̂); exigencia habitual ≥1,33 (menor que CM por más fuentes de dispersión). |
| CPK (Prozessfähigkeitsindex, Lage) | índice de capacidad de proceso (centrado) | process capability index (centering) | CPK = ΔKrit / (3×σ̂); CPK ≤ CP siempre. |
| die 5M (Mensch, Maschine, Material, Methode, Mitwelt) | las 5M (mano de obra, máquina, material, método, medio ambiente) | 5M framework | Factores de influencia considerados en la capacidad de proceso, no en la de máquina. |
| fähig | capaz (dispersión suficientemente pequeña) | capable | Se refiere solo a la anchura de la curva frente a la tolerancia. |
| beherrscht | controlado/bajo control | in control | Sin influencias sistemáticas desconocidas; media y dispersión estables en el tiempo. |

## 62. Cartas de control de calidad (SPC) — fundamentos y tipos

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Qualitätsregelkarte, -n | carta de control de calidad | (quality) control chart | Diagrama de valores estadísticos de muestras a lo largo del tiempo. |
| Walter Shewhart | Walter Shewhart | Walter Shewhart | Creador de la carta de control en los años 1930. |
| die Mittellinie | línea central | center line (CL) | Referencia central de la carta; puede ser de tolerancia o de proceso. |
| die Eingriffsgrenze, -n (OEG/UEG) | límite de intervención (sup./inf.) | control limit (UCL/LCL) | ~99% de los valores esperados dentro; superarlo obliga a detener el proceso. |
| die Warngrenze, -n (OWG/UWG) | límite de advertencia (sup./inf.) | warning limit | ~95% de los valores esperados dentro; obliga a intensificar el control, no a parar. |
| toleranzbezogen (Eingriffsgrenzen) | (límites) referidos a la tolerancia | tolerance-based (limits) | Calculados a partir de OGW/UGW — usado cuando aún no hay datos de proceso fiables. |
| prozessbezogen (Eingriffsgrenzen) | (límites) referidos al proceso | process-based (limits) | Calculados a partir de μ̂ y σ̂ reales del proceso — más preciso. |
| die T/8-Regel | regla de la tolerancia entre ocho | T/8 rule | Sustituto provisional de σ mientras no hay datos de proceso: s ≈ T/8. |
| die Annahmequalitätsregelkarte / Urwertkarte | carta de aceptación / carta de valores individuales | acceptance control chart / individuals chart | Pregunta: ¿son aceptables los resultados (dentro de tolerancia)? Enfoque en el producto. |
| die Schuhart-Karte / Prozessregelkarte | carta de Shewhart / carta de proceso | Shewhart chart / process control chart | Pregunta: ¿sigue el proceso bajo control? Enfoque en el proceso, no en la tolerancia. |
| die x̄-R-Karte | carta de medias y rangos | x̄-R chart (mean-range chart) | Variante más sensible; requiere calcular la media. |
| die x̃-R-Karte (Mediankarte) | carta de mediana y rango | median-range chart | Más simple/manual, pero menos sensible a cambios reales del proceso. |

## 63. Cartas de control — reglas de reacción ("reglas de siete")

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Ansprechen (der Regelkarte) | activación/disparo (de la carta de control) | out-of-control signal | Momento en que se cumple un criterio de intervención. |
| der Trend | tendencia | trend | 7+ valores consecutivos subiendo o bajando → detener e investigar. |
| der Run / Lauf | racha | run | 7+ valores consecutivos al mismo lado de la línea central → cambio sistemático permanente. |
| die Mittel-Drittel-Regel | regla del tercio medio | middle-third rule | [A CONFIRMAR: dos variantes contradictorias vistas en clase, según la fuente]. |
| die Wechsel-/Sägezahn-Regel | regla del zigzag/alternancia | alternating (zigzag) rule | Cambio constante de lado de la línea central → posibles 2 instrumentos distintos o datos desordenados. |
| die 100%-Prüfung | inspección al 100% | 100% inspection | Obligatoria sobre piezas fabricadas desde la última muestra conforme, si hay una señal fuera de control. |
| der Reaktionsplan, ¨-e | plan de reacción | reaction plan | Procedimiento a seguir cuando la carta de control se activa. |

