# TQ2 — Vocabulario nuevo: Qualitätsmanagement, Sitzung 1

**Nota:** Estas secciones (47–49) continúan la numeración del archivo consolidado (última sección confirmada: 46, "Sistemas numéricos", sesión Elektrotechnik 7 del 21 ago). No tengo en este chat el contenido íntegro de las secciones 42–46 para fusionarlo aquí directamente sin riesgo de error — se entrega solo el **bloque nuevo**; por favor añádelo a continuación de tu archivo consolidado maestro, o pídeme que lo fusione si me compartes/confirmas el archivo maestro más reciente.

---

## 47. Qualitätsmanagement — Grundbegriffe und Historie

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Qualitätsmanagement (QM) | gestión de calidad | quality management (QM) | Planificación, control y actividades sistemáticas orientadas a la calidad. |
| die Qualität | calidad | quality | ISO 9000: "Grad, in dem ein Satz inhärenter Merkmale Anforderungen erfüllt." |
| das inhärente Merkmal | característica inherente | inherent characteristic | Propia de la unidad, no cambia (ej. diámetro de un tornillo). |
| das zugeordnete Merkmal | característica asignada | assigned characteristic | No es propia de la unidad, viene de fuera (ej. precio). |
| die Anforderung, -en | requisito | requirement | Explícita (Lastenheft) o implícita (reglas del arte). |
| die interessierte Partei, -en | parte interesada | interested party / stakeholder | No solo el cliente: también accionistas, entes estatales, etc. |
| das Lastenheft | pliego de especificaciones (del cliente) | requirements specification | Documento donde se fijan requisitos explícitos. |
| die Zunft, ¨-e | gremio (medieval) | guild | Agrupación de artesanos de un oficio y región; garantizaba calidad de sus miembros. |
| die Walz | "la vuelta" (viaje de formación del oficial de gremio) | journeyman's tour | Tradición de trabajar itinerante con distintos maestros tras la formación. |
| das Eichwesen | sistema de verificación oficial de medidas | legal metrology / official calibration system | Desarrollo histórico de la normalización de unidades de medida. |
| kalibrieren / die Kalibrierung | calibrar / calibración | to calibrate / calibration | Comparar un instrumento con otro más exacto (≥10× más preciso); comprobar si la desviación está en tolerancia. |
| justieren / die Justierung | ajustar / ajuste | to adjust | Reconfigurar el instrumento si la desviación excede la tolerancia y es reajustable. |
| eichen / die Eichung | verificar oficialmente (metrología legal) | to legally verify (metrology) | Forma especial de calibración; solo la realiza un organismo estatal reconocido (Eichamt). |
| das Eichamt, ¨-er | oficina de verificación metrológica (estatal) | (state) verification/weights & measures office | Emite el sello de verificación (Prüfsiegel). |
| das metrische System | sistema métrico | metric system | Se impuso antes en Francia (Estado centralizado) que en Alemania (muchos principados). |
| der Taylorismus | taylorismo | Taylorism | Fragmentación del trabajo en pasos pequeños, base de la línea de montaje. |
| das Fließbandprinzip | principio de línea de montaje | assembly line principle | Ejemplo histórico: Ford, modelo T. |
| die industrielle Revolution (Phase I–IV) | revolución industrial (fases I-IV) | industrial revolution (phases I-IV) | I: mecanización (~1800). II: electricidad/producción en masa (~1900). III: electrónica/robótica (~1970). IV: Industria 4.0 / fábrica inteligente. |
| die Smart Factory | fábrica inteligente | smart factory | Productos y procesos conectados, "inteligencia" distribuida. |
| die Dark Factory | fábrica oscura | dark factory | Totalmente automatizada, sin personal ni iluminación necesaria. |
| der kollaborative Roboter (Cobot) | robot colaborativo | collaborative robot (cobot) | Detecta la cercanía de personas y reduce su velocidad; distinto del robot industrial clásico aislado. |
| das BGB (Bürgerliches Gesetzbuch) | Código Civil alemán | German Civil Code (BGB) | Base legal de la obligación de indemnizar por daños. |
| die Produkthaftung | responsabilidad por el producto | product liability | Incluye aspectos penales, laborales, de responsabilidad civil de empresa y de derecho civil (garantía). |
| die Gewährleistung | garantía (derecho de compraventa) | warranty / statutory guarantee | Derecho del cliente a devolución, reparación o sustitución. |
| Shewhart-Karte / Schuhart-Karte | carta de control de Shewhart | Shewhart control chart | Origen histórico (~1930) de la carta de control estadístico de calidad. |
| der PDCA-Zyklus / Deming-Zyklus | ciclo PDCA / ciclo de Deming | PDCA cycle / Deming cycle | Plan-Do-Check-Act; popularizado por Deming en Japón (~1950). |
| die ISO 9000-Normenfamilie (9000–9004) | familia de normas ISO 9000 (9000-9004) | ISO 9000 family of standards | Forma actual del sistema QM desde ~1990; revisión periódica (nueva versión anunciada para 2026). |
| das Total Quality Management (TQM) | gestión de calidad total | Total Quality Management (TQM) | Desarrollo desde ~1995, más allá del QM tradicional. |
| das integrierte Managementsystem | sistema de gestión integrado | integrated management system | Combina QM con gestión ambiental y prevención de riesgos laborales. |

## 48. Prozessparameter, Dokumentation und Prüfprotokolle

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| der Prozessparameter, - | parámetro de proceso | process parameter | Influye en cómo se fabrica algo (temperatura, presión, drehzahl...); ≠ Produktparameter. |
| der Produktparameter, - | parámetro de producto | product parameter | Lo que importa en la pieza terminada (espesor, conductividad...). |
| der Umgebungsparameter, - | parámetro ambiental | environmental parameter | Ej. humedad; frontera con Prozessparameter no siempre clara (reconocido por el propio docente). |
| die Rückverfolgbarkeit | trazabilidad | traceability | Esencial en wafers (alto valor); requiere ID individual por pieza. |
| der Soll-Ist-Vergleich | comparación objetivo-real | target-actual comparison | No basta con recopilar datos, hay que compararlos y evaluar. |
| SPC (statistische Prozessregelung) | control/regulación estadística de procesos | statistical process control (SPC) | El docente aclaró: mejor "regelung" (regulación) que "Kontrolle" (control) como traducción de "control" en SPC. |
| die Regelkarte, -n | carta de control | control chart | Diagrama de valores medidos + valores objetivo en el tiempo; detecta tendencias y outliers. |
| der Trend, -s | tendencia | trend | Detectado mediante regelkarten. |
| der Ausreißer, - | valor atípico / outlier | outlier | Detectado mediante regelkarten. |
| die Eingriffsgrenze, -n | límite de intervención | control limit (action limit) | Calculado estadísticamente. |
| die Normgrenze, -n | límite normativo/de especificación | specification limit | Distinto del límite de intervención estadístico. |
| Cp / Cpk (Prozessfähigkeitskennzahl) | índice de capacidad de proceso Cp / Cpk | process capability index (Cp/Cpk) | Solo mencionados; se profundizará más adelante (previa Maschinenfähigkeit + Prüfmittelprüfung). |
| die Maschinenfähigkeitsuntersuchung | estudio de capacidad de máquina | machine capability study | Prerrequisito mencionado antes de Cp/Cpk. |
| die Prüfmittelprüfung / Messsystemanalyse | verificación de medios de medición / análisis del sistema de medición | gauge verification / measurement system analysis (MSA) | Van juntas según el docente. |
| das Prüfprotokoll, -e | protocolo de prueba/inspección | test/inspection protocol | Documento central de este bloque temático. |
| das Kurzprüfprotokoll | protocolo breve de prueba | short-form test protocol | Resumen de valores/evaluaciones. |
| das Abnahmeprotokoll | protocolo de aceptación | acceptance protocol | Acto formal de liberación al siguiente paso o al mercado. |
| das Fertigungsprotokoll | protocolo de fabricación | manufacturing protocol | Foco en pruebas funcionales/visuales concretas por etapa; base del control ante desviaciones. |
| das Verifizierungs-/Qualitätsprüfprotokoll | protocolo de verificación/calidad | verification/quality test protocol | Demuestra cumplimiento de características de calidad definidas. |
| die Kopfdaten (pl.) | datos de cabecera | header data | Nº de documento único, versión, fecha, prüfer, objeto, proyecto, sede, lote/proveedor. |
| die Dokumentnummer, -n | número de documento | document number | Debe ser única, sin ambigüedad. |
| die Versionsnummer, -n | número de versión | version number | Para rastrear revisiones del documento. |
| der Prüfgegenstand, ¨-e | objeto de prueba | test object / item under test | Necesita ID propia (crítico en wafers). |
| die Charge, -n | lote | batch/lot | Relevante cuando hay varios proveedores. |
| der Kalibrierstatus | estado de calibración | calibration status | Se documenta junto con el instrumento usado. |
| das Ampelschema | esquema de semáforo (evaluación) | traffic-light scheme | Forma de evaluación cualitativa (verde/amarillo/rojo). |
| die Reproduzierbarkeit | reproducibilidad | reproducibility | Componente central de la evaluación de resultados de prueba. |
| die Messunsicherheit | incertidumbre de medición | measurement uncertainty | Se valora junto con la reproducibilidad. |
| adressatengerecht | adaptado al destinatario | audience-appropriate (tailored) | El nivel de detalle del informe depende de a quién va dirigido. |

## 49. FMEA, Fehlerklassifizierung, Audit, Verifizierung/Validierung

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die FMEA (Fehlermöglichkeits- und Einflussanalyse) | AMFE (análisis de modos de fallo y sus efectos) | Failure Mode and Effects Analysis (FMEA) | Aspecto profiláctico (inicio de proyecto) y aspecto de control (seguimiento posterior). |
| die Risikoprioritätszahl (RPZ) | número de prioridad de riesgo | Risk Priority Number (RPN) | Combina probabilidad, gravedad y detectabilidad. |
| der Fehler, - | fallo / defecto | defect / failure | Un requisito de calidad no se cumple (valor fuera de tolerancia o propiedad ausente). |
| die Passung, -en | ajuste (mecánico) | fit (mechanical) | Presspassung (forzado, pieza grande) vs. Spielpassung (con holgura, pieza pequeña). |
| die Presspassung | ajuste forzado/prensado | interference/press fit | El eje es mayor que el agujero (dentro de tolerancias de ajuste). |
| die Spielpassung | ajuste con holgura | clearance fit | El eje es menor que el agujero; puede causar juego excesivo o mal funcionamiento. |
| der kritische Fehler | fallo crítico | critical defect | Situación peligrosa/insegura o altos costos derivados (ej. frenos, contactor de subestación). |
| der Hauptfehler | fallo principal | major defect | Reduce sustancialmente la utilidad o provoca avería (ej. iluminación defectuosa — caso límite). |
| der Nebenfehler | fallo secundario | minor defect | No reduce sustancialmente la utilidad (ej. defecto de pintura, elevalunas duro). |
| die 10er-Regel | regla de diez (coste según etapa de detección) | rule of ten (cost escalation rule) | Costo se multiplica aprox. ×10 por cada etapa posterior en que se detecta el fallo. |
| die Fehlerfortpflanzung | propagación/amplificación de fallos | error/defect propagation | Ejemplo: 100 estaciones al 99% de exactitud → 0,99¹⁰⁰ ≈ 37% de producto final libre de fallos. |
| die Taguchi-Verlustfunktion | función de pérdida de Taguchi | Taguchi loss function | Minimizar dispersión respecto al valor objetivo, no solo "estar dentro de tolerancia". |
| das quantitative Merkmal | característica cuantitativa | quantitative characteristic | Se subdivide en stetig (continua) y diskret (discreta). |
| stetiges Merkmal | característica continua | continuous characteristic | Puede tomar cualquier valor intermedio (ej. diámetro). |
| diskretes Merkmal | característica discreta | discrete characteristic | Solo valores determinados/contables (ej. nº de puntos de soldadura). |
| das qualitative Merkmal | característica cualitativa | qualitative characteristic | Se subdivide en ordinal y nominal. |
| das Ordinalmerkmal | característica ordinal | ordinal characteristic | Relación de orden (ej. escala de notas). |
| das Nominalmerkmal | característica nominal | nominal characteristic | Sin relación de orden, solo pertenencia a categoría. |
| das Audit, -s | auditoría | audit | Proceso estructurado que evalúa la funcionalidad del sistema QM completo, no solo valores puntuales. |
| internes / externes Audit | auditoría interna / externa | internal / external audit | — |
| der Schlussbericht (Audit) | informe final (de auditoría) | audit closing report | Incluye áreas de mejora, plazos, responsabilidades. |
| das Zertifikat, -e | certificado | certificate | Validez típica 3–5 años; requiere renovación. |
| der/die Qualitätsmanagementbeauftragte(r) | responsable de gestión de calidad | quality management representative | Rol típico en empresas más grandes. |
| die Verifizierung / verifizieren | verificación / verificar | verification / to verify | "¿Construimos el producto correctamente?" — cumplimiento de requisitos especificados. |
| die Validierung / validieren | validación / validar | validation / to validate | "¿Construimos el producto correcto?" — cumplimiento del uso/propósito previsto. |
| das Qualitätsmanagementsystem (QMS) | sistema de gestión de calidad (SGC) | quality management system (QMS) | Determina objetivos, procesos y recursos necesarios; dirige y controla para crear valor. |
| die Kundenzufriedenheit | satisfacción del cliente | customer satisfaction | Primer principio de gestión de calidad mencionado en clase. |
| die ständige Verbesserung | mejora continua | continuous improvement | Relacionado con KVP (Kontinuierlicher Verbesserungsprozess) y Kaizen. |
| das Beziehungsmanagement | gestión de relaciones | relationship management | Con proveedores, clientes y demás partes interesadas. |
| die sachbezogene Entscheidungsfindung | toma de decisiones basada en hechos | fact-based decision making | Opuesto a decidir "por intuición". |
| das FMEA-Beispiel: "PZ" [A CONFIRMAR abreviatura exacta en audio] | número de prioridad (posible sigla alternativa a RPZ) | (possible alt. abbreviation for RPN) | El audio usó una sigla corta distinta de "RPZ"; forma exacta no confirmada. |
