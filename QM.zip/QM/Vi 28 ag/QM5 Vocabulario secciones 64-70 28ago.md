# TQ2 — Vocabulario nuevo, sesión QM5 (28 ago)
_Continúa la numeración desde la sección 63 (consolidado hasta QM4, 27 ago)._

## 64. FMEA — conceptos generales

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die FMEA (Fehlermöglichkeits- und Einflussanalyse) | AMEF / análisis de modos de fallo y efectos | failure mode and effects analysis (FMEA) | Origen: industria aeroespacial de EE.UU., no Japón. |
| der Fehler (nach ISO 9000) | fallo (definición normativa) | non-conformity / defect | Nichterfüllung einer festgelegten, vorausgesetzten Forderung. |
| die Zehnerregel | regla del factor diez | rule of ten (cost escalation) | Costo de corrección ×10 por cada etapa posterior de detección. |
| das System-FMEA / Produkt-FMEA | FMEA de sistema / de producto | system FMEA | Antes de fabricación; responsable: desarrollo. |
| die Konstruktions-FMEA / Design-FMEA | FMEA de diseño/construcción | design FMEA (DFMEA) | Sobre planos de construcción; responsable: diseño. |
| die Prozess-FMEA | FMEA de proceso | process FMEA (PFMEA) | Sobre planes de fabricación; responsable: producción. |
| die Strukturanalyse (FMEA) | análisis estructural | structure analysis | Primer paso: listar pasos/componentes, fallos, folgen, ursachen. |
| die Auftretenswahrscheinlichkeit (A) | probabilidad de aparición | occurrence (O) | Escala 1–10; base en ppm. |
| die Bedeutung (B) | importancia/gravedad para el cliente | severity (S) | Escala 1–10. |
| die Entdeckungswahrscheinlichkeit (E) | probabilidad de detección | detection (D) | Escala 1–10; 10 = casi indetectable. |
| die Risikoprioritätszahl (RPZ) | número de prioridad de riesgo | risk priority number (RPN) | RPZ = A × B × E; rango 1–1000. |
| die Fehlerfolge, -n | consecuencia del fallo | failure effect | Lo que ocurre al final si el fallo se produce. |
| die Fehlerursache, -n | causa del fallo | failure cause | Origen del fallo, punto de partida del análisis en cascada. |
| das Kick-off-Meeting (FMEA) | reunión de arranque | kick-off meeting | Inicio del equipo FMEA con áreas de desarrollo/taller. |
| die Action Priority Method | método de prioridad de acción | Action Priority Method (APM) | Desde 2019; prioriza urgencia en vez de solo RPZ. |
| bauteilorientiert / funktionsorientiert / ablauforientiert | orientado a componentes / a funciones / al flujo | component- / function- / process-oriented (structure) | Criterios de estructuración del sistema en la FMEA. |

## 65. Capacidad de proceso — ampliación

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die vorläufige Prozessfähigkeit (Pp/Ppk) | capacidad preliminar de proceso | preliminary process capability (Pp/Ppk) | Con pocas muestras, sin periodo largo de observación. |
| ΔKrit (Delta-Krit) | distancia crítica mínima | critical distance | Menor distancia del promedio a un límite de tolerancia. |
| fähig (Prozess) | capaz (proceso) | capable | Se refiere a la dispersión, no a la posición. |
| beherrscht (Prozess) | controlado/dominado (proceso) | in (statistical) control | Se refiere a la estabilidad de la posición/media. |

## 66. Excel — regresión y gráficos

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Trendlinie, -n | línea de tendencia | trendline | Opciones: linear, potenz, polynom, logarithmisch, exponentiell. |
| die Potenzfunktion, -en | función potencial | power function | y = a·x^b; elegida por plausibilidad física frente al polinomio. |
| das Bestimmtheitsmaß (R²) | coeficiente/índice de determinación | coefficient of determination (R²) | Cuadrado del coeficiente de correlación. |
| der Korrelationskoeffizient | coeficiente de correlación | correlation coefficient (r) | Raíz cuadrada de R²; máximo valor 1. |
| Transponieren (Excel) | transponer | transpose (Excel paste special) | Convierte fila en columna y viceversa. |
| Inhalte einfügen | pegado especial | paste special | Menú con opciones: valores, HTML, objeto, vínculo, transponer. |

## 67. ISO 9000-Normfamilie

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die ISO 9000 | ISO 9000 (términos y definiciones) | ISO 9000 (fundamentals and vocabulary) | Base terminológica; no es la norma certificable. |
| die ISO 9001 | ISO 9001 (requisitos) | ISO 9001 (requirements) | Norma sobre la que se certifica un sistema de gestión. |
| die ISO 9004 | ISO 9004 (éxito sostenido) | ISO 9004 (sustained success) | Guía de mejora, no certificable por sí sola. |
| die ISO 19011 | ISO 19011 (auditoría) | ISO 19011 (auditing guidelines) | Guía para auditar sistemas de gestión de calidad/ambiente. |
| das TQM (Total Quality Management) | gestión de calidad total | Total Quality Management (TQM) | Marco general en el que se inserta la familia ISO 9000. |
| der PDCA-Zyklus / Deming-Zyklus | ciclo PDCA / ciclo de Deming | PDCA cycle / Deming cycle | Plan-Do-Check-Act; estructura las cláusulas de ISO 9001. |
| die dokumentierte Information, -en | información documentada | documented information | Reemplaza los antiguos "Dokumente"/"Aufzeichnungen" (versión 2015). |
| das Qualitätsmanagement-Handbuch | manual de gestión de calidad | quality management manual | Nivel más alto de documentación, específico de cada empresa. |
| die Verfahrensanweisung, -en | instrucción de procedimiento | procedure instruction | Nivel intermedio entre manual e instrucción de trabajo. |
| die Arbeitsanweisung, -en | instrucción de trabajo | work instruction | Nivel más concreto, en el puesto de trabajo. |
| die Kundenorientierung (ISO 9001, 5.1.2) | orientación al cliente (cláusula) | customer focus (clause) | Obligación de la alta dirección de garantizar cumplimiento constante. |
| das Bewusstsein (ISO 9001) | conciencia/toma de conciencia | awareness (clause) | Aplica a TODAS las personas bajo supervisión de la organización. |
| die Ressourcen zur Überwachung und Messung | recursos de seguimiento y medición | monitoring and measuring resources | = Prüfmittel; deben demostrar idoneidad documentada. |
| das Zertifizierungsaudit | auditoría de certificación | certification audit | = Third-Party-Audit; otorga el certificado si se aprueba. |

## 68. Audits

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Produkt-Audit | auditoría de producto | product audit | Evalúa cumplimiento de especificaciones/expectativas del cliente. |
| das Prozess-Audit | auditoría de proceso | process audit | Evalúa eficiencia, consistencia y ausencia de fallos de un flujo. |
| das System-Audit | auditoría de sistema | system audit | Evalúa el sistema de gestión completo. |
| das First-Party-Audit | auditoría de primera parte | first-party audit (internal audit) | Interna; el auditor puede ser interno o externo formado. |
| das Second-Party-Audit (Lieferantenaudit) | auditoría de segunda parte (al proveedor) | second-party audit (supplier audit) | Dos partes: cliente y proveedor. |
| das Third-Party-Audit | auditoría de tercera parte | third-party audit | Auditor externo independiente; lleva a certificación. |
| das Auditprogramm | programa de auditoría | audit programme | Planificación estratégica a largo plazo, varias auditorías. |
| der Auditplan, -"e | plan de auditoría | audit plan | Planificación de una auditoría concreta. |
| der Auditprogrammleiter, - | responsable del programa de auditoría | audit programme manager | Encarga auditorías individuales dentro del programa. |
| der Abweichungsbericht, -e | informe de desviaciones | non-conformance report | Documenta hallazgos durante la auditoría. |
| der Auditbericht, -e | informe de auditoría | audit report | Resultado final, incluye conformidad/no conformidad y medidas. |
| das Nachaudit / Re-Audit | auditoría de seguimiento | follow-up audit | Verifica implementación de medidas tras desviaciones grandes. |
| unangekündigtes Audit | auditoría sin previo aviso | unannounced audit | Excepción típica en gastronomía/producción sensible. |

## 69. Six Sigma

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Six Sigma | Six Sigma | Six Sigma | Origen: Motorola, EE.UU., años 80 — no Japón. |
| der DMAIC-Zyklus | ciclo DMAIC | DMAIC cycle | Define-Measure-Analyse-Improve-Control; análogo al PDCA. |
| die Variation, -en (Prozess) | variación (de proceso) | (process) variation | Magnitud de entrada del proceso que se busca reducir. |
| die 7×7-Werkzeuge (Six Sigma) | las 7×7 herramientas de Six Sigma | 7×7 Six Sigma toolset | 7 categorías × 7 herramientas cada una; amplía las 7 clásicas de QM. |

## 70. Redacción de informes técnicos

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| adressatengerecht | adecuado al destinatario | audience-appropriate | Principio rector del informe técnico. |
| die DIN 1421 | norma DIN 1421 (clasificación numérica) | DIN 1421 (numbering/classification) | Gliederung de capítulos, máx. ~3 niveles recomendados. |
| die DIN 1422 | norma DIN 1422 (contenido de informes) | DIN 1422 (technical report content) | Contenido/estructura de informes técnicos. |
| die Einwegkommunikation | comunicación unidireccional | one-way communication | Característica clave de la documentación escrita (vs. diálogo). |
| das Deppenleerzeichen | espacio incorrecto (coloquial) | erroneous space (in compound words) | Separar incorrectamente sustantivos compuestos alemanes. |
| der Deppenapostroph | apóstrofo incorrecto (coloquial) | erroneous apostrophe | Uso injustificado del apóstrofo, influencia del inglés. |
| die Serifenschrift | tipografía con serifa | serif typeface | Ej. Times New Roman; preferida en impresos y texto corrido. |
| die serifenlose Schrift | tipografía sin serifa | sans-serif typeface | Ej. Arial, Helvetica; preferida en tamaños extremos. |
| die Proportionalschrift | tipografía proporcional | proportional typeface | Cada letra ocupa el espacio según su forma. |
| die nicht-proportionale Schrift | tipografía no proporcional (monoespaciada) | monospaced typeface | Todas las letras igual ancho; típico en código de programación. |
| einbetten (Objekt in Word) | incrustar (objeto en Word) | embed (object) | Datos guardados dentro del documento; no se actualiza con el original. |
| verknüpfen (Objekt in Word) | vincular (objeto en Word) | link (object) | Objeto queda externo; se actualiza al abrir/actualizar el documento. |
| der Formel-Editor (Word) | editor de fórmulas (Word) | equation editor (Word) | Navegación con flechas, no barra espaciadora. |
