# TQ2 — Vocabulario nuevo: secciones 47–53
_Para añadir al archivo consolidado tras la sección 46 (Zahlensysteme, sesión 16). Tema nuevo: Qualitätsmanagement/Statistik._

## 47. Qualitätsmanagement — Statistische Grundlagen

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Einzelhäufigkeit, -en | frecuencia individual | individual frequency | Valor o % de aparición de un valor concreto. |
| die Summenhäufigkeit | frecuencia acumulada | cumulative frequency | Suma progresiva de frecuencias individuales, hasta 100%. |
| das Histogramm, -e | histograma | histogram | Representación de frecuencias como barras. |
| die Wahrscheinlichkeit (P) | probabilidad | probability | P = g/m (casos favorables / casos posibles). |
| das Galtonbrett | tablero de Galton | Galton board / bean machine | Modelo físico que genera la campana de Gauss por azar acumulado. |
| die Normalverteilung / Gaußsche Glockenkurve | distribución normal / campana de Gauss | normal distribution / Gaussian curve | Definida por μ (media) y σ (desviación estándar). |
| der Mittelwert (μ) | media (de la población) | population mean | Lagemaß — dónde está el máximo de la curva. |
| die Standardabweichung (σ) | desviación estándar (de la población) | population standard deviation | Streumaß — distancia media al punto de inflexión. |
| der Wendepunkt, -e | punto de inflexión | inflection point | Define σ en la curva de Gauss (2ª derivada = 0). |
| die Wahrscheinlichkeitsdichtefunktion (g(x)/f(x)) | función de densidad de probabilidad | probability density function (PDF) | Curva de campana propiamente dicha. |
| die Verteilungsfunktion (F(x)/G(x)) | función de distribución (acumulada) | cumulative distribution function (CDF) | Curva en forma de S. |
| Six Sigma | Six Sigma | Six Sigma | Meta de "producción sin defectos"; ~99,99966% dentro de tolerancia. |
| die standardisierte Normalverteilung | distribución normal estandarizada | standard normal distribution | μ=0, σ=1; permite usar tablas únicas. |
| die Z-Standardisierung / der Z-Wert (U) | estandarización Z / valor Z | Z-score / standardization | Z = (x − μ) / σ. |
| die Mischverteilung | distribución mixta/bimodal | mixed/bimodal distribution | Dos poblaciones distintas mezcladas sin distinguir. |
| die Schiefeverteilung | distribución sesgada | skewed distribution | Máximo desplazado, suele deberse a Ausreißer. |
| der Ausreißer, - | valor atípico | outlier | Desplaza fuertemente la media, casi no afecta la mediana. |
| einseitig begrenzter Bereich | rango limitado por un solo lado | one-sided bounded range | Ej. Streuung, Konzentrizität — se acerca a 0 pero nunca negativo. |

## 48. Qualitätsmanagement — Kennwerte (Lage- und Streumaße)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Grundgesamtheit | población total | population | Símbolos: N, μ, σ. |
| die Stichprobe, -n | muestra | sample | Símbolos: n, x̄ (x quer), s. |
| das arithmetische Mittel (x̄, x quer) | media aritmética | arithmetic mean | Suma de valores / n. |
| der Median (x̃, x-Zentralwert) | mediana | median | Valor central de datos ordenados; robusto ante Ausreißer. |
| die rangierten Werte | valores ordenados/rangeados | ranked/sorted values | Requisito previo para calcular el Median. |
| die Spannweite (R) | rango | range | R = x_max − x_min. |
| die mittlere absolute Abweichung (d quer) | desviación media absoluta | mean absolute deviation | Usa valores absolutos; poco usada por complejidad matemática. |
| die Varianz (s²) | varianza | variance | Promedio de diferencias al cuadrado respecto a la media. |
| n minus 1 (Stichprobenkorrektur) | corrección n−1 (para muestras) | Bessel's correction (n−1) | Denominador de s en muestra; da valor ligeramente mayor que con n. |
| der Variationskoeffizient (V) | coeficiente de variación | coefficient of variation | V = s / x̄; útil para comparar dispersión entre medias distintas. |
| die drei tragenden Ziffern | tres cifras significativas | three significant figures | Regla de redondeo técnico para resultados finales (~1% error). |
| STABW.S (Excel) | desviación estándar de muestra (Excel) | STDEV.S (sample stdev, Excel) | Usa n−1; reemplaza a la función antigua SDABW. |
| STABW.N (Excel) | desviación estándar de población (Excel) | STDEV.P (population stdev, Excel) | Usa n. |
| μ̂ / σ̂ (Dach-Symbol) | mu/sigma estimados ("con gorrito") | estimated mu/sigma (hat notation) | Estimación de la población a partir de varias muestras (m×n valores). |

## 49. Qualitätsmanagement — Stichprobenprüfung und Annahmeprüfung

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die zerstörende Prüfung | ensayo destructivo | destructive test | Obliga a trabajar con muestra, nunca 100%. |
| die normale/verschärfte/reduzierte Prüfung | inspección normal/reforzada/reducida | normal/tightened/reduced inspection | Rigor de muestreo según historial reciente de fallos. |
| das Skip-Lot-Verfahren | procedimiento de salto de lote | skip-lot sampling | Se omite cada segunda inspección programada si el proceso es muy estable. |
| die Annahmestichprobenprüfung | inspección de aceptación por muestreo | acceptance sampling | Para lotes recibidos de proveedores. |
| die annehmbare Qualitätsgrenzlage (AQL) | nivel de calidad aceptable (AQL) | acceptable quality level (AQL) | % contractual de defectos tolerables; menor valor = más estricto. |
| die DIN ISO 2859 | norma DIN ISO 2859 | DIN ISO 2859 | Muestreo de aceptación para características atributivas (contables). |
| die Losgröße, -n | tamaño de lote | lot size | Junto con AQL determina el tamaño de muestra requerido. |
| attributives Merkmal | característica atributiva | attribute characteristic | Bueno/malo, contable — vs. quantitatives (medible). |

## 50. Qualitätsmanagement — Die 7 Werkzeuge (I): Datenerfassung, Histogramm, Regelkarte

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die 7 Qualitätswerkzeuge | las 7 herramientas de calidad | 7 QC tools | Selección varía algo según autor. |
| die Fehlersammelliste / Fehlerzählkarte | lista de recogida de fallos | defect tally sheet | Para características discretas/contables, con Strichliste (5 en 5). |
| die Strichliste | lista de conteo (por clases) | tally chart (grouped data) | Para datos continuos clasificados; no confundir con Fehlersammelliste. |
| die Häufigkeitstabelle | tabla de frecuencias | frequency table | Usada a veces como sinónimo de ambas anteriores — hay que ver el contexto. |
| das Verlaufsdiagramm | diagrama de evolución/tendencia | run chart | Valores en función del tiempo; base de la Regelkarte. |
| die Regelkarte, -n | carta de control | control chart | Permite ver estabilidad en el tiempo — el histograma solo no lo permite. |
| die Klassenbildung | formación de clases | class formation | k ≈ raíz de n (regla práctica); clases ni muy finas ni muy anchas. |
| die Klassenweite / Klassenbreite | amplitud de clase | class width | = Spannweite / número de clases. |
| die Klassengrenze, -n | límite de clase | class boundary | Límite superior de una clase = límite inferior de la siguiente. |

## 51. Qualitätsmanagement — Die 7 Werkzeuge (II): Brainstorming, Ishikawa, Streudiagramm, Pareto

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Brainstorming | lluvia de ideas | brainstorming | Grupo heterogéneo, sin crítica en el momento, cantidad antes que calidad. |
| das Ursache-Wirkungs-Diagramm / Ishikawa-Diagramm / Fischgräten-Diagramm | diagrama causa-efecto / Ishikawa / espina de pescado | cause-and-effect / Ishikawa / fishbone diagram | Tres nombres válidos, todos examinables. |
| die 5M (Mensch, Maschine, Material, Methode, Mitwelt) | las 5M (persona, máquina, material, método, entorno) | 5M (Man, Machine, Material, Method, Mother Nature/Environment) | Categorías clásicas; ampliables (Management, Money, Messung). |
| das Streudiagramm / Korrelationsdiagramm | diagrama de dispersión / correlación | scatter diagram / correlation diagram | Para detectar relación entre dos variables de un proceso. |
| der Korrelationskoeffizient | coeficiente de correlación | correlation coefficient | Cercano a ±1 = relación fuerte; cercano a 0 = sin relación. |
| die Ausgleichsgerade / Trendlinie | línea de tendencia / ajuste | trend line / line of best fit | Se traza sobre el Streudiagramm para visualizar la relación. |
| die Pareto-Analyse / ABC-Analyse | análisis de Pareto / análisis ABC | Pareto analysis / ABC analysis | Ordenado de mayor a menor + curva acumulada. |
| die 80-20-Regel | regla 80-20 | 80/20 rule (Pareto principle) | 80% del resultado con 20% de las causas (orientativo). |
| die Fehlerklasse A/B/C | clase de fallo A/B/C | defect class A/B/C | A = pocos pero muy costosos/prioritarios; C = frecuentes, bajo impacto. |

## 52. Qualitätsmanagement — Fehlerbaumanalyse, Matrixdiagramm, PDCA

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Fehlerbaumanalyse (FBA/FTA) | análisis del árbol de fallos | fault tree analysis (FTA) | Parte de un Top-Ereignis, usa operadores lógicos UND/ODER. |
| das Top-Ereignis, -se | evento superior/no deseado | top event | Punto de partida de un árbol de fallos. |
| das Baumdiagramm, -e | diagrama de árbol | tree diagram | Representa dependencias/jerarquías (ej. despieces). |
| das Matrixdiagramm, -e | diagrama de matriz | matrix diagram | Comparación por pares de criterios para tomar decisiones. |
| der PDCA-Zyklus / Deming-Kreis | ciclo PDCA / círculo de Deming | PDCA cycle / Deming wheel | Plan-Do-Check-Act; variante alemana PDPH (Plan-Do-Prüfen-Handeln). |

## 53. Qualitätsmanagement — 5S, Just-in-Time, 5-Why, 8D-Report

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| 5S / 5A | 5S / 5A | 5S (Sort, Set, Shine, Standardize, Sustain) | Parte del sistema de producción Toyota. |
| SMED (Single Minute Exchange of Die) | SMED | SMED | Reducir tiempos de cambio de herramienta a minutos. |
| das Just-in-Time-Prinzip (JIT) | principio justo a tiempo | just-in-time (JIT) | Entrega en el momento de necesidad, minimiza almacén. |
| die 5-Why-Methode / 5×Warum | método de los 5 porqués | 5 Whys method | Preguntar "¿por qué?" repetidamente hasta la causa raíz. |
| der 8D-Report | informe de las 8 disciplinas | 8D report | Estándar VDA para reclamaciones; 8 pasos, ligado a PDCA. |
| Lessons Learned | lecciones aprendidas | lessons learned | Documentación de buenas prácticas al cerrar un 8D. |
| der Sponsor, -en (8D) | patrocinador (del equipo 8D) | sponsor | Rol que asigna recursos y da el cierre final. |
