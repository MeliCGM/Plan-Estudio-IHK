# Vocabulario nuevo — QM 3 (26 ago)
_Secciones 54–58, para añadir al final del archivo TQ2_Vocabulario_CONSOLIDADO_NUEVO.md (continúa tras la sección 41)._

## 54. Calidad — Métodos de resolución de problemas (8D, 5-Why)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| der 8D-Report / die 8D-Methode | informe/método 8D | 8D report/method | D = Disziplin; 8 pasos estandarizados por el VDA (asociación automotriz alemana). |
| die Disziplin, -en (8D) | disciplina (paso del 8D) | discipline (8D step) | No "disciplina" en sentido educativo, sino cada uno de los 8 pasos. |
| der Sponsor, -en | patrocinador (del equipo 8D) | sponsor | Asegura los recursos necesarios para resolver el problema. |
| das interdisziplinäre Team | equipo interdisciplinario | cross-functional team | Desarrollo, producción, servicio, compras. |
| die 6W-Fragetechnik | técnica de las 6 preguntas | 5W1H / 6W questioning technique | Wer, was, wann, wo, wie, warum (quién, qué, cuándo, dónde, cómo, por qué). |
| der Schnellstopp | parada rápida | quick stop / containment | Medida inmediata (D3) para frenar la propagación del fallo. |
| die Sofortmaßnahme, -n | medida inmediata | immediate/containment action | D3 del 8D. |
| die Abstellmaßnahme, -n | medida correctiva/de eliminación | corrective action | D5–D6 del 8D. |
| die Vorbeugungsmaßnahme, -n | medida preventiva | preventive action | D7 del 8D. |
| die Wirksamkeit (Validierung der) | eficacia (validación de la) | effectiveness (validation of) | D6: se valida que la medida realmente funcionó. |
| die Entscheidungsmatrix, -en | matriz de decisión | decision matrix | Comparación por pares de criterios; usada en D5. |
| das Ishikawa-Diagramm | diagrama de Ishikawa (espina de pescado) | Ishikawa/fishbone diagram | Herramienta de análisis de causas (D4). |
| die 5-Why-Methode / 5W-Methode | método de los 5 porqués | 5-Why method | Herramienta de análisis, no de solución; parte del Toyota-Produktionssystem. |
| das Toyota-Produktionssystem (TPS) | sistema de producción Toyota | Toyota Production System (TPS) | Origen histórico de 5-Why y otras herramientas lean. |
| der Schlupffehler, - | error de escape | slip-through error | Pieza mala no detectada, pasa como buena. |
| der Pseudofehler, - | pseudo-error | pseudo error / false rejection | Pieza buena rechazada por error. |
| Lessons Learned | lecciones aprendidas | lessons learned | D8; distinción con Best Practices no siempre clara según el propio profesor. |
| Best Practices | mejores prácticas | best practices | D8; documentadas en base de conocimiento de la empresa. |
| das VDA (Verband der Automobilindustrie) | asociación de la industria automotriz (alemana) | German Association of the Automotive Industry (VDA) | Estandariza el 8D-Report. |
| die Reklamation, -en | reclamación (de cliente) | customer complaint | Motivo típico para abrir un 8D. |
| die Fehlerursache, -n | causa del fallo | root cause | Objetivo del análisis de causas (D4). |
| die Wiederholungsfehler (pl.) | errores repetidos/recurrentes | recurring errors | Uno de los objetivos del 8D es evitarlos. |

## 55. Calidad — Herramientas gráficas (Flussdiagramm, Diagrammtypen)

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| das Flussdiagramm, -e | diagrama de flujo | flowchart | Símbolos: óvalo=inicio/fin, rectángulo=proceso, rombo=decisión. |
| der Entscheidungspunkt, -e | punto de decisión | decision point | Símbolo: rombo, en un diagrama de flujo. |
| das Symbol, -e (Flussdiagramm) | símbolo (de diagrama de flujo) | flowchart symbol | Estandarizados, similares a los de programas de oficina. |
| die Vorbereitungsmaßnahme, -n (Symbol) | medida de preparación (símbolo) | preparation step (symbol) | Forma de trapecio alargado en el diagrama de flujo. |
| das Säulendiagramm, -e | diagrama de columnas | column chart | Barras verticales. |
| das Balkendiagramm, -e | diagrama de barras | bar chart | Barras horizontales; se confunde fácilmente con Säulendiagramm. |
| das Kreisdiagramm, -e | diagrama circular / de pastel | pie chart | Para mostrar proporciones del total. |
| das Liniendiagramm, -e | diagrama de líneas | line chart | Para evoluciones temporales y tendencias. |
| das Streudiagramm, -e | diagrama de dispersión | scatter chart | Para detectar relaciones desconocidas entre variables. |
| das Verbunddiagramm, -e | diagrama combinado | combo chart | Ej. columnas + línea; usado para histograma + curva acumulada. |
| das Pareto-Prinzip | principio de Pareto | Pareto principle | Regla 80/20. |
| die Korrelationsanalyse, -n | análisis de correlación | correlation analysis | Vinculado al Streudiagramm. |

## 56. Calidad — Estadística descriptiva y Excel

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| der arithmetische Mittelwert | media aritmética | arithmetic mean | Suma de valores / cantidad. |
| der Median (x̃) | mediana | median | Valor central de la serie ordenada. |
| der Modus | moda | mode | Valor más frecuente; función MODUS/MODA en Excel. |
| die Spannweite | rango (estadístico) | range | Max − Min. |
| die Standardabweichung (Stichprobe vs. Grundgesamtheit) | desviación estándar (muestra vs. población) | standard deviation (sample vs. population) | Muestra usa N−1 (STABW.S), población usa N (STABW.N); muestra siempre ≥ población. |
| die Klassierung / klassieren | clasificación en clases / clasificar | binning / to bin (data) | Agrupar valores continuos en intervalos para el histograma. |
| die Klassenanzahl | número de clases | number of classes/bins | Valor orientativo, no fórmula fija. |
| die Klassenweite | ancho de clase | class width | = Spannweite / Klassenanzahl, redondeado. |
| die Klassengrenze, -n (obere/untere) | límite de clase (superior/inferior) | class boundary (upper/lower) | Deben ser continuos sin solapamiento ni huecos. |
| die absolute Adressierung ($) | direccionamiento absoluto (Excel) | absolute cell reference | Fijado con $; tecla F4 en Excel. |
| die relative Adressierung | direccionamiento relativo (Excel) | relative cell reference | Se desplaza al copiar la fórmula. |
| der Namens-Manager (Excel) | administrador de nombres (Excel) | Name Manager (Excel) | Asigna nombres a rangos de celdas. |
| ZÄHLENWENN / ZÄHLENWENNS | función CONTAR.SI / CONTAR.SI.CONJUNTO | COUNTIF / COUNTIFS | Usada para contar frecuencias por clase con condiciones. |
| die Häufigkeit (absolut/relativ) | frecuencia (absoluta/relativa) | frequency (absolute/relative) | Nj = absoluta, hj = relativa (Nj/total). |
| die Häufigkeitssumme (kumuliert) | frecuencia acumulada | cumulative frequency | Suma progresiva de las frecuencias relativas. |
| das Histogramm, -e | histograma | histogram | Gráfico de barras adyacentes por clase. |
| die Sekundärachse (Diagramm) | eje secundario (de un gráfico) | secondary axis (chart) | Para combinar dos escalas distintas en un mismo gráfico. |

## 57. Calidad — Fähigkeitsuntersuchungen: MSA, Prüfmittel- y Maschinenfähigkeit

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die beherrschten Bedingungen (ISO 9001) | condiciones controladas (ISO 9001) | controlled conditions (ISO 9001) | Requisito de la norma para producción/prestación de servicios. |
| die Fähigkeitsuntersuchung, -en | estudio de capacidad | capability study | Genérico: Prüfmittel-, Maschinen- o Prozessfähigkeit. |
| die MSA (Messsystemanalyse) | análisis del sistema de medición (MSA) | measurement system analysis (MSA) | Incluye variantes para características cuantitativas y atributivas. |
| die Prüfmittelfähigkeit (CG/CGK) | capacidad del instrumento de medición | gauge capability (CG/CGK) | Primer paso antes de Maschinenfähigkeit. |
| das Kalibriernormal, -e / Endmaß, -e | patrón de calibración / bloque patrón | calibration standard / gauge block | Usado para medir Wiederholpräzision. |
| die Wiederholpräzision | precisión de repetición | repeatability | Medir varias veces el mismo patrón. |
| die Vergleichspräzision | precisión de comparación | reproducibility | Variando prüfer/lugar/equipo. |
| die Stabilität (Messmittel) | estabilidad (del instrumento) | stability (gauge) | Variación del parámetro a lo largo del tiempo. |
| die Maschinenfähigkeit (CM/CMK) | capacidad de la máquina | machine capability (CM/CMK) | Estudio a corto plazo (MFU), min. 50 piezas. |
| die MFU (Maschinenfähigkeitsuntersuchung) | estudio de capacidad de máquina | machine capability study (MFU) | Siglas usadas en clase. |
| die Prozessfähigkeit (CP/CPK) | capacidad de proceso | process capability (CP/CPK) | Kurzfristig/langfristig; formeln iguales a PP/PPK. |
| der Prozessfähigkeitsindex / Prozessleistungsindex | índice de capacidad / de rendimiento de proceso | process capability index / process performance index | CP=PP, CPK=PPK en fórmula; distinción no uniforme en la literatura. |
| SPC (statistische Prozessregelung/-kontrolle) | control estadístico de procesos (SPC) | statistical process control (SPC) | Incluye Qualitätsregelkarten. |
| die Qualitätsregelkarte, -n | carta/gráfico de control de calidad | control chart | Herramienta central del SPC. |
| der kleine Regelkreis | ciclo de control pequeño | small control loop | Reacción directa en la máquina, con plan de reacción. |
| der große Regelkreis | ciclo de control grande | large control loop | Mejora continua a largo plazo (KVP). |
| der Reaktionsplan, -"e | plan de reacción | reaction plan | Instrucciones para el operario ante una desviación. |
| die Kappa-Methode | método kappa | Kappa method | MSA para características atributivas (bueno/malo). |
| das attributive Merkmal, -e | característica atributiva | attribute characteristic | Bueno/malo, sí/no; contraste con característica cuantitativa. |
| die Sichtprüfung, -en | inspección visual | visual inspection | Ámbito típico de aplicación del método kappa. |
| SD2 (VDA-Norm) | norma SD2 de la VDA | VDA SD2 standard | Exige mín. 90% de detección correcta en inspección visual. |
| die Reproduzierbarkeit (Kappa) | reproducibilidad (entre inspectores) | reproducibility (inter-rater) | Lo que mide realmente el índice kappa. |
| die Treffsicherheit | precisión/acierto (frente al criterio experto) | accuracy (vs. expert reference) | Distinto de kappa: kappa no garantiza acierto, solo coincidencia entre prüfer. |

## 58. Calidad — Maschinenfähigkeit: cálculo CM/CMK y método gráfico

| Alemán | Español | Inglés técnico | Nota de memorización |
|---|---|---|---|
| die Fertigungsstreuung | dispersión de fabricación | manufacturing spread | = 6×S; no debe superar el 60% de la tolerancia T. |
| CM (Maschinenfähigkeitsindex) | índice de capacidad de máquina (dispersión) | machine capability index (spread) | CM = T / (6×S); valor de referencia ≥1,67. |
| CMK (Maschinenfähigkeitsindex, Lage) | índice de capacidad de máquina (centrado) | machine capability index (centering) | CMK = ΔKrit / (3×S); siempre CMK ≤ CM. |
| das Delta-Krit (ΔKrit) | distancia crítica | critical distance | Menor de las dos distancias media–límite de tolerancia. |
| die Zentrierung (Prozess) | centrado (del proceso) | centering (process) | CMK = CM solo si está perfectamente centrado. |
| der obere/untere Grenzwert (OGW/UGW) | límite superior/inferior (de tolerancia) | upper/lower specification limit (USL/LSL) | No confundir con Maximum/Minimum de los datos medidos. |
| das Wahrscheinlichkeitsnetz | papel/red de probabilidad | probability plot (paper) | Eje x lineal, eje y logarítmico (%); método gráfico para CM/CMK. |
| die Ausgleichsgerade, -n | recta de ajuste/regresión | best-fit line | Trazada a través de los puntos del papel de probabilidad. |
| der Überschreitungsanteil, -e (B̂o/B̂u) | proporción fuera de tolerancia | out-of-tolerance proportion | Estimado gráfica o analíticamente. |
| die Standardnormalverteilung | distribución normal estándar | standard normal distribution | Usada junto con la transformación u=(x−x̄)/S. |
| die u-Transformation / z-Transformation | transformación u / z (estandarización) | z-transformation / standardization | u = (x − x̄) / S. |
| der Beschichter / Belacker, - | equipo de recubrimiento (spin coater/aplicador) | coater (spin/spray) | Ejemplo de máquina analizada (espesor de lacado). |
